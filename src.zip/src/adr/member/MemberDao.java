package adr.member;

import java.util.List;

public interface MemberDao {

	MemberVO findByMememail(String mememail);

}
