package adr.tool.util;

public class Common {
	public final static String URL = "jdbc:oracle:thin:@localhost:1521:XE";
	public final static String USER = "aa103";
	public final static String PASSWORD = "1234";
}
