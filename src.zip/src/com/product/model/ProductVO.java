package com.product.model;
import java.sql.Date;

public class ProductVO implements java.io.Serializable{
	private Integer prodno;
	private String prodname;
	private Double prodprice;
	private byte[] prodpic;
	private String proddesc;
	
	
	public Integer getProdno() {
		return prodno;
	}
	public void setProdno(Integer prodno) {
		this.prodno = prodno;
	}
	public String getProdname() {
		return prodname;
	}
	public void setProdname(String prodname) {
		this.prodname = prodname;
	}
	public Double getProdprice() {
		return prodprice;
	}
	public void setProdprice(Double prodprice) {
		this.prodprice = prodprice;
	}
	public byte[] getProdpic() {
		return prodpic;
	}
	public void setProdpic(byte[] prodpic) {
		this.prodpic = prodpic;
	}
	public String getProddesc() {
		return proddesc;
	}
	public void setProddesc(String proddesc) {
		this.proddesc = proddesc;
	}
	
}
