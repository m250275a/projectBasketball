package com.product.model;

import java.util.*;
import java.sql.*;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class ProductDAO implements ProductDAO_interface {

	// �@�����ε{����,�w��@�Ӹ�Ʈw ,�@�Τ@��DataSource�Y�i
	private static DataSource ds = null;
	static {
		try {
			Context ctx = new InitialContext();
			ds = (DataSource) ctx.lookup("java:comp/env/jdbc/TestDB");
		} catch (NamingException e) {
			e.printStackTrace();
		}
	}

	private static final String INSERT_STMT = 
			"INSERT INTO product (prodno,prodname,prodprice,prodpic,proddesc) VALUES (product_seq.NEXTVAL, ?, ?, ?, ?)";
		private static final String GET_ALL_STMT = 
			"SELECT prodno,prodname,prodprice,prodpic,proddesc FROM product order by prodno";
		private static final String GET_ONE_STMT = 
			"SELECT prodno,prodname,prodprice,prodpic,proddesc FROM product where prodno = ?";
		private static final String DELETE = 
			"DELETE FROM product where prodno = ?";
		private static final String UPDATE = 
			"UPDATE product set prodname=?, prodprice=?, prodpic=?, proddesc=? where prodno = ?";

		@Override
		public void insert(ProductVO productVO) {

			Connection con = null;
			PreparedStatement pstmt = null;

			try {

				
				con = ds.getConnection();
				pstmt = con.prepareStatement(INSERT_STMT);

				pstmt.setString(1, productVO.getProdname());
				pstmt.setDouble(2, productVO.getProdprice());
//				pstmt.setBytes(3, productVO.getProdpic());
				pstmt.setBytes(3, null);
				pstmt.setString(4, productVO.getProddesc());
				
				pstmt.executeUpdate();
			
				// Handle any SQL errors
			} catch (SQLException se) {
				throw new RuntimeException("A database error occured. "
						+ se.getMessage());
				// Clean up JDBC resources
			} finally {
				if (pstmt != null) {
					try {
						pstmt.close();
					} catch (SQLException se) {
						se.printStackTrace(System.err);
					}
				}
				if (con != null) {
					try {
						con.close();
					} catch (Exception e) {
						e.printStackTrace(System.err);
					}
				}
			}

		}

		@Override
		public void update(ProductVO productVO) {

			Connection con = null;
			PreparedStatement pstmt = null;

			try {

				
				con = ds.getConnection();
				pstmt = con.prepareStatement(UPDATE);

				pstmt.setString(1, productVO.getProdname());
				pstmt.setDouble(2, productVO.getProdprice());
				pstmt.setBytes(3, productVO.getProdpic());
				pstmt.setString(4, productVO.getProddesc());
				pstmt.setInt(5, productVO.getProdno());
				
				pstmt.executeUpdate();
						
				// Handle any SQL errors
			} catch (SQLException se) {
				throw new RuntimeException("A database error occured. "
						+ se.getMessage());
				// Clean up JDBC resources
			} finally {
				if (pstmt != null) {
					try {
						pstmt.close();
					} catch (SQLException se) {
						se.printStackTrace(System.err);
					}
				}
				if (con != null) {
					try {
						con.close();
					} catch (Exception e) {
						e.printStackTrace(System.err);
					}
				}
			}

		}

		@Override
		public void delete(Integer prodno) {

			Connection con = null;
			PreparedStatement pstmt = null;

			try {

				
				con = ds.getConnection();
				pstmt = con.prepareStatement(DELETE);

				pstmt.setInt(1, prodno);

				pstmt.executeUpdate();
						
				// Handle any SQL errors
			} catch (SQLException se) {
				throw new RuntimeException("A database error occured. "
						+ se.getMessage());
				// Clean up JDBC resources
			} finally {
				if (pstmt != null) {
					try {
						pstmt.close();
					} catch (SQLException se) {
						se.printStackTrace(System.err);
					}
				}
				if (con != null) {
					try {
						con.close();
					} catch (Exception e) {
						e.printStackTrace(System.err);
					}
				}
			}

		}

		@Override
		public ProductVO findByPrimaryKey(Integer prodno) {

			ProductVO productVO = null;
			Connection con = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;

			try {

				
				con = ds.getConnection();
				pstmt = con.prepareStatement(GET_ONE_STMT);

				pstmt.setInt(1, prodno);

				rs = pstmt.executeQuery();

				while (rs.next()) {
					// productVo �]�٬� Domain objects
					productVO = new ProductVO();
					productVO.setProdno(rs.getInt("prodno"));
					productVO.setProdname(rs.getString("prodname"));
					productVO.setProdprice(rs.getDouble("prodprice"));
					productVO.setProdpic(rs.getBytes("prodpic"));
					productVO.setProddesc(rs.getString("proddesc"));
					
				}
						
				// Handle any SQL errors
			} catch (SQLException se) {
				throw new RuntimeException("A database error occured. "
						+ se.getMessage());
				// Clean up JDBC resources
			} finally {
				if (rs != null) {
					try {
						rs.close();
					} catch (SQLException se) {
						se.printStackTrace(System.err);
					}
				}
				if (pstmt != null) {
					try {
						pstmt.close();
					} catch (SQLException se) {
						se.printStackTrace(System.err);
					}
				}
				if (con != null) {
					try {
						con.close();
					} catch (Exception e) {
						e.printStackTrace(System.err);
					}
				}
			}
			return productVO;
		}

		@Override
		public List<ProductVO> getAll() {
			List<ProductVO> list = new ArrayList<ProductVO>();
			ProductVO productVO = null;

			Connection con = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;

			try {

				
				con = ds.getConnection();
				pstmt = con.prepareStatement(GET_ALL_STMT);
				rs = pstmt.executeQuery();

				while (rs.next()) {
					// productVO �]�٬� Domain objects
					productVO = new ProductVO();
					productVO.setProdno(rs.getInt("prodno"));
					productVO.setProdname(rs.getString("prodname"));
					productVO.setProdprice(rs.getDouble("prodprice"));
					productVO.setProdpic(rs.getBytes("prodpic"));
					productVO.setProddesc(rs.getString("proddesc"));
					
					list.add(productVO); // Store the row in the list
				}
						
				// Handle any SQL errors
			} catch (SQLException se) {
				throw new RuntimeException("A database error occured. "
						+ se.getMessage());
				// Clean up JDBC resources
			} finally {
				if (rs != null) {
					try {
						rs.close();
					} catch (SQLException se) {
						se.printStackTrace(System.err);
					}
				}
				if (pstmt != null) {
					try {
						pstmt.close();
					} catch (SQLException se) {
						se.printStackTrace(System.err);
					}
				}
				if (con != null) {
					try {
						con.close();
					} catch (Exception e) {
						e.printStackTrace(System.err);
					}
				}
			}
			return list;
		}

}