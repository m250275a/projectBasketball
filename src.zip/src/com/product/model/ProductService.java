package com.product.model;

import java.util.List;

public class ProductService {

	private ProductDAO_interface dao;

	public ProductService() {
		dao = new ProductDAO();
	}

	public ProductVO addProduct(Integer prodno, String prodname, Double prodprice,
			byte[] prodpic, String proddesc) {

		ProductVO productVO = new ProductVO();

		productVO.setProdno(prodno);
		productVO.setProdname(prodname);
		productVO.setProdprice(prodprice);
		productVO.setProdpic(prodpic);
		productVO.setProddesc(proddesc);
		dao.insert(productVO);

		return productVO;
	}

	public ProductVO updateProduct(Integer prodno, String prodname, Double prodprice,
			byte[] prodpic, String proddesc) {

		ProductVO productVO = new ProductVO();

		productVO.setProdno(prodno);
		productVO.setProdname(prodname);
		productVO.setProdprice(prodprice);
		productVO.setProdpic(prodpic);
		productVO.setProddesc(proddesc);
		dao.update(productVO);

		return productVO;
	}

	public void deleteProduct(Integer prodno) {
		dao.delete(prodno);
	}

	public ProductVO getOneProduct(Integer prodno) {
		return dao.findByPrimaryKey(prodno);
	}

	public List<ProductVO> getAll() {
		return dao.getAll();
	}
}
