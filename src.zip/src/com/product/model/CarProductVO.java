package com.product.model;
import java.sql.Date;

public class CarProductVO implements java.io.Serializable{
	private Integer prodno;
	private String prodname;
	private Double prodprice;
	private String proddesc;
	private Integer prodqnty;

	public Integer getProdno() {
		return prodno;
	}
	public void setProdno(Integer prodno) {
		this.prodno = prodno;
	}
	public String getProdname() {
		return prodname;
	}
	public void setProdname(String prodname) {
		this.prodname = prodname;
	}
	public Double getProdprice() {
		return prodprice;
	}
	public void setProdprice(Double prodprice) {
		this.prodprice = prodprice;
	}
	public String getProddesc() {
		return proddesc;
	}
	public void setProddesc(String proddesc) {
		this.proddesc = proddesc;
	}
	public Integer getProdqnty() {
		return prodqnty;
	}
	public void setProdqnty(Integer prodqnty) {
		this.prodqnty = prodqnty;
	}
	
	@Override
	public boolean equals(Object that) {
		// TODO Auto-generated method stub
		if(that instanceof CarProductVO) {
			CarProductVO carProductVO = (CarProductVO) that;
            return this.prodno.intValue() == carProductVO.prodno.intValue();
        }
        return false;
	}
	
	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return this.prodno.intValue();
	}
	
}
