package com.challteam.model;

public class ChallteamVO implements java.io.Serializable{
	private Integer teamno;
	private Integer challmode;
	public Integer getTeamno() {
		return teamno;
	}
	public void setTeamno(Integer teamno) {
		this.teamno = teamno;
	}
	public Integer getChallmode() {
		return challmode;
	}
	public void setChallmode(Integer challmode) {
		this.challmode = challmode;
	}
		
}
