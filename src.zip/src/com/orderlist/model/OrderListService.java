package com.orderlist.model;

import java.util.List;
import java.util.Map;

public class OrderListService {

	private OrderListDAO_interface dao;

	public OrderListService() {
		dao = new OrderListDAO();
	}

	public OrderListVO addOrderList(Integer ordlstno, Integer ordedno, Integer prodno, Integer ordedqnty) {

		OrderListVO orderListVO = new OrderListVO();

		orderListVO.setOrdlstno(ordlstno);
		orderListVO.setOrdedno(ordedno);
		orderListVO.setProdno(prodno);
		orderListVO.setOrdedqnty(ordedqnty);
		dao.insert(orderListVO);

		return orderListVO;
	}

	public boolean updateOrderList(Integer ordlstno, Integer ordedno, Integer prodno, Integer ordedqnty, Integer sums) {

		OrderListVO orderListVO = new OrderListVO();

		orderListVO.setOrdlstno(ordlstno);
		orderListVO.setOrdedno(ordedno);
		orderListVO.setProdno(prodno);
		orderListVO.setOrdedqnty(ordedqnty);

		return dao.update(orderListVO, sums);
	}

	public void deleteOrderList(Integer ordlstno) {
		dao.delete(ordlstno);
	}

	public OrderListVO getOneOrderList(Integer ordlstno) {
		return dao.findByPrimaryKey(ordlstno);
	}

	public List<OrderListVO> getAll() {
		return dao.getAll();
	}
	
}
