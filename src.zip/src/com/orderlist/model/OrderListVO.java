package com.orderlist.model;
import java.sql.Date;
import java.sql.Timestamp;

import com.product.model.CarProductVO;

public class OrderListVO implements java.io.Serializable{
	private Integer ordlstno;
	private Integer ordedno;
	private Integer prodno;
	private Integer ordedqnty;

	public Integer getOrdlstno() {
		return ordlstno;
	}
	public void setOrdlstno(Integer ordlstno) {
		this.ordlstno = ordlstno;
	}
	public Integer getOrdedno() {
		return ordedno;
	}
	public void setOrdedno(Integer ordedno) {
		this.ordedno = ordedno;
	}
	public Integer getProdno() {
		return prodno;
	}
	public void setProdno(Integer prodno) {
		this.prodno = prodno;
	}
	public Integer getOrdedqnty() {
		return ordedqnty;
	}
	public void setOrdedqnty(Integer ordedqnty) {
		this.ordedqnty = ordedqnty;
	}
	
	@Override
	public boolean equals(Object that) {
		// TODO Auto-generated method stub
		if(that instanceof OrderListVO) {
			OrderListVO orderListVO = (OrderListVO) that;
            return this.ordlstno.intValue() == orderListVO.ordlstno.intValue();
        }
        return false;
	}
	
	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return this.ordlstno.intValue();
	}
	
}
