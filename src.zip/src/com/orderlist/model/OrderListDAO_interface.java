package com.orderlist.model;

import java.util.*;

public interface OrderListDAO_interface {
          public void insert(OrderListVO orderListVO);
          public boolean update(OrderListVO orderListVO, Integer sums);
          public void delete(Integer ordlstno);
          public OrderListVO findByPrimaryKey(Integer ordlstno);
          public List<OrderListVO> getAll();
}
