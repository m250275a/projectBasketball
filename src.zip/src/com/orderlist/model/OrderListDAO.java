package com.orderlist.model;

import java.util.*;
import java.sql.*;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;


public class OrderListDAO implements OrderListDAO_interface {

	// �@�����ε{����,�w��@�Ӹ�Ʈw ,�@�Τ@��DataSource�Y�i
	private static DataSource ds = null;
	static {
		try {
			Context ctx = new InitialContext();
			ds = (DataSource) ctx.lookup("java:comp/env/jdbc/TestDB");
		} catch (NamingException e) {
			e.printStackTrace();
		}
	}

		private static final String INSERT_STMT = 
			"INSERT INTO orderList (ordlstno,ordedno,prodno,ordedqnty) VALUES (orderList_seq.NEXTVAL, ?, ?, ?)";
		private static final String GET_ALL_STMT = 
				"SELECT ordlstno,ordedno,prodno,ordedqnty FROM orderList order by ordlstno";
		private static final String GET_ONE_STMT = 
				"SELECT ordlstno,ordedno,prodno,ordedqnty FROM orderList where ordlstno = ?";
		private static final String DELETE = 
			"DELETE FROM orderList where ordlstno = ?";
		private static final String UPDATE = 
			"UPDATE orderList set ordedno=?, prodno=?, ordedqnty=? where ordlstno = ?";
		private static final String UPDATE_ORDERED_SUM = 
				"UPDATE ordered set sums=? where ordedno = ?";

		@Override
		public void insert(OrderListVO orderListVO) {

			Connection con = null;
			PreparedStatement pstmt = null;

			try {

				
				con = ds.getConnection();
				pstmt = con.prepareStatement(INSERT_STMT);

				pstmt.setInt(1, orderListVO.getOrdedno());
				pstmt.setInt(2, orderListVO.getProdno());
				pstmt.setInt(3, orderListVO.getOrdedqnty());
				
				pstmt.executeUpdate();
						
				// Handle any SQL errors
			} catch (SQLException se) {
				throw new RuntimeException("A database error occured. "
						+ se.getMessage());
				// Clean up JDBC resources
			} finally {
				if (pstmt != null) {
					try {
						pstmt.close();
					} catch (SQLException se) {
						se.printStackTrace(System.err);
					}
				}
				if (con != null) {
					try {
						con.close();
					} catch (Exception e) {
						e.printStackTrace(System.err);
					}
				}
			}

		}

		@Override
		public boolean update(OrderListVO orderListVO, Integer sums) {

			Connection con = null;
			PreparedStatement pstmt = null;

			try {

				
				con = ds.getConnection();
				
				// 1���]�w�� pstm.executeUpdate()���e
				con.setAutoCommit(false);
				
				pstmt = con.prepareStatement(UPDATE);
				pstmt.setInt(1, orderListVO.getOrdedno());
				pstmt.setInt(2, orderListVO.getProdno());
				pstmt.setInt(3, orderListVO.getOrdedqnty());
				pstmt.setInt(4, orderListVO.getOrdlstno());
				pstmt.executeUpdate();
				
				PreparedStatement pstmt2 = con.prepareStatement(UPDATE_ORDERED_SUM);
				pstmt2.setInt(1, sums);
				pstmt2.setInt(2, orderListVO.getOrdedno());
				pstmt2.executeUpdate();
				
				// 2���]�w�� pstm.executeUpdate()����
				con.commit();
				con.setAutoCommit(true);
				
				// Handle any SQL errors
			} catch (SQLException se) {
				if (con != null) {
					try {
						// 3���]�w�����exception�o�ͮɤ�catch�϶���
						con.rollback();
					} catch (SQLException excep) {
						throw new RuntimeException("rollback error occured. "
								+ excep.getMessage());
					}
				}
				throw new RuntimeException("A database error occured. "
						+ se.getMessage());
			} finally {
				if (pstmt != null) {
					try {
						pstmt.close();
					} catch (SQLException se) {
						se.printStackTrace(System.err);
					}
				}
				if (con != null) {
					try {
						con.close();
					} catch (Exception e) {
						e.printStackTrace(System.err);
					}
				}
			}
			return true;
		}

		@Override
		public void delete(Integer ordlstno) {

			Connection con = null;
			PreparedStatement pstmt = null;

			try {

				
				con = ds.getConnection();
				pstmt = con.prepareStatement(DELETE);

				pstmt.setInt(1, ordlstno);

				pstmt.executeUpdate();
						
				// Handle any SQL errors
			} catch (SQLException se) {
				throw new RuntimeException("A database error occured. "
						+ se.getMessage());
				// Clean up JDBC resources
			} finally {
				if (pstmt != null) {
					try {
						pstmt.close();
					} catch (SQLException se) {
						se.printStackTrace(System.err);
					}
				}
				if (con != null) {
					try {
						con.close();
					} catch (Exception e) {
						e.printStackTrace(System.err);
					}
				}
			}

		}

		@Override
		public OrderListVO findByPrimaryKey(Integer ordlstno) {

			OrderListVO orderListVO = null;
			Connection con = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;

			try {

				
				con = ds.getConnection();
				pstmt = con.prepareStatement(GET_ONE_STMT);

				pstmt.setInt(1, ordlstno);

				rs = pstmt.executeQuery();

				while (rs.next()) {
					// orderListVo �]�٬� Domain objects
					orderListVO = new OrderListVO();
					orderListVO.setOrdlstno(rs.getInt("ordlstno"));
					orderListVO.setOrdedno(rs.getInt("ordedno"));
					orderListVO.setProdno(rs.getInt("prodno"));
					orderListVO.setOrdedqnty(rs.getInt("ordedqnty"));
				}
						
				// Handle any SQL errors
			} catch (SQLException se) {
				throw new RuntimeException("A database error occured. "
						+ se.getMessage());
				// Clean up JDBC resources
			} finally {
				if (rs != null) {
					try {
						rs.close();
					} catch (SQLException se) {
						se.printStackTrace(System.err);
					}
				}
				if (pstmt != null) {
					try {
						pstmt.close();
					} catch (SQLException se) {
						se.printStackTrace(System.err);
					}
				}
				if (con != null) {
					try {
						con.close();
					} catch (Exception e) {
						e.printStackTrace(System.err);
					}
				}
			}
			return orderListVO;
		}

		@Override
		public List<OrderListVO> getAll() {
			List<OrderListVO> list = new ArrayList<OrderListVO>();
			OrderListVO orderListVO = null;

			Connection con = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;

			try {

				
				con = ds.getConnection();
				pstmt = con.prepareStatement(GET_ALL_STMT);
				rs = pstmt.executeQuery();

				while (rs.next()) {
					// orderListVO �]�٬� Domain objects
					orderListVO = new OrderListVO();
					orderListVO.setOrdlstno(rs.getInt("ordlstno"));
					orderListVO.setOrdedno(rs.getInt("ordedno"));
					orderListVO.setProdno(rs.getInt("prodno"));
					orderListVO.setOrdedqnty(rs.getInt("ordedqnty"));
					
					list.add(orderListVO); // Store the row in the list
				}
				
				// Handle any SQL errors
			} catch (SQLException se) {
				throw new RuntimeException("A database error occured. "
						+ se.getMessage());
				// Clean up JDBC resources
			} finally {
				if (rs != null) {
					try {
						rs.close();
					} catch (SQLException se) {
						se.printStackTrace(System.err);
					}
				}
				if (pstmt != null) {
					try {
						pstmt.close();
					} catch (SQLException se) {
						se.printStackTrace(System.err);
					}
				}
				if (con != null) {
					try {
						con.close();
					} catch (Exception e) {
						e.printStackTrace(System.err);
					}
				}
			}
			return list;
		}

}