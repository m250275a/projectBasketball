package com.friend.model;

public class FriendVO implements java.io.Serializable{
	private Integer memno;
	private Integer frino;	
	public Integer getMemno() {
		return memno;
	}
	public void setMemno(Integer memno) {
		this.memno = memno;
	}
	public Integer getFrino() {
		return frino;
	}
	public void setFrino(Integer frino) {
		this.frino = frino;
	}
	
	
	
}
