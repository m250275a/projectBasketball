package com.team.model;

import java.util.Date;
import java.util.List;
import java.util.Set;

import com.game.model.GameVO;
import com.memsche.model.MemScheVO;
import com.memteam.model.MemteamVO;
import com.report.model.ReportVO;
import com.teammsg.model.TeamMsgVO;

public class TeamService {

	private TeamDAO_interface dao;

	public TeamService() {
		dao = new TeamDAO();
	}

	public TeamVO addTeam(String teamname, Integer courtno, byte[] teamlogo, String gender, String teamlevel,
			Integer gametype, Integer wins, Integer lose,Integer teamadmin) {

		TeamVO teamVO = new TeamVO();

		teamVO.setTeamname(teamname);
		teamVO.setCourtno(courtno);
		teamVO.setTeamlogo(teamlogo);
		teamVO.setGender(gender);
		teamVO.setTeamlevel(teamlevel);
		teamVO.setGametype(gametype);
		teamVO.setWins(wins);
		teamVO.setLose(lose);
		teamVO.setTeamadmin(teamadmin);
		dao.insert(teamVO);

		return teamVO;
	}

	public TeamVO updateTeam(Integer teamno, String teamname, Integer courtno, byte[] teamlogo, String gender,
			String teamlevel, Integer gametype, Integer wins, Integer lose,Integer teamadmin) {

		TeamVO teamVO = new TeamVO();

		teamVO.setTeamno(teamno);
		teamVO.setTeamname(teamname);
		teamVO.setCourtno(courtno);
		teamVO.setTeamlogo(teamlogo);
		teamVO.setGender(gender);
		teamVO.setTeamlevel(teamlevel);
		teamVO.setGametype(gametype);
		teamVO.setWins(wins);
		teamVO.setLose(lose);
		teamVO.setTeamadmin(teamadmin);
		dao.update(teamVO);

		return teamVO;
	}

	public void deleteTeam(Integer teamno) {

		dao.delete(teamno);
	}

	public TeamVO getOneTeam(Integer teamno) {

		return dao.findByPrimaryKey(teamno);
	}

	public List<TeamVO> getAll() {

		return dao.getAll();
	}
	//�βy����Ӳy���d��
	public Set<TeamMsgVO> getTeammsgByTeamno(Integer teamno) {
		return dao.getTeammsgByTeamno(teamno);
	}
	////�βy����y���������ɨ�
	public Set<GameVO> getGameByTeamno(Integer teamno){
		return dao.getGameByTeamno(teamno);
	}
	//��y�����W
	public List<TeamVO> getAllTeamName(){
		return dao.getAllTeamName();
	}
	//�βy������鶤��
	public List<MemteamVO> getAllMemByTeamno(Integer teamno){
		return dao.getAllMemByTeamno(teamno);
	}
	//�s�W�ӳ���,�y���ӳ���+1
	public TeamVO addTeamWins(Integer teamno){
		return dao.addTeamWins(teamno);
	}
	//�s�W�ѳ���,�y���ѳ�+1
	public TeamVO addTeamLose(Integer teamno){
		return dao.addTeamLose(teamno);
	}
	//�䰣�F�����H�~������
	public List<MemteamVO> getOther(Integer teamno,Integer memno){
		return dao.getOther(teamno,memno);
	}
	//��y���d��list��
	public List<TeamMsgVO> getMsgByTeam(Integer teamno){
		return dao.getMsgByTeam(teamno);
	}
	//���X�s�},�Q�D�Ԥ譶���X�{�X�l
	public List<GameVO> showTeamnoLogo(Integer teamno){
		return dao.showTeamnoLogo(teamno);
	} 
	//�d��Ĺ�o�Ӳy�����X�Ԫ����
	public List<GameVO> getWinTeams(Integer teamno){
		return dao.getWinTeams(teamno);
	}
	 //Ĺ�a�v�Q,�ק��a����
    public TeamVO updateWinVpno(Integer teamno,String winvpno) {

		TeamVO teamVO = new TeamVO();

		teamVO.setTeamno(teamno);
		teamVO.setWinvpno(winvpno);
		dao.updateWinVpno(teamVO);

		return teamVO;
	}
    //���o�ק�᪺����������
    public TeamVO getOneOfTeam(Integer teamno){
    	return dao.getOneOfTeam(teamno);
    }
    
    //�䶤����{��
    public List<MemScheVO> getTeamSche(java.sql.Date mdate ,java.sql.Date mdate1){
    	return dao.getTeamSche(mdate,mdate1);
    }
  //�ۤv�y�������ɨ�
    public List<GameVO> getAllTeamGame(Integer teamno){
    	return dao.getAllTeamGame(teamno);
    }
    //�y���n����������
    public int getCount(Integer memedno){
    	
    	return dao.getCount(memedno);
    }
  //�s��y��
    public TeamVO EditTeam(Integer teamno, String teamname, byte[] teamlogo,
    		Integer gametype, Integer teamadmin) {

		TeamVO teamVO = new TeamVO();

		teamVO.setTeamno(teamno);
		teamVO.setTeamname(teamname);
		teamVO.setTeamlogo(teamlogo);
		teamVO.setGametype(gametype);
		teamVO.setTeamadmin(teamadmin);
		dao.EditTeam(teamVO);

		return teamVO;
	}
}
