package com.team.model;

import java.util.*;
import java.util.Date;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.game.model.GameVO;
import com.memsche.model.MemScheVO;
import com.memteam.model.MemteamVO;
import com.report.model.ReportVO;
import com.sun.crypto.provider.RSACipher;
import com.teammsg.model.TeamMsgVO;

import java.io.*;
import java.sql.*;

public class TeamDAO implements TeamDAO_interface {

	// �@�����ε{����,�w��@�Ӹ�Ʈw ,�@�Τ@��DataSource�Y�i
	private static DataSource ds = null;
	public static int GeneratedKeys;
	static {
		try {
			Context ctx = new InitialContext();
			ds = (DataSource) ctx.lookup("java:comp/env/jdbc/TestDB");
		} catch (NamingException e) {
			e.printStackTrace();
		}
	}

	private static final String INSERT_STMT = "INSERT INTO Team (teamno,teamname,courtno,teamlogo,gender,teamlevel,gametype,wins,lose,teamadmin) VALUES (team_seq.NEXTVAL, ?, ?, ?, ?, ?, ?, ?, ?,?)";
	private static final String GET_ALL_STMT = "SELECT teamno,teamname,courtno,teamlogo,gender,teamlevel,gametype,wins,lose,teamadmin FROM Team order by teamno";
	private static final String GET_ONE_STMT = "SELECT teamno,teamname,courtno,teamlogo,gender,teamlevel,gametype,wins,lose,teamadmin FROM Team where teamno =?";
	private static final String DELETE = "DELETE FROM Team where teamno =?";
	private static final String UPDATE = "UPDATE Team set teamname=?, courtno=?, teamlogo=?, gender=?, teamlevel=?, gametype=?, wins=?, lose=?, teamadmin=? where teamno= ?";

	// �H�y���W�٧�y���d��
	private static final String GET_TEAMMSG_BYTEAMNO = "SELECT * FROM Teammsg WHERE teamno=? ORDER BY msgdate DESC";
	// �βy����y���������ɨ�
	private static final String GET_GAME_BYTEAMNO = "SELECT gameno,gamedate,memno,teamno,teamno2,courtno,gametype,gameresult FROM Game WHERE (teamno=? or teamno2=?) and gameresult is null";
	// ��y�����W
	private static final String GET_ALL_TEAMNAME = "SELECT teamno,teamname FROM Team";
	// �βy���䶤��
	private static final String GET_ALL_MEM_BYTEAMNO = "SELECT memno,teamno FROM Memteam WHERE teamno=? ";
	// �s�W�ӳ���,�y���ӳ���+1
	private static final String GET_ONE_TEAMWINS = "SELECT * FROM Team WHERE teamno=?";
	// �ӳ���+1
	private static final String UPDATE_WINS = "UPDATE Team SET wins=? WHERE teamno=?";
	// �s�W�ѳ���,�y���ѳ�+1
	private static final String GET_ONE_TEAMLOSE = "SELECT * FROM Team WHERE teamno=?";
	// �ѳ���+1
	private static final String UPDATE_LOSE = "UPDATE Team SET lose=? WHERE teamno=?";
	// �䰣�F�����H�~������
	private static final String GET_OTHER = "SELECT memno,teamno FROM Memteam WHERE teamno=? and not(memno=?)";
	// ���X�s�},�Q�D�Ԥ譶���X�{�X�l
	private static final String GET_TEAMLOGO_BY_TEAMNO2 = "SELECT teamno2,gametype FROM Game WHERE (((gametype=2 or gametype=5) and gameresult is null)and teamno2 is not null) and teamno=?";
	// �d��Ĺ�o�Ӳy�����X�Ԫ����
	private static final String GET_WIN_TEAMS_BYGAMETYPE = "SELECT teamno2, gametype FROM Game WHERE ((gametype=2 or gametype=5) and gameresult='��') and teamno=?";
	// Ĺ�a�v�Q,�ק��a����
	private static final String UPDATE_WIN_VPNO = "UPDATE Team SET winvpno=? WHERE teamno=?";
	// ���o����ק�᪺�������
	private static final String GET_ONE_OF_TEAM = "SELECT teamno,teamname,courtno,teamlogo,gender,teamlevel,gametype,wins,lose,teamadmin,winvpno FROM Team where teamno =?";
	// �䶤����{��
	private static final String GET_TEAM_SCHE = "SELECT memsche,memno,free,mdate FROM Memsche  where mdate between ? and ? ORDER BY free,mdate";
	// �ۤv�y�������ɨ�
	private static final String GET_ALL_TEAM_GAME = "SELECT gameno,gamedate,memno,teamno,teamno2,courtno,gametype,gameresult FROM Game WHERE (teamno=? or teamno2=?) ORDER BY gamedate DESC";
	// �y���n����������
	private static final String GET_TEAM_REPOET_COUNTS = "select count(*) from Report where result like '�f�ֳq�L' and memedno=?";
	// �s��y��
	private static final String EDIE_TEAM = "UPDATE Team set teamname=?, teamlogo=?, gametype=?, teamadmin=? where teamno= ?";

	@Override
	public void insert(TeamVO teamVO) {

		Connection con = null;
		PreparedStatement pstmt = null;

		try {

			con = ds.getConnection();
			int cols[] = { 1 }; // �� int cols[] = {1};
			pstmt = con.prepareStatement(INSERT_STMT, cols);

			pstmt.setString(1, teamVO.getTeamname());
			pstmt.setInt(2, teamVO.getCourtno());
			pstmt.setBytes(3, teamVO.getTeamlogo());
			pstmt.setString(4, teamVO.getGender());
			pstmt.setString(5, teamVO.getTeamlevel());
			pstmt.setInt(6, teamVO.getGametype());
			pstmt.setInt(7, teamVO.getWins());
			pstmt.setInt(8, teamVO.getLose());
			pstmt.setInt(9, teamVO.getTeamadmin());

			pstmt.executeUpdate();
			// �o��O�ۼW�D����
			ResultSet rsKeys = pstmt.getGeneratedKeys();
			ResultSetMetaData rsmd = rsKeys.getMetaData();
			int columnCount = rsmd.getColumnCount();
			if (rsKeys.next()) {
				do {
					for (int i = 1; i <= columnCount; i++) {
						GeneratedKeys = rsKeys.getInt(i);
						System.out.println("�ۼW�D���(i=" + i + ") = " + GeneratedKeys + "(��s�W���\���y���s��)");
					}
				} while (rsKeys.next());
			} else {
				System.out.println("NO KEYS WERE GENERATED.");
			}
			// Handle any SQL errors
		} catch (SQLException se) {
			throw new RuntimeException("A database error occured. " + se.getMessage());
			// Clean up JDBC resources
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					e.printStackTrace(System.err);
				}
			}
		}

	}

	@Override
	public void update(TeamVO teamVO) {
		Connection con = null;
		PreparedStatement pstmt = null;

		try {

			con = ds.getConnection();
			pstmt = con.prepareStatement(UPDATE);

			pstmt.setString(1, teamVO.getTeamname());
			pstmt.setInt(2, teamVO.getCourtno());
			pstmt.setBytes(3, teamVO.getTeamlogo());
			pstmt.setString(4, teamVO.getGender());
			pstmt.setString(5, teamVO.getTeamlevel());
			pstmt.setInt(6, teamVO.getGametype());
			pstmt.setInt(7, teamVO.getWins());
			pstmt.setInt(8, teamVO.getLose());
			pstmt.setInt(9, teamVO.getTeamadmin());
			pstmt.setInt(10, teamVO.getTeamno());

			pstmt.executeUpdate();

			// Handle any SQL errors
		} catch (SQLException se) {
			throw new RuntimeException("A database error occured. " + se.getMessage());
			// Clean up JDBC resources
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					e.printStackTrace(System.err);
				}
			}
		}
	}

	@Override
	public void delete(Integer teamno) {
		Connection con = null;
		PreparedStatement pstmt = null;

		try {

			con = ds.getConnection();
			pstmt = con.prepareStatement(DELETE);

			pstmt.setInt(1, teamno);

			pstmt.executeUpdate();

			// Handle any SQL errors
		} catch (SQLException se) {
			throw new RuntimeException("A database error occured. " + se.getMessage());
			// Clean up JDBC resources
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					e.printStackTrace(System.err);
				}
			}
		}
	}

	@Override
	public TeamVO findByPrimaryKey(Integer teamno) {

		TeamVO teamVO = null;
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {

			con = ds.getConnection();
			pstmt = con.prepareStatement(GET_ONE_STMT);

			pstmt.setInt(1, teamno);

			rs = pstmt.executeQuery();

			while (rs.next()) {
				// empVo �]�٬� Domain objects
				teamVO = new TeamVO();
				teamVO.setTeamno(rs.getInt("teamno"));
				teamVO.setTeamname(rs.getString("teamname"));
				teamVO.setCourtno(rs.getInt("courtno"));
				teamVO.setTeamlogo(rs.getBytes("teamlogo"));
				teamVO.setGender(rs.getString("gender"));
				teamVO.setTeamlevel(rs.getString("teamlevel"));
				teamVO.setGametype(rs.getInt("gametype"));
				teamVO.setWins(rs.getInt("wins"));
				teamVO.setLose(rs.getInt("lose"));
				teamVO.setTeamadmin(rs.getInt("teamadmin"));
			}

			// Handle any SQL errors
		} catch (SQLException se) {
			throw new RuntimeException("A database error occured. " + se.getMessage());
			// Clean up JDBC resources
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					e.printStackTrace(System.err);
				}
			}
		}
		return teamVO;
	}

	@Override
	public List<TeamVO> getAll() {
		List<TeamVO> list = new ArrayList<TeamVO>();
		TeamVO teamVO = null;

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {

			con = ds.getConnection();
			pstmt = con.prepareStatement(GET_ALL_STMT);

			rs = pstmt.executeQuery();

			while (rs.next()) {
				// empVO �]�٬� Domain objects
				teamVO = new TeamVO();
				teamVO.setTeamno(rs.getInt("teamno"));
				teamVO.setTeamname(rs.getString("teamname"));
				teamVO.setCourtno(rs.getInt("courtno"));
				teamVO.setTeamlogo(rs.getBytes("teamlogo"));
				teamVO.setGender(rs.getString("gender"));
				teamVO.setTeamlevel(rs.getString("teamlevel"));
				teamVO.setGametype(rs.getInt("gametype"));
				teamVO.setWins(rs.getInt("wins"));
				teamVO.setLose(rs.getInt("lose"));
				teamVO.setTeamadmin(rs.getInt("teamadmin"));
				list.add(teamVO); // Store the row in the vector
			}

			// Handle any SQL errors
		} catch (SQLException se) {
			throw new RuntimeException("A database error occured. " + se.getMessage());
			// Clean up JDBC resources
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					e.printStackTrace(System.err);
				}
			}
		}
		return list;
	}

	// �βy���s���d�y���d��
	@Override
	public Set<TeamMsgVO> getTeammsgByTeamno(Integer teamno) {
		// TODO Auto-generated method stub

		Set<TeamMsgVO> set = new LinkedHashSet<TeamMsgVO>();
		TeamMsgVO teamMsgVO = null;

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {

			con = ds.getConnection();
			pstmt = con.prepareStatement(GET_TEAMMSG_BYTEAMNO);
			pstmt.setInt(1, teamno);
			rs = pstmt.executeQuery();

			while (rs.next()) {

				teamMsgVO = new TeamMsgVO();
				teamMsgVO.setMsgno(rs.getInt("msgno"));
				teamMsgVO.setMemno(rs.getInt("memno"));
				teamMsgVO.setTeamno(rs.getInt("teamno"));
				teamMsgVO.setMsg(rs.getString("msg"));
				teamMsgVO.setMsgdate(rs.getTimestamp("msgdate"));
				set.add(teamMsgVO);// Store the row in the list

			}
		} catch (SQLException se) {
			throw new RuntimeException("A database error occured. " + se.getMessage());
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					e.printStackTrace(System.err);
				}
			}
		}
		return set;
	}

	@Override
	//// �βy����y���������ɨ�
	public Set<GameVO> getGameByTeamno(Integer teamno) {
		// TODO Auto-generated method stub

		Set<GameVO> set = new LinkedHashSet<GameVO>();
		GameVO gameVO = null;

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Integer teamno2 = teamno;
		try {

			con = ds.getConnection();
			pstmt = con.prepareStatement(GET_GAME_BYTEAMNO);
			pstmt.setInt(1, teamno);
			pstmt.setInt(2, teamno2);

			rs = pstmt.executeQuery();
			while (rs.next()) {
				gameVO = new GameVO();
				gameVO.setGameno(rs.getInt("gameno"));
				gameVO.setGamedate(rs.getDate("gamedate"));
				gameVO.setMemno(rs.getInt("memno"));
				gameVO.setTeamno(rs.getInt("teamno"));
				gameVO.setTeamno2(rs.getInt("teamno2"));
				gameVO.setCourtno(rs.getInt("courtno"));
				gameVO.setGametype(rs.getInt("gametype"));
				gameVO.setGameresult(rs.getString("gameresult"));
				set.add(gameVO);// Store the row in the list
			}
		} catch (SQLException se) {
			throw new RuntimeException("A database error occured. " + se.getMessage());
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					e.printStackTrace(System.err);
				}
			}
		}
		return set;
	}

	// ��y�����W
	@Override
	public List<TeamVO> getAllTeamName() {
		// TODO Auto-generated method stub

		List<TeamVO> list = new ArrayList<TeamVO>();
		TeamVO teamVO = null;

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {

			con = ds.getConnection();
			pstmt = con.prepareStatement(GET_ALL_TEAMNAME);

			rs = pstmt.executeQuery();

			while (rs.next()) {
				// empVO �]�٬� Domain objects
				teamVO = new TeamVO();
				teamVO.setTeamno(rs.getInt("teamno"));
				teamVO.setTeamname(rs.getString("teamname"));

				list.add(teamVO); // Store the row in the vector
			}

			// Handle any SQL errors
		} catch (SQLException se) {
			throw new RuntimeException("A database error occured. " + se.getMessage());
			// Clean up JDBC resources
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					e.printStackTrace(System.err);
				}
			}
		}
		return list;
	}

	// �βy���䶤��
	@Override
	public List<MemteamVO> getAllMemByTeamno(Integer teamno) {
		// TODO Auto-generated method stub

		List<MemteamVO> list = new ArrayList<MemteamVO>();
		MemteamVO memteamVO = null;

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {

			con = ds.getConnection();
			pstmt = con.prepareStatement(GET_ALL_MEM_BYTEAMNO);
			pstmt.setInt(1, teamno);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				// empVO �]�٬� Domain objects
				memteamVO = new MemteamVO();
				memteamVO.setMemno(rs.getInt("memno"));
				memteamVO.setTeamno(rs.getInt("teamno"));

				list.add(memteamVO); // Store the row in the vector
			}

			// Handle any SQL errors
		} catch (SQLException se) {
			throw new RuntimeException("A database error occured. " + se.getMessage());
			// Clean up JDBC resources
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					e.printStackTrace(System.err);
				}
			}
		}
		return list;
	}

	// �s�W�ӳ���,�y���ӳ���+1
	@SuppressWarnings("resource")
	@Override
	public TeamVO addTeamWins(Integer teamno) {
		// TODO Auto-generated method stub

		TeamVO teamVO = null;
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {

			con = ds.getConnection();
			pstmt = con.prepareStatement(GET_ONE_TEAMWINS);

			pstmt.setInt(1, teamno);

			rs = pstmt.executeQuery();

			while (rs.next()) {
				// empVo �]�٬� Domain objects
				teamVO = new TeamVO();
				teamVO.setTeamno(rs.getInt("teamno"));
				teamVO.setTeamname(rs.getString("teamname"));
				teamVO.setCourtno(rs.getInt("courtno"));
				teamVO.setTeamlogo(rs.getBytes("teamlogo"));
				teamVO.setGender(rs.getString("gender"));
				teamVO.setTeamlevel(rs.getString("teamlevel"));
				teamVO.setGametype(rs.getInt("gametype"));
				teamVO.setWins(rs.getInt("wins") + 1);
				teamVO.setLose(rs.getInt("lose"));
				teamVO.setTeamadmin(rs.getInt("teamadmin"));
			}

			// �ӳ���+1
			pstmt = con.prepareStatement(UPDATE_WINS);
			pstmt.setInt(1, teamVO.getWins());
			pstmt.setInt(2, teamVO.getTeamno());
			pstmt.executeUpdate();

			// Handle any SQL errors
		} catch (SQLException se) {
			throw new RuntimeException("A database error occured. " + se.getMessage());
			// Clean up JDBC resources
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					e.printStackTrace(System.err);
				}
			}
		}
		return teamVO;
	}

	// �s�W�ѳ�,�y���ѳ���+1
	@SuppressWarnings("resource")
	@Override
	public TeamVO addTeamLose(Integer teamno) {
		// TODO Auto-generated method stub
		TeamVO teamVO = null;
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {

			con = ds.getConnection();
			pstmt = con.prepareStatement(GET_ONE_TEAMLOSE);

			pstmt.setInt(1, teamno);

			rs = pstmt.executeQuery();

			while (rs.next()) {
				// empVo �]�٬� Domain objects
				teamVO = new TeamVO();
				teamVO.setTeamno(rs.getInt("teamno"));
				teamVO.setTeamname(rs.getString("teamname"));
				teamVO.setCourtno(rs.getInt("courtno"));
				teamVO.setTeamlogo(rs.getBytes("teamlogo"));
				teamVO.setGender(rs.getString("gender"));
				teamVO.setTeamlevel(rs.getString("teamlevel"));
				teamVO.setGametype(rs.getInt("gametype"));
				teamVO.setWins(rs.getInt("wins"));
				teamVO.setLose(rs.getInt("lose") + 1);
				teamVO.setTeamadmin(rs.getInt("teamadmin"));
			}

			// �ѳ���+1
			pstmt = con.prepareStatement(UPDATE_LOSE);
			pstmt.setInt(1, teamVO.getLose());
			pstmt.setInt(2, teamVO.getTeamno());
			pstmt.executeUpdate();

			// Handle any SQL errors
		} catch (SQLException se) {
			throw new RuntimeException("A database error occured. " + se.getMessage());
			// Clean up JDBC resources
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					e.printStackTrace(System.err);
				}
			}
		}
		return teamVO;
	}

	// �䰣�F�����H�~������
	@Override
	public List<MemteamVO> getOther(Integer teamno, Integer memno) {
		// TODO Auto-generated method stub
		List<MemteamVO> list = new ArrayList<MemteamVO>();
		MemteamVO memteamVO = null;

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {

			con = ds.getConnection();
			pstmt = con.prepareStatement(GET_OTHER);
			pstmt.setInt(1, teamno);
			pstmt.setInt(2, memno);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				// empVO �]�٬� Domain objects
				memteamVO = new MemteamVO();
				memteamVO.setMemno(rs.getInt("memno"));
				memteamVO.setTeamno(rs.getInt("teamno"));

				list.add(memteamVO); // Store the row in the vector
			}

			// Handle any SQL errors
		} catch (SQLException se) {
			throw new RuntimeException("A database error occured. " + se.getMessage());
			// Clean up JDBC resources
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					e.printStackTrace(System.err);
				}
			}
		}
		return list;
	}

	// ��y���d��list��
	@Override
	public List<TeamMsgVO> getMsgByTeam(Integer teamno) {
		// TODO Auto-generated method stub
		List<TeamMsgVO> list = new ArrayList<TeamMsgVO>();
		TeamMsgVO teamMsgVO = null;

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {

			con = ds.getConnection();
			pstmt = con.prepareStatement(GET_TEAMMSG_BYTEAMNO);
			pstmt.setInt(1, teamno);
			rs = pstmt.executeQuery();

			while (rs.next()) {

				teamMsgVO = new TeamMsgVO();
				teamMsgVO.setMsgno(rs.getInt("msgno"));
				teamMsgVO.setMemno(rs.getInt("memno"));
				teamMsgVO.setTeamno(rs.getInt("teamno"));
				teamMsgVO.setMsg(rs.getString("msg"));
				teamMsgVO.setMsgdate(rs.getTimestamp("msgdate"));
				list.add(teamMsgVO);// Store the row in the list

			}
		} catch (SQLException se) {
			throw new RuntimeException("A database error occured. " + se.getMessage());
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					e.printStackTrace(System.err);
				}
			}
		}
		return list;
	}

	// ���X�s�},�Q�D�Ԥ譶���X�{�X�l
	@Override
	public List<GameVO> showTeamnoLogo(Integer teamno) {
		// TODO Auto-generated method stub
		List<GameVO> list = new ArrayList<GameVO>();
		GameVO gameVO = null;

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {

			con = ds.getConnection();
			pstmt = con.prepareStatement(GET_TEAMLOGO_BY_TEAMNO2);
			pstmt.setInt(1, teamno);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				// empVO �]�٬� Domain objects
				gameVO = new GameVO();
				gameVO.setTeamno2(rs.getInt("teamno2"));
				gameVO.setGametype(rs.getInt("gametype"));
				list.add(gameVO); // Store the row in the vector
			}

			// Handle any SQL errors
		} catch (SQLException se) {
			throw new RuntimeException("A database error occured. " + se.getMessage());
			// Clean up JDBC resources
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					e.printStackTrace(System.err);
				}
			}
		}
		return list;
	}

	// �d��Ĺ�o�Ӳy�����X�Ԫ����
	@Override
	public List<GameVO> getWinTeams(Integer teamno) {
		// TODO Auto-generated method stub
		List<GameVO> list = new ArrayList<GameVO>();
		GameVO gameVO = null;

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {

			con = ds.getConnection();
			pstmt = con.prepareStatement(GET_WIN_TEAMS_BYGAMETYPE);
			pstmt.setInt(1, teamno);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				// empVO �]�٬� Domain objects
				gameVO = new GameVO();
				gameVO.setTeamno2(rs.getInt("teamno2"));
				gameVO.setGametype(rs.getInt("gametype"));
				list.add(gameVO); // Store the row in the vector
			}

			// Handle any SQL errors
		} catch (SQLException se) {
			throw new RuntimeException("A database error occured. " + se.getMessage());
			// Clean up JDBC resources
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					e.printStackTrace(System.err);
				}
			}
		}
		return list;
	}

	// Ĺ�a�v�Q,�ק��a����
	@Override
	public void updateWinVpno(TeamVO teamVO) {
		// TODO Auto-generated method stub
		Connection con = null;
		PreparedStatement pstmt = null;

		try {

			con = ds.getConnection();
			pstmt = con.prepareStatement(UPDATE_WIN_VPNO);

			pstmt.setString(1, teamVO.getWinvpno());
			pstmt.setInt(2, teamVO.getTeamno());

			pstmt.executeUpdate();

			// Handle any SQL errors
		} catch (SQLException se) {
			throw new RuntimeException("A database error occured. " + se.getMessage());
			// Clean up JDBC resources
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					e.printStackTrace(System.err);
				}
			}
		}
	}

	// ���o����ק�᪺�������
	@Override
	public TeamVO getOneOfTeam(Integer teamno) {
		// TODO Auto-generated method stub
		TeamVO teamVO = null;
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {

			con = ds.getConnection();
			pstmt = con.prepareStatement(GET_ONE_OF_TEAM);

			pstmt.setInt(1, teamno);

			rs = pstmt.executeQuery();

			while (rs.next()) {
				// empVo �]�٬� Domain objects
				teamVO = new TeamVO();
				teamVO.setTeamno(rs.getInt("teamno"));
				teamVO.setTeamname(rs.getString("teamname"));
				teamVO.setCourtno(rs.getInt("courtno"));
				teamVO.setTeamlogo(rs.getBytes("teamlogo"));
				teamVO.setGender(rs.getString("gender"));
				teamVO.setTeamlevel(rs.getString("teamlevel"));
				teamVO.setGametype(rs.getInt("gametype"));
				teamVO.setWins(rs.getInt("wins"));
				teamVO.setLose(rs.getInt("lose"));
				teamVO.setTeamadmin(rs.getInt("teamadmin"));
				teamVO.setWinvpno(rs.getString("winvpno"));
			}
			// Handle any SQL errors
		} catch (SQLException se) {
			throw new RuntimeException("A database error occured. " + se.getMessage());
			// Clean up JDBC resources
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					e.printStackTrace(System.err);
				}
			}
		}
		return teamVO;
	}

	// �䶤����{��
	@Override
	public List<MemScheVO> getTeamSche(java.sql.Date mdate, java.sql.Date mdate1) {
		// TODO Auto-generated method stub
		List<MemScheVO> list = new ArrayList<MemScheVO>();
		MemScheVO memScheVO = null;

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {

			con = ds.getConnection();
			pstmt = con.prepareStatement(GET_TEAM_SCHE);

			pstmt.setDate(1, mdate);
			pstmt.setDate(2, mdate1);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				// empVO �]�٬� Domain objects
				memScheVO = new MemScheVO();
				memScheVO.setMemsche(rs.getInt("memsche"));
				memScheVO.setMemno(rs.getInt("memno"));
				memScheVO.setFree(rs.getInt("free"));
				memScheVO.setMdate(rs.getDate("mdate"));
				list.add(memScheVO); // Store the row in the list
			}

			// Handle any driver errors
		} catch (SQLException se) {
			throw new RuntimeException("A database error occured. " + se.getMessage());
			// Clean up JDBC resources
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					e.printStackTrace(System.err);
				}
			}
		}
		return list;
	}

	// �ۤv�y�������ɨ�
	@Override
	public List<GameVO> getAllTeamGame(Integer teamno) {
		// TODO Auto-generated method stub
		List<GameVO> list = new ArrayList<GameVO>();
		GameVO gameVO = null;

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Integer teamno2 = teamno;
		try {

			con = ds.getConnection();
			pstmt = con.prepareStatement(GET_ALL_TEAM_GAME);
			pstmt.setInt(1, teamno);
			pstmt.setInt(2, teamno2);

			rs = pstmt.executeQuery();
			while (rs.next()) {
				gameVO = new GameVO();
				gameVO.setGameno(rs.getInt("gameno"));
				gameVO.setGamedate(rs.getDate("gamedate"));
				gameVO.setMemno(rs.getInt("memno"));
				gameVO.setTeamno(rs.getInt("teamno"));
				gameVO.setTeamno2(rs.getInt("teamno2"));
				gameVO.setCourtno(rs.getInt("courtno"));
				gameVO.setGametype(rs.getInt("gametype"));
				gameVO.setGameresult(rs.getString("gameresult"));
				list.add(gameVO);// Store the row in the list
			}
		} catch (SQLException se) {
			throw new RuntimeException("A database error occured. " + se.getMessage());
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					e.printStackTrace(System.err);
				}
			}
		}
		return list;
	}

	// �y���n���O������
	@Override
	public int getCount(Integer memedno) {
		// TODO Auto-generated method stub
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int count = 0;
		try {

			con = ds.getConnection();
			pstmt = con.prepareStatement(GET_TEAM_REPOET_COUNTS);

			pstmt.setInt(1, memedno);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				count = rs.getInt(1);
			}
			// Handle any driver errors
		} catch (SQLException se) {
			throw new RuntimeException("A database error occured. " + se.getMessage());
			// Clean up JDBC resources
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					e.printStackTrace(System.err);
				}
			}
		}
		return count;
	}

	// �s��y��
	@Override
	public void EditTeam(TeamVO teamVO) {
		// TODO Auto-generated method stub
		Connection con = null;
		PreparedStatement pstmt = null;

		try {

			con = ds.getConnection();
			pstmt = con.prepareStatement(EDIE_TEAM);

			pstmt.setString(1, teamVO.getTeamname());
			pstmt.setBytes(2, teamVO.getTeamlogo());
			pstmt.setInt(3, teamVO.getGametype());
			pstmt.setInt(4, teamVO.getTeamadmin());
			pstmt.setInt(5, teamVO.getTeamno());

			pstmt.executeUpdate();

			// Handle any SQL errors
		} catch (SQLException se) {
			throw new RuntimeException("A database error occured. " + se.getMessage());
			// Clean up JDBC resources
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					e.printStackTrace(System.err);
				}
			}
		}

	}

}