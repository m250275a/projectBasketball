package com.team.model;


public class TeamVO implements java.io.Serializable{
	private Integer teamno;
	private String teamname;
	private Integer courtno;
	private byte[] teamlogo;
	private String gender;
	private String teamlevel;
	private Integer gametype;
	private Integer wins;
	private Integer lose;
	private Integer teamadmin;
	private String winvpno;
	
	
	
	
	public Integer getTeamno() {
		return teamno;
	}
	public void setTeamno(Integer teamno) {
		this.teamno = teamno;
	}
	public String getTeamname() {
		return teamname;
	}
	public void setTeamname(String teamname) {
		this.teamname = teamname;
	}
	public Integer getCourtno() {
		return courtno;
	}
	public void setCourtno(Integer courtno) {
		this.courtno = courtno;
	}
	public byte[] getTeamlogo() {
		return teamlogo;
	}
	public void setTeamlogo(byte[] teamlogo) {
		this.teamlogo = teamlogo;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getTeamlevel() {
		return teamlevel;
	}
	public void setTeamlevel(String teamlevel) {
		this.teamlevel = teamlevel;
	}
	public Integer getGametype() {
		return gametype;
	}
	public void setGametype(Integer gametype) {
		this.gametype = gametype;
	}
	public Integer getWins() {
		return wins;
	}
	public void setWins(Integer wins) {
		this.wins = wins;
	}
	public Integer getLose() {
		return lose;
	}
	public void setLose(Integer lose) {
		this.lose = lose;
	}
	public Integer getTeamadmin() {
		return teamadmin;
	}
	public void setTeamadmin(Integer teamadmin) {
		this.teamadmin = teamadmin;
	}	
	/**
	 * @return the winvpno
	 */
	public String getWinvpno() {
		return winvpno;
	}
	/**
	 * @param winvpno the winvpno to set
	 */
	public void setWinvpno(String winvpno) {
		this.winvpno = winvpno;
	}
}