package com.team.controller;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Date;
import java.util.LinkedList;
import java.util.*;
import java.util.Set;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import org.apache.tomcat.jni.File;

import com.game.model.GameService;
import com.game.model.*;
import com.member.model.MemberService;
import com.member.model.MemberVO;
import com.memsche.model.MemScheVO;
import com.memteam.model.MemteamService;
import com.memteam.model.MemteamVO;
import com.report.model.*;
import com.sun.java.util.*;
import com.sun.org.apache.xalan.internal.xsltc.dom.SAXImpl.NamespaceWildcardIterator;
import com.sun.xml.internal.ws.org.objectweb.asm.Label;
import com.team.model.TeamDAO;
import com.team.model.TeamService;
import com.team.model.TeamVO;
import com.teammsg.model.TeamMsgVO;
import com.videopicture.model.VideoPictureVO;

import sun.print.resources.serviceui;

@MultipartConfig(fileSizeThreshold = 1 * 1024, maxFileSize = 5 * 1024 * 1024, maxRequestSize = 20 * 1024 * 1024)
// ���ƾڶq�j��fileSizeThreshold�ȮɡA���e�N�Q�g�J�Ϻ�
// �W�ǹL�{���L�׬O��Ӥ��W�LmaxFileSize�ȡA�Ϊ̤W�Ǫ��`�q�j��maxRequestSize �ȳ��|�ߥXIllegalStateException
// ���`

public class TeamServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		doPost(req, res);
	}

	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {

		req.setCharacterEncoding("UTF-8");
		String action = req.getParameter("action");
		HttpSession session = req.getSession();

		if ("getOne_For_Display".equals(action)) { // �Ӧ�select_page.jsp���ШD

			List<String> errorMsgs = new LinkedList<String>();
			// Store this set in the request scope, in case we need to
			// send the ErrorPage view.
			req.setAttribute("errorMsgs", errorMsgs);

			try {
				/***************************
				 * 1.�����ШD�Ѽ� - ��J�榡�����~�B�z
				 **********************/
				String str = req.getParameter("teamno");
				if (str == null || (str.trim()).length() == 0) {
					errorMsgs.add("�п�J�y���s��");
				}
				// Send the use back to the form, if there were errors

				Integer teamno = null;
				try {
					teamno = new Integer(str);
				} catch (Exception e) {
					errorMsgs.add("�y���s���榡�����T");
				}
				// Send the use back to the form, if there were errors
				if (!errorMsgs.isEmpty()) {
					RequestDispatcher failureView = req.getRequestDispatcher("/front-end/errormsg.jsp");
					failureView.forward(req, res);
					return;// �{�����_
				}

				/***************************
				 * 2.�}�l�d�߸��
				 *****************************************/
				TeamService teamSvc = new TeamService();
				TeamVO teamVO = teamSvc.getOneTeam(teamno);
				if (teamVO == null) {
					errorMsgs.add("�d�L���");
				}
				// Send the use back to the form, if there were errors
				if (!errorMsgs.isEmpty()) {
					RequestDispatcher failureView = req.getRequestDispatcher("/front-end/errormsg.jsp");
					failureView.forward(req, res);
					return;// �{�����_
				}

				/***************************
				 * 3.�d�ߧ���,�ǳ����(Send the Success view)
				 *************/
				session.setAttribute("teamVO", teamVO); // ��Ʈw���X��teamVO����,�s�Jreq
				String url = "/front-end/teampage.jsp";
				RequestDispatcher successView = req.getRequestDispatcher(url); // ���\���teampage.jsp
				successView.forward(req, res);

				/*************************** ��L�i�઺���~�B�z *************************************/
			} catch (Exception e) {
				errorMsgs.add("�L�k���o���:" + e.getMessage());
				RequestDispatcher failureView = req.getRequestDispatcher("/front-end/errormsg.jsp");
				failureView.forward(req, res);
			}
		}

		if ("getOne_For_Update".equals(action)) { // �Ӧ�listAllTeam.jsp

			List<String> errorMsgs = new LinkedList<String>();
			// Store this set in the request scope, in case we need to
			// send the ErrorPage view.
			req.setAttribute("errorMsgs", errorMsgs);

			String requestURL = req.getParameter("requestURL"); // �e�X�ק諸�ӷ��������|:
																// �i�ର�i/emp/listAllTeam.jsp�j
			try {
				/***************************
				 * 1.�����ШD�Ѽ�
				 ****************************************/
				Integer teamno = new Integer(req.getParameter("teamno"));

				/***************************
				 * 2.�}�l�d�߸��
				 ****************************************/
				TeamService teamSvc = new TeamService();
				TeamVO teamVO = teamSvc.getOneTeam(teamno);

				/***************************
				 * 3.�d�ߧ���,�ǳ����(Send the Success view)
				 ************/
				req.setAttribute("teamVO", teamVO); // ��Ʈw���X��teamVO����,�s�Jreq
				String url = "/team/update_team_input.jsp";
				RequestDispatcher successView = req.getRequestDispatcher(url); // ���\���update_team_input.jsp
				successView.forward(req, res);

				/*************************** ��L�i�઺���~�B�z ************************************/
			} catch (Exception e) {
				errorMsgs.add("�ק��ƨ��X�ɥ���:" + e.getMessage());
				RequestDispatcher failureView = req.getRequestDispatcher(requestURL);
				failureView.forward(req, res);
			}
		}

		if ("update".equals(action)) { // �Ӧ�update_team_input.jsp���ШD

			List<String> errorMsgs = new LinkedList<String>();
			// Store this set in the request scope, in case we need to
			// send the ErrorPage view.
			req.setAttribute("errorMsgs", errorMsgs);

			String requestURL = req.getParameter("requestURL"); // �e�X�ק諸�ӷ��������|:
																// �i�ର�i/team/listAllTeam.jsp�j
			try {
				/***************************
				 * 1.�����ШD�Ѽ� - ��J�榡�����~�B�z
				 **********************/

				Integer teamno = new Integer(req.getParameter("teamno").trim());
				String teamname = req.getParameter("teamname").trim();

				Integer courtno = null;
				try {
					courtno = new Integer(req.getParameter("courtno").trim());
				} catch (NumberFormatException e) {
					courtno = 0;
					errorMsgs.add("�п�J�y���s��");
				}

				String gender = req.getParameter("gender");

				String teamlevel = req.getParameter("teamlevel");
				Integer gametype = new Integer(req.getParameter("gametype"));
				Integer wins = new Integer(req.getParameter("wins"));
				Integer lose = new Integer(req.getParameter("lose"));
				Integer teamadmin = new Integer(req.getParameter("teamadmin"));

				// �ק�teamlogo
				Part part = req.getPart("teamlogo");
				InputStream file = part.getInputStream();
				byte[] teamlogo = new byte[file.available()];
				file.read(teamlogo);

				TeamVO teamVO = new TeamVO();
				teamVO.setTeamname(teamname);
				teamVO.setCourtno(courtno);
				teamVO.setTeamlogo(teamlogo);
				teamVO.setGender(gender);
				teamVO.setTeamlevel(teamlevel);
				teamVO.setGametype(gametype);
				teamVO.setWins(wins);
				teamVO.setLose(lose);
				teamVO.setTeamadmin(teamadmin);
				file.close();

				// Send the use back to the form, if there were errors
				if (!errorMsgs.isEmpty()) {
					req.setAttribute("teamVO", teamVO); // �t����J�榡���~��teamVO����,�]�s�Jreq
					RequestDispatcher failureView = req.getRequestDispatcher("/team/update_team_input.jsp");
					failureView.forward(req, res);
					return; // �{�����_
				}

				/***************************
				 * 2.�}�l�ק���
				 *****************************************/
				TeamService teamSvc = new TeamService();
				teamVO = teamSvc.updateTeam(teamno, teamname, courtno, teamlogo, gender, teamlevel, gametype, wins,
						lose, teamadmin);

				/***************************
				 * 3.�ק粒��,�ǳ����(Send the Success view)
				 *************/

				String url = requestURL;
				RequestDispatcher successView = req.getRequestDispatcher(url); // �ק令�\��,���^�e�X�ק諸�ӷ�����
				successView.forward(req, res);

				/*************************** ��L�i�઺���~�B�z *************************************/

			} catch (Exception e) {
				errorMsgs.add("�ק��ƥ���:" + e.getMessage());
				RequestDispatcher failureView = req.getRequestDispatcher("/team/update_team_input.jsp");
				failureView.forward(req, res);
			}
		}

		if ("insert".equals(action)) { // �Ӧ�addTeam.jsp���ШD

			List<String> errorMsgs = new LinkedList<String>();
			// Store this set in the request scope, in case we need to
			// send the ErrorPage view.
			req.setAttribute("errorMsgs", errorMsgs);

			try {
				/***********************
				 * 1.�����ШD�Ѽ� - ��J�榡�����~�B�z
				 *************************/
				String teamname = req.getParameter("teamname").trim();
				Integer courtno = null;
				try {
					courtno = new Integer(req.getParameter("courtno").trim());
				} catch (NumberFormatException e) {
					courtno = 0;
					errorMsgs.add("�п�J�y���s��");
				}

				// �s�Wteamlogo
				Part part = req.getPart("teamlogo");
				InputStream file = part.getInputStream();
				byte[] teamlogo = new byte[file.available()];
				file.read(teamlogo);

				String gender = req.getParameter("gender");
				String teamlevel = req.getParameter("teamlevel");
				Integer gametype = new Integer(req.getParameter("gametype"));
				Integer wins = new Integer(req.getParameter("wins"));
				Integer lose = new Integer(req.getParameter("lose"));
				Integer teamadmin = new Integer(req.getParameter("teamadmin"));

				TeamVO teamVO = new TeamVO();
				teamVO.setTeamname(teamname);
				teamVO.setCourtno(courtno);
				teamVO.setTeamlogo(teamlogo);
				teamVO.setGender(gender);
				teamVO.setTeamlevel(teamlevel);
				teamVO.setGametype(gametype);
				teamVO.setWins(wins);
				teamVO.setLose(lose);
				teamVO.setTeamadmin(teamadmin);
				file.close();

				// Send the use back to the form, if there were errors
				if (!errorMsgs.isEmpty()) {
					req.setAttribute("teamVO", teamVO); // �t����J�榡���~��teamVO����,�]�s�Jreq
					RequestDispatcher failureView = req.getRequestDispatcher("/team/addTeam.jsp");
					failureView.forward(req, res);
					return;
				}

				/***************************
				 * 2.�}�l�s�W���
				 ***************************************/
				TeamService teamSvc = new TeamService();
				teamVO = teamSvc.addTeam(teamname, courtno, teamlogo, gender, teamlevel, gametype, wins, lose,
						teamadmin);
				if(teamVO != null){
					errorMsgs.add("�y���s�W�o!");
				}
				// �P�ɷs�W��Memteam��table;
				MemteamService memteamSvc = new MemteamService();
				memteamSvc.addMemteam(teamadmin, TeamDAO.GeneratedKeys);

				/***************************
				 * 3.�s�W����,�ǳ����(Send the Success view)
				 ***********/
				String url = "/front-end/memberPage.jsp";
				RequestDispatcher successView = req.getRequestDispatcher(url); // �s�W���\�����listAllTeam.jsp
				successView.forward(req, res);

				/*************************** ��L�i�઺���~�B�z **********************************/

			} catch (Exception e) {
				errorMsgs.add(e.getMessage());
				RequestDispatcher failureView = req.getRequestDispatcher("/team/addTeam.jsp");
				failureView.forward(req, res);
			}
		}

		// �y���s����y���d��
		if ("getTeammsgByTeamno".equals(action)) { // �Ӧ�teammsg.jsp���ШD

			List<String> errorMsgs = new LinkedList<String>();
			// Store this set in the request scope, in case we need to
			// send the ErrorPage view.
			req.setAttribute("errorMsgs", errorMsgs);
			try {
				/***************************
				 * 1.�����ШD�Ѽ� - ��J�榡�����~�B�z
				 **********************/
				Integer teamno = new Integer(req.getParameter("teamno"));

				/***************************
				 * 2.�}�l�d�߸��
				 *****************************************/
				TeamService teamSvc = new TeamService();
				Set<TeamMsgVO> set = teamSvc.getTeammsgByTeamno(teamno);
				if ((set == null) || (set.size() == 0)) {
					errorMsgs.add("�d�L���");
				}
				// Send the use back to the form, if there were errors
				if (!errorMsgs.isEmpty()) {
					String url = "/front-end/msgload.jsp";
					RequestDispatcher failureView = req.getRequestDispatcher(url);
					failureView.forward(req, res);
					return;// �{�����_
				}

				/***************************
				 * 3.�d�ߧ���,�ǳ����(Send the Success view)
				 *************/
				req.setAttribute("oneteammsg", set); // ��Ʈw���X��teammsgVO����,�s�Jreq
				String url = "/front-end/msgload.jsp";
				RequestDispatcher successView = req.getRequestDispatcher(url); // ���\���teammsg.jsp
				successView.forward(req, res);

				/*************************** ��L�i�઺���~�B�z *************************************/
			} catch (Exception e) {
				errorMsgs.add("�L�k���o���:" + e.getMessage());
				String url = "/front-end/msgload.jsp";
				RequestDispatcher failureView = req.getRequestDispatcher(url);
				failureView.forward(req, res);
			}
		}

		// �βy����y���������ɨ�
		if ("getGameByTeamno".equals(action)) { // �Ӧ�teamWins_page.jsp���ШD
			List<String> errorMsgs = new LinkedList<String>();
			// Store this set in the request scope, in case we need to
			// send the ErrorPage view.
			req.setAttribute("errorMsgs", errorMsgs);

			try {
				/***************************
				 * 1.�����ШD�Ѽ� - ��J�榡�����~�B�z
				 **********************/
				Integer teamno = new Integer(req.getParameter("teamno"));
				/***************************
				 * 2.�}�l�d�߸��
				 *****************************************/
				TeamService teamSvc = new TeamService();
				Set<GameVO> set = teamSvc.getGameByTeamno(teamno);

				if ((set == null) || (set.size() == 0)) {
					errorMsgs.add("�d�L���O�������ɸ��");
				}
				// Send the use back to the form, if there were errors
				if (!errorMsgs.isEmpty()) {
					String url = "/front-end/teamWins.jsp";
					RequestDispatcher failureView = req.getRequestDispatcher(url);
					failureView.forward(req, res);
					return;// �{�����_
				}
				/***************************
				 * 3.�d�ߧ���,�ǳ����(Send the Success view)
				 *************/
				req.setAttribute("teamwin", set); // ��Ʈw���X��gameVO����,�s�Jreq
				String url = "/front-end/teamWins.jsp";
				RequestDispatcher successView = req.getRequestDispatcher(url); // ���\���teamWin.jsp
				successView.forward(req, res);

				/*************************** ��L�i�઺���~�B�z *************************************/
			} catch (Exception e) {
				errorMsgs.add("�L�k���o���:" + e.getMessage());
				String url = "/front-end/teamWins.jsp";
				RequestDispatcher failureView = req.getRequestDispatcher(url);
				failureView.forward(req, res);
			}
		}

		// �βy����|��
		if ("getAllMemByTeamno".equals(action)) { // �Ӧ�teampage.jsp���ШD

			List<String> errorMsgs = new LinkedList<String>();
			// Store this set in the request scope, in case we need to
			// send the ErrorPage view.
			req.setAttribute("errorMsgs", errorMsgs);
			try {
				/***************************
				 * 1.�����ШD�Ѽ� - ��J�榡�����~�B�z
				 **********************/
				Integer teamno = new Integer(req.getParameter("teamno"));

				/***************************
				 * 2.�}�l�d�߸��
				 *****************************************/
				TeamService teamSvc = new TeamService();
				List<MemteamVO> memlist = teamSvc.getAllMemByTeamno(teamno);
				if ((memlist == null) || (memlist.size() == 0)) {
					errorMsgs.add("�d�L���");
				}
				// Send the use back to the form, if there were errors
				if (!errorMsgs.isEmpty()) {
					String url = "/front-end/memList.jsp";
					RequestDispatcher failureView = req.getRequestDispatcher(url);
					failureView.forward(req, res);
					return;// �{�����_
				}

				/***************************
				 * 3.�d�ߧ���,�ǳ����(Send the Success view)
				 *************/
				req.setAttribute("memlist", memlist); // ��Ʈw���X��teamVO����,�s�Jreq
				String url = "/front-end/memList.jsp";
				RequestDispatcher successView = req.getRequestDispatcher(url); // ���\���memList.jsp||memShit.jsp
				successView.forward(req, res);

				/*************************** ��L�i�઺���~�B�z *************************************/
			} catch (Exception e) {
				errorMsgs.add("�L�k���o���:" + e.getMessage());
				String url = "/front-end/memList.jsp";
				RequestDispatcher failureView = req.getRequestDispatcher(url);
				failureView.forward(req, res);
			}
		}
		
		// �Ψ�y���s�����y���|��
				if ("getAllMemByTeamno2".equals(action)) { // �Ӧ�teampage.jsp���ШD
					List<String> errorMsgs = new LinkedList<String>();
					// Store this set in the request scope, in case we need to
					// send the ErrorPage view.
					req.setAttribute("errorMsgs", errorMsgs);
					try {
						/***************************
						 * 1.�����ШD�Ѽ� - ��J�榡�����~�B�z
						 **********************/
						List<GameVO> courtgamelist = (ArrayList<GameVO>) session.getAttribute("courtgamelist");
						Integer gameno = new Integer(req.getParameter("gameno"));
						GameVO selectedGameVO = null;
						for (GameVO gameVO : courtgamelist){
							if(gameno.intValue() == gameVO.getGameno().intValue()){
								selectedGameVO = gameVO;
								System.out.println("Yes");
							}
						}
						
						System.out.println(selectedGameVO.getGameno());
						
						Integer teamno  = selectedGameVO.getTeamno();
						Integer teamno2 = selectedGameVO.getTeamno2();
						System.out.println("teamno  : " + teamno);
						System.out.println("teamno2 : " + teamno2);

						/***************************
						 * 2.�}�l�d�߸��
						 *****************************************/
						TeamService teamSvc = new TeamService();
						List<MemteamVO> teamMemlist  = teamSvc.getAllMemByTeamno(teamno);
						List<MemteamVO> teamMemlist2 = teamSvc.getAllMemByTeamno(teamno2);
						
						MemberService memSvc = new MemberService();
						
						List<MemberVO> gameTeamMemlist = new ArrayList<MemberVO>();
						for(MemteamVO memteamVO : teamMemlist){
							Integer memno  = memteamVO.getMemno();
							MemberVO memVO = null;
							memVO = memSvc.getOneMember(memno);
							gameTeamMemlist.add(memVO);
						}
						
						List<MemberVO> gameTeamMemlist2 = new ArrayList<MemberVO>();
						for(MemteamVO memteamVO : teamMemlist2){
							Integer memno  = memteamVO.getMemno();
							MemberVO memVO = null;
							memVO = memSvc.getOneMember(memno);
							gameTeamMemlist2.add(memVO);
						}
						
						if ((gameTeamMemlist == null) || (gameTeamMemlist.size() == 0) || (gameTeamMemlist2 == null) || (gameTeamMemlist2.size() == 0)) {
							errorMsgs.add("�d�L���");
						}
						// Send the use back to the form, if there were errors
						if (!errorMsgs.isEmpty()) {
							String url = "/front-end/memList.jsp";
							RequestDispatcher failureView = req.getRequestDispatcher(url);
							failureView.forward(req, res);
							return;// �{�����_
						}

						/***************************
						 * 3.�d�ߧ���,�ǳ����(Send the Success view)
						 *************/
						session.setAttribute("gameTeamMemlist", gameTeamMemlist);
						session.setAttribute("gameTeamMemlist2", gameTeamMemlist2);// ��Ʈw���X��teamVO����,�s�Jreq
						String url = "/front-end/chatRoom.jsp";
						RequestDispatcher successView = req.getRequestDispatcher(url); // ���\���memList.jsp||memShit.jsp
						successView.forward(req, res);

						/*************************** ��L�i�઺���~�B�z *************************************/
					} catch (Exception e) {
						errorMsgs.add("�L�k���o���:" + e.getMessage());
						String url = "/front-end/memList.jsp";
						RequestDispatcher failureView = req.getRequestDispatcher(url);
						failureView.forward(req, res);
					}
				}

		// �䰣�F�����H�~������
		// TODO
		if ("getOther".equals(action)) { // �Ӧ�memlist.jsp���ШD

			List<String> errorMsgs = new LinkedList<String>();
			// Store this set in the request scope, in case we need to
			// send the ErrorPage view.
			req.setAttribute("errorMsgs", errorMsgs);
			try {
				/***************************
				 * 1.�����ШD�Ѽ� - ��J�榡�����~�B�z
				 **********************/
				Integer teamno = new Integer(req.getParameter("teamno"));
				Integer memno = new Integer(req.getParameter("memno"));
				/***************************
				 * 2.�}�l�d�߸��
				 *****************************************/
				TeamService teamSvc = new TeamService();
				List<MemteamVO> memlist = teamSvc.getOther(teamno, memno);
				if ((memlist == null) || (memlist.size() == 0)) {
					errorMsgs.add("�d�L���");
				}
				// Send the use back to the form, if there were errors
				if (!errorMsgs.isEmpty()) {
					String url = "/front-end/memList.jsp";
					RequestDispatcher failureView = req.getRequestDispatcher(url);
					failureView.forward(req, res);
					return;// �{�����_
				}

				/***************************
				 * 3.�d�ߧ���,�ǳ����(Send the Success view)
				 *************/
				req.setAttribute("memlist", memlist); // ��Ʈw���X��memteamVO����,�s�Jreq
				String url = "/front-end/memList.jsp";
				RequestDispatcher successView = req.getRequestDispatcher(url); // ���\���memList.jsp
				successView.forward(req, res);

				/*************************** ��L�i�઺���~�B�z *************************************/
			} catch (Exception e) {
				errorMsgs.add("�L�k���o���:" + e.getMessage());
				String url = "/front-end/memList.jsp";
				RequestDispatcher failureView = req.getRequestDispatcher(url);
				failureView.forward(req, res);
			}
		}
		// �T�{�O�_��Ĺ�a�y�����ݲy��
		if ("memcheck".equals(action)) {

			List<String> errorMsgs = new LinkedList<String>();
			// Store this set in the request scope, in case we need to
			// send the ErrorPage view.
			req.setAttribute("errorMsgs", errorMsgs);
			try {

				Integer memno = new Integer(req.getParameter("memno"));
				Integer teamno = new Integer(req.getParameter("teamno"));
				// ���o�|���y��
				MemteamService memteamSvc = new MemteamService();
				List<MemteamVO> memteamList = memteamSvc.getTeamBYMemno(memno);
				MemteamVO memteamVO = null;

				// ���o��L����b���X�Ԥ�Ĺ�F�ҳy�X���y��
				TeamService teamSvc = new TeamService();
				List<GameVO> winerList = teamSvc.getWinTeams(teamno);
				GameVO gameVO = null;
				// �P�_�O�_��Ĺ�a�y��
				LabA: for (int i = 0; i <= memteamList.size(); i++) {
					memteamVO = memteamList.get(i);
					Integer memteamno = memteamVO.getTeamno();
					for (int j = 0; j <= winerList.size(); j++) {
						gameVO = winerList.get(j);
						Integer winno = gameVO.getTeamno2();

						if (memteamno.equals(winno)) {
							break LabA;
						}
					}
				}

				MemberService memSvc = new MemberService();
				List<VideoPictureVO> vpList = memSvc.getTeamWinPic(memno);
				req.setAttribute("vpList", vpList);
				if ((vpList == null) || (vpList.size() == 0)) {
					errorMsgs.add("�ӥΤ�ثe�å��W�ǥ���Ϥ�");
					String url = "/front-end/winpic.jsp";
					RequestDispatcher failureView = req.getRequestDispatcher(url);
					failureView.forward(req, res);
				} else {

					String url = "/front-end/winpic.jsp";
					RequestDispatcher successView = req.getRequestDispatcher(url); // ���\���teammsg.jsp
					successView.forward(req, res);
				}
			} catch (Exception e) {
				// TODO: handle exception
				errorMsgs.add("\" �DĹ�a�y��!���ഡ�X! \"");
				String url = "/front-end/teampage.jsp";
				RequestDispatcher failureView = req.getRequestDispatcher(url);
				failureView.forward(req, res);
			}
		}
		// Ĺ�a�v�Q,�ק��a����
		if ("changpic".equals(action)) {

			List<String> errorMsgs = new LinkedList<String>();
			// Store this set in the request scope, in case we need to
			// send the ErrorPage view.
			req.setAttribute("errorMsgs", errorMsgs);
			try {

				Integer teamno = new Integer(req.getParameter("teamno"));
				String winvpno = req.getParameter("vpno");

				TeamVO teamVO = new TeamVO();
				teamVO.setTeamno(teamno);
				teamVO.setWinvpno(winvpno);

				TeamService teamSvc = new TeamService();
				teamVO = teamSvc.updateWinVpno(teamno, winvpno);

				if (teamVO != null) {
					errorMsgs.add("�󴫦��\!");
				}

				TeamService teamSvc1 = new TeamService();
				teamVO = teamSvc1.getOneOfTeam(teamno);
				session.setAttribute("teamVO", teamVO);

				String url = "/front-end/teampage.jsp";
				RequestDispatcher successView = req.getRequestDispatcher(url); // �ק令�\��,���^�e�X�ק諸�ӷ�����
				successView.forward(req, res);

			} catch (Exception e) {
				// TODO: handle exception
				errorMsgs.add("��ƿ��~");
				String url = "/front-end/winpic.jsp";
				RequestDispatcher failureView = req.getRequestDispatcher(url);
				failureView.forward(req, res);
			}
		}

		// ���o�ק�᪺����������
		if ("getOneOfTeam".equals(action)) { // �Ӧ�teamHome.jsp���ШD

			List<String> errorMsgs = new LinkedList<String>();
			// Store this set in the request scope, in case we need to
			// send the ErrorPage view.
			req.setAttribute("errorMsgs", errorMsgs);
			try {
				/***************************
				 * 1.�����ШD�Ѽ� - ��J�榡�����~�B�z
				 **********************/
				String str = req.getParameter("teamno");
				if (str == null || (str.trim()).length() == 0) {
					errorMsgs.add("�п�J�y���s��");
				}
				// Send the use back to the form, if there were errors

				Integer teamno = null;
				try {
					teamno = new Integer(str);
				} catch (Exception e) {
					errorMsgs.add("�y���s���榡�����T");
				}
				// Send the use back to the form, if there were errors
				if (!errorMsgs.isEmpty()) {
					RequestDispatcher failureView = req.getRequestDispatcher("/front-end/teamHome.jsp");
					failureView.forward(req, res);
					return;// �{�����_
				}

				/***************************
				 * 2.�}�l�d�߸��
				 *****************************************/
				TeamService teamSvc = new TeamService();
				TeamVO teamVO = teamSvc.getOneOfTeam(teamno);

				if (teamVO == null) {
					errorMsgs.add("�d�L���");
				}
				// Send the use back to the form, if there were errors
				if (!errorMsgs.isEmpty()) {
					RequestDispatcher failureView = req.getRequestDispatcher("/front-end/teamHome.jsp");
					failureView.forward(req, res);
					return;// �{�����_
				}
				session.setAttribute("teamVO", teamVO); // ��Ʈw���X��teamVO����,�s�Jreq

				/***************************
				 * 3.�d�ߧ���,�ǳ����(Send the Success view)
				 *************/
				String url = "/front-end/teampage.jsp";
				RequestDispatcher successView = req.getRequestDispatcher(url); // ���\���teampage.jsp
				successView.forward(req, res);

				/*************************** ��L�i�઺���~�B�z *************************************/
			} catch (Exception e) {
				errorMsgs.add("�L�k���o���:" + e.getMessage());
				RequestDispatcher failureView = req.getRequestDispatcher("/front-end/teamHome.jsp");
				failureView.forward(req, res);
			}
		}
		// �䶤����{��
		if ("getTeamSche".equals(action)) { // �Ӧ�memList.jsp���ШD
			List<String> errorMsgs = new LinkedList<String>();
			// Store this set in the request scope, in case we need to
			// send the ErrorPage view.
			req.setAttribute("errorMsgs", errorMsgs);
			try {
				/***************************
				 * 1.�����ШD�Ѽ� - ��J�榡�����~�B�z
				 **********************/
				Integer teamno = new Integer(req.getParameter("teamno"));

				java.sql.Date mdate = java.sql.Date.valueOf(req.getParameter("mdate").trim());
				java.sql.Date mdate1 = java.sql.Date.valueOf(req.getParameter("mdate1").trim());
				/***************************
				 * 2.�}�l�d�߸��
				 *****************************************/
				TeamService teamSvc = new TeamService();
				List<MemteamVO> memteamList = teamSvc.getAllMemByTeamno(teamno);

				req.setAttribute("memteamList", memteamList); // ��Ʈw���X��memteamVO����,�s�Jreq

				/***************************
				 * 3.�d�ߧ���,�ǳ����(Send the Success view)
				 *************/

				TeamService teamscheSvc = new TeamService();
				List<MemScheVO> teamscheList = teamscheSvc.getTeamSche(mdate, mdate1);
				req.setAttribute("teamscheList", teamscheList); // ��Ʈw���X��memscheVO����,�s�Jreq

				String url = "/front-end/memList.jsp";
				RequestDispatcher successView = req.getRequestDispatcher(url); // ���\���teammsg.jsp
				successView.forward(req, res);
				/*************************** ��L�i�઺���~�B�z *************************************/
			} catch (Exception e) {
				errorMsgs.add("�ثe�S��������{��");
				String url = "/front-end/memList.jsp";
				RequestDispatcher failureView = req.getRequestDispatcher(url);
				failureView.forward(req, res);
			}
		}

		// ���|�����o���ʧ@1
		if ("reportMsg".equals(action)) {
			List<String> errorMsgs = new LinkedList<String>();
			// Store this set in the request scope, in case we need to
			// send the ErrorPage view.
			req.setAttribute("errorMsgs", errorMsgs);
			try {

				Integer msgmemno = new Integer(req.getParameter("msgmemno"));
				Integer msgno = new Integer(req.getParameter("msgno"));
				session.setAttribute("msgmemno", msgmemno);
				session.setAttribute("msgno", msgno);
				String url = "/front-end/teamMsg.jsp";
				RequestDispatcher successView = req.getRequestDispatcher(url); // ���\���reportMem.jsp
				successView.forward(req, res);
			} catch (Exception e) {
				errorMsgs.add("�L�k���o���");
				String url = "/front-end/teamMsg.jsp";
				RequestDispatcher failureView = req.getRequestDispatcher(url); // ���teamMsg.jsp
				failureView.forward(req, res);
			}
		}

		// ���|�����o���ʧ@2
		if ("reportToMail".equals(action)) {
			List<String> errorMsgs = new LinkedList<String>();
			// Store this set in the request scope, in case we need to
			// send the ErrorPage view.
			req.setAttribute("errorMsgs", errorMsgs);
			try {
				Integer msgmemno = new Integer(req.getParameter("msgmemno"));
				Integer msgno = new Integer(req.getParameter("msgno"));
				Integer reportmem = new Integer(req.getParameter("reportmem"));
				String repmsg = req.getParameter("repmsg");

				String to = "aa103g05@gmail.com";
				String subject = "���|�����o�� FROM:" + reportmem;
				String messageText = "���|" + " �d���s��:" + msgno + " �d���|��:" + msgmemno + " �d�����e:" + repmsg;

				MailService reportmail = new MailService();
				reportmail.sendMail(to, subject, messageText);

				if (reportmail != null) {
					errorMsgs.add("�o�e���|����");
				}

				String url = "/front-end/reportMem.jsp";
				RequestDispatcher successView = req.getRequestDispatcher(url); // ���\���reportMem.jsp
				successView.forward(req, res);

			} catch (Exception e) {
				errorMsgs.add("�L�k���o���");
				String url = "/front-end/reportMem.jsp";
				RequestDispatcher failureView = req.getRequestDispatcher(url); // ���\���teamMsg.jsp
				failureView.forward(req, res);
			}

		}

		// ���|�y���n��
		if ("insertreport".equals(action)) { // �Ӧ�teamgame.jsp���ШD
			List<String> errorMsgs = new LinkedList<String>();
			// Store this set in the request scope, in case we need to
			// send the ErrorPage view.
			req.setAttribute("errorMsgs", errorMsgs);

			try {
				/***********************
				 * 1.�����ШD�Ѽ� - ��J�榡�����~�B�z
				 *************************/

				Integer memno = new Integer(req.getParameter("repmemberno"));
				Integer repteamno = new Integer(req.getParameter("repteamno"));
				String content = "�n��";
				Integer gameteamno = new Integer(req.getParameter("gameteamno"));
				Integer gameteamno2 = new Integer(req.getParameter("gameteamno2"));
				Integer memedno = null;

				if (repteamno.equals(gameteamno)) {
					memedno = gameteamno2;
				} else {
					memedno = gameteamno;
				}

				ReportVO reportVO = new ReportVO();

				reportVO.setMemno(memno);
				reportVO.setContent(content);
				reportVO.setMemedno(memedno);

				/***************************
				 * 2.�}�l�s�W���
				 ***************************************/
				ReportService reportSvc = new ReportService();
				reportVO = reportSvc.insertReport(memno, content, memedno);

				if (reportVO != null) {
					errorMsgs.add("���|�n���w�e�X");
					String url = "/front-end/teamgame.jsp";
					RequestDispatcher successView = req.getRequestDispatcher(url); // �s�W���\�����teamgame.jsp
					successView.forward(req, res);
				}

				/***************************
				 * 3.�s�W����,�ǳ����(Send the Success view)
				 ***********/

				/*************************** ��L�i�઺���~�B�z **********************************/
			} catch (Exception e) {
				errorMsgs.add(e.getMessage());
				RequestDispatcher failureView = req.getRequestDispatcher("/front-end/teamgame.jsp");
				failureView.forward(req, res);
			}
		}
		// �f�ֵ��G
		if ("getPass".equals(action) || "getNG".equals(action)) { // �Ӧ�backreport.jsp���ШD

			List<String> errorMsgs = new LinkedList<String>();
			// Store this set in the request scope, in case we need to
			// send the ErrorPage view.
			req.setAttribute("errorMsgs", errorMsgs);

			try {
				/***************************
				 * 1.�����ШD�Ѽ� - ��J�榡�����~�B�z
				 **********************/
				Integer reportno = new Integer(req.getParameter("reportno").trim());
				String result = req.getParameter("result").trim();

				ReportVO reportVO = new ReportVO();
				reportVO.setReportno(reportno);
				reportVO.setResult(result);

				// Send the use back to the form, if there were errors
				if (!errorMsgs.isEmpty()) {
					req.setAttribute("reportVO", reportVO); // �t����J�榡���~��reportVO����,�]�s�Jreq
					RequestDispatcher failureView = req.getRequestDispatcher("/back/backreport.jsp");
					failureView.forward(req, res);
					return; // �{�����_
				}

				/***************************
				 * 2.�}�l�ק���
				 *****************************************/
				ReportService reportSvc = new ReportService();
				reportVO = reportSvc.updateResult(reportno, result);

				/***************************
				 * 3.�ק粒��,�ǳ����(Send the Success view)
				 *************/
				req.setAttribute("reportVO", reportVO); // ��Ʈwupdate���\��,���T����empVO����,�s�Jreq
				String url = "/back/backreport.jsp";
				RequestDispatcher successView = req.getRequestDispatcher(url); // �ק令�\��,���listOneEmp.jsp
				successView.forward(req, res);
				/*************************** ��L�i�઺���~�B�z *************************************/
			} catch (Exception e) {
				errorMsgs.add("�ק��ƥ���:" + e.getMessage());
				RequestDispatcher failureView = req.getRequestDispatcher("/back/backreport.jsp");
				failureView.forward(req, res);
			}
		}

		// ��ӽФJ���|��
		if ("getJoinMem".equals(action)) { // �Ӧ�memList.jsp���ШD

			List<String> errorMsgs = new LinkedList<String>();
			// Store this set in the request scope, in case we need to
			// send the ErrorPage view.
			req.setAttribute("errorMsgs", errorMsgs);
			try {
				/***************************
				 * 1.�����ШD�Ѽ� - ��J�榡�����~�B�z
				 **********************/
				Integer teamno = new Integer(req.getParameter("teamno"));

				MemberService memberSvc = new MemberService();
				List<MemberVO> joinlist = memberSvc.getJoinMem(req.getParameter("teamno"));

				/***************************
				 * 2.�}�l�d�߸��
				 *****************************************/
				if (joinlist == null || joinlist.size() == 0) {
					errorMsgs.add("�٨S���H�n�[�J!");
				}
				// Send the use back to the form, if there were errors
				if (!errorMsgs.isEmpty()) {
					RequestDispatcher failureView = req.getRequestDispatcher("/front-end/memList.jsp");
					failureView.forward(req, res);
					return;// �{�����_
				}
				/***************************
				 * 3.�d�ߧ���,�ǳ����(Send the Success view)
				 *************/
				req.setAttribute("joinlist", joinlist); // ��Ʈw���X��memberVO����,�s�Jreq
				String url = "/front-end/memList.jsp";
				RequestDispatcher successView = req.getRequestDispatcher(url); // ���\���memList.jsp
				successView.forward(req, res);

				/*************************** ��L�i�઺���~�B�z *************************************/
			} catch (Exception e) {
				errorMsgs.add("�L�k���o���:" + e.getMessage());
				RequestDispatcher failureView = req.getRequestDispatcher("/front-end/memList.jsp");
				failureView.forward(req, res);
			}
		}
		// �s���ӤH����
		if ("DisplayTOMem".equals(action)) {

			MemberService memberSvc = new MemberService();
			MemberVO memberedVO = memberSvc.getOneMember(new Integer(req.getParameter("memno")));
			session.setAttribute("memberedVO", memberedVO);

			String url = "/front-end/memberPage2.jsp"; // �ӤH�������|
			RequestDispatcher successView = req.getRequestDispatcher(url); // ���\���
			successView.forward(req, res);
		}

		// �s��y��
		if ("updateteam".equals(action)) { // �Ӧ�teamupdate.jsp���ШD

			List<String> errorMsgs = new LinkedList<String>();
			// Store this set in the request scope, in case we need to
			// send the ErrorPage view.
			req.setAttribute("errorMsgs", errorMsgs);

			try {
				/***************************
				 * 1.�����ШD�Ѽ� - ��J�榡�����~�B�z
				 **********************/

				Integer teamno = new Integer(req.getParameter("teamno").trim());
				String teamname = req.getParameter("teamname").trim();

				Integer gametype = new Integer(req.getParameter("gametype"));

				if (gametype == 0) {
					errorMsgs.add("�|����ܤ��ɼҦ�");
					RequestDispatcher failureView = req.getRequestDispatcher("/front-end/teamupdate.jsp");
					failureView.forward(req, res);
					return;
				}
				Integer teamadmin = new Integer(req.getParameter("teamadmin"));

				// �ק�teamlogo
				Part part = req.getPart("teamlogo");
				InputStream file = part.getInputStream();
				byte[] teamlogo = new byte[file.available()];
				file.read(teamlogo);

				TeamVO teamVO = new TeamVO();
				teamVO.setTeamname(teamname);
				teamVO.setTeamlogo(teamlogo);
				teamVO.setGametype(gametype);
				teamVO.setTeamadmin(teamadmin);
				file.close();

				/***************************
				 * 2.�}�l�ק���
				 *****************************************/
				TeamService teamSvc = new TeamService();
				teamVO = teamSvc.EditTeam(teamno, teamname, teamlogo, gametype, teamadmin);
				/***************************
				 * 3.�ק粒��,�ǳ����(Send the Success view)
				 *************/

				if (teamVO != null) {
					TeamVO teamVO1 = teamSvc.getOneOfTeam(teamno);
					session.setAttribute("teamVO", teamVO1);
					errorMsgs.add("����w�s�觹��!");
				}
				String url = "/front-end/teampage.jsp";
				RequestDispatcher successView = req.getRequestDispatcher(url); // �ק令�\��,���^�e�X�ק諸�ӷ�����
				successView.forward(req, res);

				/*************************** ��L�i�઺���~�B�z *************************************/

			} catch (Exception e) {
				errorMsgs.add("�ק��ƥ���");
				RequestDispatcher failureView = req.getRequestDispatcher("/front-end/teamupdate.jsp");
				failureView.forward(req, res);
			}
		}
	}
}