package com.ordered.controller;

import java.io.*;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.*;

import javax.servlet.*;
import javax.servlet.http.*;

import com.member.model.*;
import com.ordered.model.*;
import com.orderlist.model.*;
import com.product.model.*;

public class OrderedServlet extends HttpServlet {

	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		doPost(req, res);
	}

	public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {

		req.setCharacterEncoding("UTF-8");
		String action = req.getParameter("action");
		
		
		if ("getOne_For_Display".equals(action)) { // �Ӧ�select_page.jsp���ШD

			List<String> errorMsgs = new LinkedList<String>();
			// Store this set in the request scope, in case we need to
			// send the ErrorPage view.
			req.setAttribute("errorMsgs", errorMsgs);

			try {
				/***************************1.�����ШD�Ѽ� - ��J�榡�����~�B�z**********************/
				String str = req.getParameter("ordedno");
				if (str == null || (str.trim()).length() == 0) {
					errorMsgs.add("�п�J�q��s��");
				}
				// Send the use back to the form, if there were errors
				if (!errorMsgs.isEmpty()) {
					RequestDispatcher failureView = req
							.getRequestDispatcher("/select_page.jsp");
					failureView.forward(req, res);
					return;//�{�����_
				}
				
				Integer ordedno = null;
				try {
					ordedno = new Integer(str);
				} catch (Exception e) {
					errorMsgs.add("�q��s���榡�����T");
				}
				// Send the use back to the form, if there were errors
				if (!errorMsgs.isEmpty()) {
					RequestDispatcher failureView = req
							.getRequestDispatcher("/select_page.jsp");
					failureView.forward(req, res);
					return;//�{�����_
				}
				
				/***************************2.�}�l�d�߸��*****************************************/
				OrderedService orderedSvc = new OrderedService();
				OrderedVO orderedVO = orderedSvc.getOneOrdered(ordedno);
				if (orderedVO == null) {
					errorMsgs.add("�d�L���");
				}
				// Send the use back to the form, if there were errors
				if (!errorMsgs.isEmpty()) {
					RequestDispatcher failureView = req
							.getRequestDispatcher("/select_page.jsp");
					failureView.forward(req, res);
					return;//�{�����_
				}
				
				/***************************3.�d�ߧ���,�ǳ����(Send the Success view)*************/
				req.setAttribute("orderedVO", orderedVO); // ��Ʈw���X��orderedVO����,�s�Jreq
				String url = "/ordered/listOneOrdered.jsp";
				RequestDispatcher successView = req.getRequestDispatcher(url); // ���\���listOneOrdered.jsp
				successView.forward(req, res);

				/***************************��L�i�઺���~�B�z*************************************/
			} catch (Exception e) {
				errorMsgs.add("�L�k���o���:" + e.getMessage());
				RequestDispatcher failureView = req
						.getRequestDispatcher("/select_page.jsp");
				failureView.forward(req, res);
			}
		}
		
		
	             // �|���q�� - listOrdereds_ByMemno.jsp      // �Ӧ� dept/listAllDept.jsp���ШD
			if ("listProducts_ByOrdedno_A".equals(action) || "listEmps_ByDeptno_B".equals(action)) {

				List<String> errorMsgs = new LinkedList<String>();
				req.setAttribute("errorMsgs", errorMsgs);

				try {
					/*************************** 1.�����ШD�Ѽ� ****************************************/
					Integer ordedno = new Integer(req.getParameter("ordedno"));
					Integer memno   = new Integer(req.getParameter("memno"));
					req.setAttribute("memno", memno);

					/*************************** 2.�}�l�d�߸�� ****************************************/
					OrderedService orderedSvc = new OrderedService();
					Set<OrderListVO> set = orderedSvc.getOrderListsByOrdedno(ordedno);

					/*************************** 3.�d�ߧ���,�ǳ����(Send the Success view) ************/
					req.setAttribute("listProducts_ByOrdedno", set);    // ��Ʈw���X��set����,�s�Jrequest

					String url = null;
					if ("listProducts_ByOrdedno_A".equals(action))
						url = "/ordered/listProducts_ByOrdedno.jsp";        // ���\��� dept/listEmps_ByDeptno.jsp
					else if ("listEmps_ByDeptno_B".equals(action))
						url = "/dept/listAllDept.jsp";              // ���\��� dept/listAllDept.jsp

					RequestDispatcher successView = req.getRequestDispatcher(url);
					successView.forward(req, res);

					/*************************** ��L�i�઺���~�B�z ***********************************/
				} catch (Exception e) {
					throw new ServletException(e);
				}
			}
			
		
			if ("delete_Ordered".equals(action)) { // �Ӧ�/dept/listAllDept.jsp���ШD

				List<String> errorMsgs = new LinkedList<String>();
				req.setAttribute("errorMsgs", errorMsgs);
				String requestURL = req.getParameter("requestURL");
		
				try {
					/***************************1.�����ШD�Ѽ�***************************************/
					Integer ordedno = new Integer(req.getParameter("ordedno"));
					Integer memno = new Integer(req.getParameter("memno"));
					
					/***************************2.�}�l�R�����***************************************/
					OrderedService orderedSvc = new OrderedService();
					orderedSvc.deleteOrdered(ordedno);
					
					/***************************3.�R������,�ǳ����(Send the Success view)***********/
					
					MemberService memberSvc = new MemberService();
					Set<OrderedVO> set = memberSvc.getOrderedsByMemno(memno);
					req.setAttribute("listOrdereds_ByMemno", set);
					
					String url = "/front-end/listOrdereds_ByMemno2.jsp";
					RequestDispatcher successView = req.getRequestDispatcher(url);// �R�����\��, ���\��� �^�� /dept/listAllDept.jsp
					successView.forward(req, res);
					
					/***************************��L�i�઺���~�B�z***********************************/
				} catch (Exception e) {
					errorMsgs.add("�R����ƥ���:"+e.getMessage());
					RequestDispatcher failureView = req
							.getRequestDispatcher("/member/listOrdereds_ByMemno.jsp");
					failureView.forward(req, res);
				}
			}
			
			
			if ("getOne_For_CarList".equals(action)) {
				List<String> errorMsgs = new LinkedList<String>();
				req.setAttribute("errorMsgs", errorMsgs);
				String requestURL = req.getParameter("requestURL");
				
				HttpSession session = req.getSession();
				Set<CarProductVO> carList = (LinkedHashSet<CarProductVO>) session.getAttribute("carList");
				if(carList == null){
					carList = new LinkedHashSet<CarProductVO>();
				}
				try {
					/*************************** 1.�����ШD�Ѽ� ****************************************/
					Integer prodno = new Integer(req.getParameter("prodno"));
					String prodname   = req.getParameter("prodname");
//					String p2 = new String(prodname.getBytes("ISO-8859-1"),"UTF-8");
//					System.out.println(prodname);
					Double prodprice   = new Double(req.getParameter("prodprice"));
					String proddesc = req.getParameter("proddesc");
					Integer prodqnty = new Integer(req.getParameter("prodqnty"));
					/*************************** 2.��Ʀs�JcarProductVO;�BcarProductVO�s�JcarList ****************************************/
					CarProductVO carProductVO = new CarProductVO();
					carProductVO.setProdno(prodno);
					carProductVO.setProdname(prodname);
					carProductVO.setProdprice(prodprice);
					carProductVO.setProddesc(proddesc);
					carProductVO.setProdqnty(prodqnty);
					
					if(carList.contains(carProductVO)){//�]�i�H����if~else�����I�sremove,�|�h���CarProductVO��hashCode()�Mequals().
						carList.remove(carProductVO);
						carList.add(carProductVO);
					}else{
						carList.add(carProductVO);
					}
					/*************************** 3.��Ʀs�J����,�ǳ����(Send the Success view) ************/
					int sums = 0;
					if(!carList.isEmpty()){
						for(CarProductVO carProductVO2 : carList){
							sums += (int) (carProductVO2.getProdprice()*carProductVO2.getProdqnty());} 
					}
					session.setAttribute("carList", carList);
					session.setAttribute("sums", sums);
					
					RequestDispatcher successView = req.getRequestDispatcher(requestURL);
					successView.forward(req, res);
					/*************************** ��L�i�઺���~�B�z ***********************************/
				} catch (Exception e) {
					throw new ServletException(e);
				}
			}

			
			if ("delete_carProduct".equals(action)) {

				List<String> errorMsgs = new LinkedList<String>();
				req.setAttribute("errorMsgs", errorMsgs);
				
				HttpSession session = req.getSession();
				Set<CarProductVO> carList = (LinkedHashSet<CarProductVO>) session.getAttribute("carList");
				if(carList == null){
					carList = new LinkedHashSet<CarProductVO>();
				}
				try {
					/*************************** 1.�����ШD�Ѽ� ****************************************/
					Integer prodno = new Integer(req.getParameter("prodno"));
					
					/*************************** 2.��Ʀs�JcarProductVO;�B�qcarList�R��carProductVO ****************************************/
					CarProductVO carProductVO = new CarProductVO();
					carProductVO.setProdno(prodno);
					carList.remove(carProductVO);//�w��gCarProductVO.java��equals()�MhashCode()��k�C

					/*************************** 3.��Ʀs�J����,�ǳ����(Send the Success view) ************/
					int sums = 0;
					if(!carList.isEmpty()){
						for(CarProductVO carProductVO2 : carList){
							sums += (int) (carProductVO2.getProdprice()*carProductVO2.getProdqnty());} 
					}
					session.setAttribute("carList", carList);
					session.setAttribute("sums", sums);

					RequestDispatcher successView = req.getRequestDispatcher("/front-end/shop.jsp");
					successView.forward(req, res);
					/*************************** ��L�i�઺���~�B�z ***********************************/
				} catch (Exception e) {
					throw new ServletException(e);
				}
			}
			
			
			if ("insert_carOrdered".equals(action)) { 
				List<String> errorMsgs = new LinkedList<String>();
				req.setAttribute("errorMsgs", errorMsgs);
				String requestURL = req.getParameter("requestURL");
				HttpSession session = req.getSession();
		
				try {
					/***************************1.�����ШD�Ѽ�***************************************/
					Integer memno = new Integer(session.getAttribute("memno").toString());
					Integer sums = new Integer(req.getParameter("sums"));
					Timestamp orddate = new Timestamp(System.currentTimeMillis());
					Set<CarProductVO> carList = (LinkedHashSet<CarProductVO>) session.getAttribute("carList");
					if(carList == null || carList.isEmpty()){
						errorMsgs.add("�ʪ������L�ӫ~�A���ʪ���A���b!");
						RequestDispatcher failureView = req
								.getRequestDispatcher("/front-end/shop.jsp");
						failureView.forward(req, res);
						return;
					}
					
					/***2.�}�linsert��ơA�òM���ʪ���(carList����)�A�D���ʪ����qsession�M���A�ϱo���s�i�ʶR�����ɡA���Anew�s��carList����***/
					OrderedService orderedSvc = new OrderedService();
					orderedSvc.addCarOrdered(memno,orddate,sums,carList);
					carList.clear();
					sums = 0;
					session.setAttribute("carList", carList);
					session.setAttribute("sums", sums);
					
					/***************************3.insert��Ƨ���,�ǳ����(Send the Success view)***********/
					MemberService memberSvc = new MemberService();
					Set<OrderedVO> set = memberSvc.getOrderedsByMemno(memno);
					req.setAttribute("listOrdereds_ByMemno", set);
					String url = "/front-end/listOrdereds_ByMemno2.jsp";
					RequestDispatcher successView = req.getRequestDispatcher(url);// �R�����\��, ���\��� �^�� /dept/listAllDept.jsp
					successView.forward(req, res);
					
					/***************************��L�i�઺���~�B�z***********************************/
				} catch (Exception e) {
					errorMsgs.add("�s�W�q�楢��:"+e.getMessage());
					RequestDispatcher failureView = req
							.getRequestDispatcher("/front-end/shop.jsp");
					failureView.forward(req, res);
				}
			}
			
			
			if ("showImg".equals(action)) { 

					Integer prodno = new Integer(req.getParameter("prodno"));

					ProductService productSvc = new ProductService();
					ProductVO productVO = productSvc.getOneProduct(prodno);

					res.setContentType("image/gif");
					ServletOutputStream out = res.getOutputStream();
					out.write(productVO.getProdpic());
			}


			if ("reset_car".equals(action)) {
				HttpSession session = req.getSession();
				session.removeAttribute("carList");
				int sums = 0;
				session.setAttribute("sums", sums);
				RequestDispatcher successView = req.getRequestDispatcher("/front-end/shop.jsp");
				successView.forward(req, res);
			}

			
			if ("logout".equals(action)) {
				List<String> errorMsgs = new LinkedList<String>();
				req.setAttribute("errorMsgs", errorMsgs);
				
				HttpSession session = req.getSession();
				session.invalidate();
				session = req.getSession();
				if (session.isNew()) {
					RequestDispatcher successView = req.getRequestDispatcher("/select_page.jsp");
					successView.forward(req, res);
				}else{
					errorMsgs.add("�n�X����");
					RequestDispatcher failureView = req
							.getRequestDispatcher("/front-end/shop.jsp");
					failureView.forward(req, res);
				}
			}
			
			//��ݽT�{�X�f
			if ("checkorderlist".equals(action)) { // �Ӧ�orderlist.jsp���ШD
				
				List<String> errorMsgs = new LinkedList<String>();
				// Store this set in the request scope, in case we need to
				// send the ErrorPage view.
				req.setAttribute("errorMsgs", errorMsgs);
				
				try {
					/***************************1.�����ШD�Ѽ� - ��J�榡�����~�B�z**********************/
					Integer ordedno = new Integer(req.getParameter("ordedno").trim());

					OrderedVO orderedVO = new OrderedVO();
					orderedVO.setOrdedno(ordedno);
	
					// Send the use back to the form, if there were errors
				
					/***************************2.�}�l�ק���*****************************************/
					OrderedService orderedSvc = new OrderedService();
					orderedVO = orderedSvc.updateOrderList(ordedno);
					
				 	Send se = new Send();
				 	String[] tel ={"0917768970"};
				 	String message = "�q�ʪ��ӫ~�w�X�f!";
				 	se.sendMessage(tel , message);
					
					if(orderedVO != null){
						errorMsgs.add("�ӫ~�w�T�{�X�f");
					}
					
					/***************************3.�ק粒��,�ǳ����(Send the Success view)*************/				
					
					String url = "/back-end/orderlist.jsp";
					RequestDispatcher successView = req.getRequestDispatcher(url);   // �ק令�\��,���^�e�X�ק諸�ӷ�����
					successView.forward(req, res);
	
					/***************************��L�i�઺���~�B�z*************************************/
				} catch (Exception e) {
					errorMsgs.add("�ק��ƥ���");
					RequestDispatcher failureView = req
							.getRequestDispatcher("/back-end/orderlist.jsp");
					failureView.forward(req, res);
				}
			}
	
		
//		if ("getOne_For_Update".equals(action)) { // �Ӧ�listAllEmp.jsp ��  /dept/listEmps_ByDeptno.jsp ���ШD
//
//			List<String> errorMsgs = new LinkedList<String>();
//			// Store this set in the request scope, in case we need to
//			// send the ErrorPage view.
//			req.setAttribute("errorMsgs", errorMsgs);
//			
//			String requestURL = req.getParameter("requestURL"); // �e�X�ק諸�ӷ��������|: �i�ର�i/ordered/listAllEmp.jsp�j ��  �i/dept/listEmps_ByDeptno.jsp�j �� �i /dept/listAllDept.jsp�j		
//			
//			try {
//				/***************************1.�����ШD�Ѽ�****************************************/
//				Integer ordedno = new Integer(req.getParameter("ordedno"));
//				
//				/***************************2.�}�l�d�߸��****************************************/
//				OrderedService orderedSvc = new OrderedService();
//				OrderedVO orderedVO = orderedSvc.getOneEmp(ordedno);
//								
//				/***************************3.�d�ߧ���,�ǳ����(Send the Success view)************/
//				req.setAttribute("orderedVO", orderedVO); // ��Ʈw���X��orderedVO����,�s�Jreq
//				String url = "/ordered/update_emp_input.jsp";
//				RequestDispatcher successView = req.getRequestDispatcher(url); // ���\���update_emp_input.jsp
//				successView.forward(req, res);
//
//				/***************************��L�i�઺���~�B�z************************************/
//			} catch (Exception e) {
//				errorMsgs.add("�ק��ƨ��X�ɥ���:"+e.getMessage());
//				RequestDispatcher failureView = req
//						.getRequestDispatcher(requestURL);
//				failureView.forward(req, res);
//			}
//		}
//		
//		
//		if ("update".equals(action)) { // �Ӧ�update_emp_input.jsp���ШD
//			
//			List<String> errorMsgs = new LinkedList<String>();
//			// Store this set in the request scope, in case we need to
//			// send the ErrorPage view.
//			req.setAttribute("errorMsgs", errorMsgs);
//			
//			String requestURL = req.getParameter("requestURL"); // �e�X�ק諸�ӷ��������|: �i�ର�i/ordered/listAllEmp.jsp�j ��  �i/dept/listEmps_ByDeptno.jsp�j �� �i /dept/listAllDept.jsp�j �� �i /ordered/listEmps_ByCompositeQuery.jsp�j
//		
//			try {
//				/***************************1.�����ШD�Ѽ� - ��J�榡�����~�B�z**********************/
//				Integer ordedno = new Integer(req.getParameter("ordedno").trim());
//				String ename = req.getParameter("ename").trim();
//				String job = req.getParameter("job").trim();				
//				
//				java.sql.Date hiredate = null;
//				try {
//					hiredate = java.sql.Date.valueOf(req.getParameter("hiredate").trim());
//				} catch (IllegalArgumentException e) {
//					hiredate=new java.sql.Date(System.currentTimeMillis());
//					errorMsgs.add("�п�J���!");
//				}
//
//				Double sal = null;
//				try {
//					sal = new Double(req.getParameter("sal").trim());
//				} catch (NumberFormatException e) {
//					sal = 0.0;
//					errorMsgs.add("�~���ж�Ʀr.");
//				}
//
//				Double comm = null;
//				try {
//					comm = new Double(req.getParameter("comm").trim());
//				} catch (NumberFormatException e) {
//					comm = 0.0;
//					errorMsgs.add("�����ж�Ʀr.");
//				}
//
//				Integer deptno = new Integer(req.getParameter("deptno").trim());
//
//				OrderedVO orderedVO = new OrderedVO();
//				orderedVO.setEmpno(ordedno);
//				orderedVO.setEname(ename);
//				orderedVO.setJob(job);
//				orderedVO.setHiredate(hiredate);
//				orderedVO.setSal(sal);
//				orderedVO.setComm(comm);
//				orderedVO.setDeptno(deptno);
//
//				// Send the use back to the form, if there were errors
//				if (!errorMsgs.isEmpty()) {
//					req.setAttribute("orderedVO", orderedVO); // �t����J�榡���~��orderedVO����,�]�s�Jreq
//					RequestDispatcher failureView = req
//							.getRequestDispatcher("/ordered/update_emp_input.jsp");
//					failureView.forward(req, res);
//					return; //�{�����_
//				}
//				
//				/***************************2.�}�l�ק���*****************************************/
//				OrderedService orderedSvc = new OrderedService();
//				orderedVO = orderedSvc.updateEmp(ordedno, ename, job, hiredate, sal,comm, deptno);
//				
//				/***************************3.�ק粒��,�ǳ����(Send the Success view)*************/				
//				DeptService deptSvc = new DeptService();
//				if(requestURL.equals("/dept/listEmps_ByDeptno.jsp") || requestURL.equals("/dept/listAllDept.jsp"))
//					req.setAttribute("listEmps_ByDeptno",deptSvc.getEmpsByDeptno(deptno)); // ��Ʈw���X��list����,�s�Jrequest
//				
//				if(requestURL.equals("/ordered/listEmps_ByCompositeQuery.jsp")){
//					HttpSession session = req.getSession();
//					Map<String, String[]> map = (Map<String, String[]>)session.getAttribute("map");
//					List<OrderedVO> list  = orderedSvc.getAll(map);
//					req.setAttribute("listEmps_ByCompositeQuery",list); //  �ƦX�d��, ��Ʈw���X��list����,�s�Jrequest
//				}
//                
//				String url = requestURL;
//				RequestDispatcher successView = req.getRequestDispatcher(url);   // �ק令�\��,���^�e�X�ק諸�ӷ�����
//				successView.forward(req, res);
//
//				/***************************��L�i�઺���~�B�z*************************************/
//			} catch (Exception e) {
//				errorMsgs.add("�ק��ƥ���:"+e.getMessage());
//				RequestDispatcher failureView = req
//						.getRequestDispatcher("/ordered/update_emp_input.jsp");
//				failureView.forward(req, res);
//			}
//		}
//
//        if ("insert".equals(action)) { // �Ӧ�addEmp.jsp���ШD  
//			
//			List<String> errorMsgs = new LinkedList<String>();
//			// Store this set in the request scope, in case we need to
//			// send the ErrorPage view.
//			req.setAttribute("errorMsgs", errorMsgs);
//
//			try {
//				/***********************1.�����ШD�Ѽ� - ��J�榡�����~�B�z*************************/
//				String ename = req.getParameter("ename").trim();
//				String job = req.getParameter("job").trim();
//				
//				java.sql.Date hiredate = null;
//				try {
//					hiredate = java.sql.Date.valueOf(req.getParameter("hiredate").trim());
//				} catch (IllegalArgumentException e) {
//					hiredate=new java.sql.Date(System.currentTimeMillis());
//					errorMsgs.add("�п�J���!");
//				}
//				
//				Double sal = null;
//				try {
//					sal = new Double(req.getParameter("sal").trim());
//				} catch (NumberFormatException e) {
//					sal = 0.0;
//					errorMsgs.add("�~���ж�Ʀr.");
//				}
//				
//				Double comm = null;
//				try {
//					comm = new Double(req.getParameter("comm").trim());
//				} catch (NumberFormatException e) {
//					comm = 0.0;
//					errorMsgs.add("�����ж�Ʀr.");
//				}
//				
//				Integer deptno = new Integer(req.getParameter("deptno").trim());
//
//				OrderedVO orderedVO = new OrderedVO();
//				orderedVO.setEname(ename);
//				orderedVO.setJob(job);
//				orderedVO.setHiredate(hiredate);
//				orderedVO.setSal(sal);
//				orderedVO.setComm(comm);
//				orderedVO.setDeptno(deptno);
//
//				// Send the use back to the form, if there were errors
//				if (!errorMsgs.isEmpty()) {
//					req.setAttribute("orderedVO", orderedVO); // �t����J�榡���~��orderedVO����,�]�s�Jreq
//					RequestDispatcher failureView = req
//							.getRequestDispatcher("/ordered/addEmp.jsp");
//					failureView.forward(req, res);
//					return;
//				}
//				
//				/***************************2.�}�l�s�W���***************************************/
//				OrderedService orderedSvc = new OrderedService();
//				orderedVO = orderedSvc.addEmp(ename, job, hiredate, sal, comm, deptno);
//				
//				/***************************3.�s�W����,�ǳ����(Send the Success view)***********/
//				String url = "/ordered/listAllEmp.jsp";
//				RequestDispatcher successView = req.getRequestDispatcher(url); // �s�W���\�����listAllEmp.jsp
//				successView.forward(req, res);				
//				
//				/***************************��L�i�઺���~�B�z**********************************/
//			} catch (Exception e) {
//				errorMsgs.add(e.getMessage());
//				RequestDispatcher failureView = req
//						.getRequestDispatcher("/ordered/addEmp.jsp");
//				failureView.forward(req, res);
//			}
//		}
//		
//       
//		if ("delete".equals(action)) { // �Ӧ�listAllEmp.jsp ��  /dept/listEmps_ByDeptno.jsp���ШD
//
//			List<String> errorMsgs = new LinkedList<String>();
//			// Store this set in the request scope, in case we need to
//			// send the ErrorPage view.
//			req.setAttribute("errorMsgs", errorMsgs);
//			
//			String requestURL = req.getParameter("requestURL"); // �e�X�R�����ӷ��������|: �i�ର�i/ordered/listAllEmp.jsp�j ��  �i/dept/listEmps_ByDeptno.jsp�j �� �i /dept/listAllDept.jsp�j �� �i /ordered/listEmps_ByCompositeQuery.jsp�j
//
//			try {
//				/***************************1.�����ШD�Ѽ�***************************************/
//				Integer ordedno = new Integer(req.getParameter("ordedno"));
//				
//				/***************************2.�}�l�R�����***************************************/
//				OrderedService orderedSvc = new OrderedService();
//				OrderedVO orderedVO = orderedSvc.getOneEmp(ordedno);
//				orderedSvc.deleteEmp(ordedno);
//				
//				/***************************3.�R������,�ǳ����(Send the Success view)***********/
//				DeptService deptSvc = new DeptService();
//				if(requestURL.equals("/dept/listEmps_ByDeptno.jsp") || requestURL.equals("/dept/listAllDept.jsp"))
//					req.setAttribute("listEmps_ByDeptno",deptSvc.getEmpsByDeptno(orderedVO.getDeptno())); // ��Ʈw���X��list����,�s�Jrequest
//				
//				if(requestURL.equals("/ordered/listEmps_ByCompositeQuery.jsp")){
//					HttpSession session = req.getSession();
//					Map<String, String[]> map = (Map<String, String[]>)session.getAttribute("map");
//					List<OrderedVO> list  = orderedSvc.getAll(map);
//					req.setAttribute("listEmps_ByCompositeQuery",list); //  �ƦX�d��, ��Ʈw���X��list����,�s�Jrequest
//				}
//				
//				String url = requestURL;
//				RequestDispatcher successView = req.getRequestDispatcher(url); // �R�����\��,���^�e�X�R�����ӷ�����
//				successView.forward(req, res);
//				
//				/***************************��L�i�઺���~�B�z**********************************/
//			} catch (Exception e) {
//				errorMsgs.add("�R����ƥ���:"+e.getMessage());
//				RequestDispatcher failureView = req
//						.getRequestDispatcher(requestURL);
//				failureView.forward(req, res);
//			}
//		}
//		
//		if ("listEmps_ByCompositeQuery".equals(action)) { // �Ӧ�select_page.jsp���ƦX�d�߽ШD
//			List<String> errorMsgs = new LinkedList<String>();
//			// Store this set in the request scope, in case we need to
//			// send the ErrorPage view.
//			req.setAttribute("errorMsgs", errorMsgs);
//
//			try {
//				
//				/***************************1.�N��J����ରMap**********************************/ 
//				//�ĥ�Map<String,String[]> getParameterMap()����k 
//				//�`�N:an immutable java.util.Map 
//				//Map<String, String[]> map = req.getParameterMap();
//				HttpSession session = req.getSession();
//				Map<String, String[]> map = (Map<String, String[]>)session.getAttribute("map");
//				if (req.getParameter("whichPage") == null){
//					HashMap<String, String[]> map1 = (HashMap<String, String[]>)req.getParameterMap();
//					HashMap<String, String[]> map2 = new HashMap<String, String[]>();
//					map2 = (HashMap<String, String[]>)map1.clone();
//					session.setAttribute("map",map2);
//					map = (HashMap<String, String[]>)req.getParameterMap();
//				} 
//				
//				/***************************2.�}�l�ƦX�d��***************************************/
//				OrderedService orderedSvc = new OrderedService();
//				List<OrderedVO> list  = orderedSvc.getAll(map);
//				
//				/***************************3.�d�ߧ���,�ǳ����(Send the Success view)************/
//				req.setAttribute("listEmps_ByCompositeQuery", list); // ��Ʈw���X��list����,�s�Jrequest
//				RequestDispatcher successView = req.getRequestDispatcher("/ordered/listEmps_ByCompositeQuery.jsp"); // ���\���listEmps_ByCompositeQuery.jsp
//				successView.forward(req, res);
//				
//				/***************************��L�i�઺���~�B�z**********************************/
//			} catch (Exception e) {
//				errorMsgs.add(e.getMessage());
//				RequestDispatcher failureView = req
//						.getRequestDispatcher("/select_page.jsp");
//				failureView.forward(req, res);
//			}
//		}
	}
}
