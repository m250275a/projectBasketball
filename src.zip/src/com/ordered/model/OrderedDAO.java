package com.ordered.model;

import java.util.*;
import java.sql.*;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.orderlist.model.OrderListVO;
import com.product.model.CarProductVO;

public class OrderedDAO implements OrderedDAO_interface {

	// �@�����ε{����,�w��@�Ӹ�Ʈw ,�@�Τ@��DataSource�Y�i
	private static DataSource ds = null;
	static {
		try {
			Context ctx = new InitialContext();
			ds = (DataSource) ctx.lookup("java:comp/env/jdbc/TestDB");
		} catch (NamingException e) {
			e.printStackTrace();
		}
	}

	private static final String INSERT_CarOrdered_STMT = "INSERT INTO ordered (ordedno,memno,orddate,sums) VALUES (ordered_seq.NEXTVAL, ?, ?, ?)";
	private static final String INSERT_CarOrderList_STMT = "INSERT INTO orderList (ordlstno,ordedno,prodno,ordedqnty) VALUES (orderList_seq.NEXTVAL, ?, ?, ?)";
	private static final String GET_ALL_STMT = "SELECT ordedno,memno,TO_CHAR(orddate,'YYYY-MM-DD HH24:MI:SS') orddate,TO_CHAR(deliverydate,'YYYY-MM-DD HH24:MI:SS') deliverydate,sums FROM ordered order by ordedno";
	private static final String GET_ONE_STMT = "SELECT ordedno,memno,TO_CHAR(orddate,'YYYY-MM-DD HH24:MI:SS') orddate,TO_CHAR(deliverydate,'YYYY-MM-DD HH24:MI:SS') deliverydate,sums FROM ordered where ordedno = ?";
	private static final String UPDATE = "UPDATE ordered set memno=?, orddate=?, deliverydate=?, sums=? where ordedno = ?";
	// �䥼�X�f���q��
	private static final String GET_ORDERLIST = "select ordedno,memno,orddate,deliverydate,sums from ordered where deliverydate is null order by orddate desc";
	// �T�{�X�f
	private static final String UPDATE_DELIVERYDATE = "UPDATE Ordered set deliverydate=TO_DATE(TO_CHAR(SYSDATE,'YYYY-MM-DD HH24:MI:SS'),'YYYY-MM-DD HH24:MI:SS') WHERE ordedno=?";

	@Override
	public void insertCarOrdered(OrderedVO orderedVO, Set<CarProductVO> carList) {

		Connection con = null;
		PreparedStatement pstmt = null;

		try {

			con = ds.getConnection();

			// 1���]�w�� pstm.executeUpdate()���e
			con.setAutoCommit(false);

			// ���s�W�q��
			// "INSERT INTO ordered (ordedno,memno,orddate,sum) VALUES
			// (ordered_seq.NEXTVAL, ?, ?, ?)"
			String cols[] = { "ordedno" }; // �� int cols[] = {1};
			pstmt = con.prepareStatement(INSERT_CarOrdered_STMT, cols);
			pstmt.setInt(1, orderedVO.getMemno());
			pstmt.setTimestamp(2, orderedVO.getOrddate());
			pstmt.setInt(3, orderedVO.getSums());
			pstmt.executeUpdate();

			// �����������ۼW�D���
			ResultSet rsKeys = pstmt.getGeneratedKeys();
			ResultSetMetaData rsmd = rsKeys.getMetaData();
			int columnCount = rsmd.getColumnCount();
			System.out.println("columnCount: " + columnCount);
			System.out.println("rsKeys: " + rsKeys);
			if (rsKeys.next()) {
				do {
					for (int i = 1; i <= columnCount; i++) {
						String key = rsKeys.getString(i);
						orderedVO.setOrdedno(new Integer(Integer.parseInt(key)));
						System.out.println("�ۼW�D���(i=" + i + ") = " + key + "(��s�W���\���q��s��)");
					}
				} while (rsKeys.next());
			} else {
				System.out.println("NO KEYS WERE GENERATED.");
			}

			// �A�s�W�q�����(�ƦX�D��)
			// INSERT INTO orderList (ordlstno,ordedno,prodno,ordedqnty) VALUES
			// (orderList_seq.NEXTVAL, ?, ?, ?)
			for (CarProductVO carProduct : carList) {
				PreparedStatement pstmt2 = null;
				pstmt2 = con.prepareStatement(INSERT_CarOrderList_STMT);
				pstmt2.setInt(1, orderedVO.getOrdedno());
				pstmt2.setInt(2, carProduct.getProdno());
				pstmt2.setInt(3, carProduct.getProdqnty());
				pstmt2.executeUpdate();
			}

			// 2���]�w�� pstm.executeUpdate()����
			con.commit();
			con.setAutoCommit(true);

			// Handle any SQL errors
		} catch (SQLException se) {
			if (con != null) {
				try {
					// 3���]�w�����exception�o�ͮɤ�catch�϶���
					con.rollback();
				} catch (SQLException excep) {
					throw new RuntimeException("rollback error occured. " + excep.getMessage());
				}
			}
			throw new RuntimeException("A database error occured. " + se.getMessage());
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					e.printStackTrace(System.err);
				}
			}
		}

	}

	@Override
	public void update(OrderedVO orderedVO) {

		Connection con = null;
		PreparedStatement pstmt = null;

		try {

			con = ds.getConnection();
			pstmt = con.prepareStatement(UPDATE);

			pstmt.setInt(1, orderedVO.getMemno());
			pstmt.setTimestamp(2, orderedVO.getOrddate());
			pstmt.setTimestamp(3, orderedVO.getDeliverydate());
			pstmt.setInt(4, orderedVO.getSums());
			pstmt.setInt(5, orderedVO.getOrdedno());

			pstmt.executeUpdate();

			// Handle any SQL errors
		} catch (SQLException se) {
			throw new RuntimeException("A database error occured. " + se.getMessage());
			// Clean up JDBC resources
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					e.printStackTrace(System.err);
				}
			}
		}

	}

	private static final String DELETE_ORDERLISTs = "DELETE FROM orderlist where ordedno = ?";
	private static final String DELETE_ORDERED = "DELETE FROM ordered where ordedno = ?";

	@Override
	public void delete(Integer ordedno) {
		int updateCount_ORDERLISTs = 0;

		Connection con = null;
		PreparedStatement pstmt = null;

		try {

			con = ds.getConnection();

			// 1���]�w�� pstm.executeUpdate()���e
			con.setAutoCommit(false);

			// ���R�����u
			pstmt = con.prepareStatement(DELETE_ORDERLISTs);
			pstmt.setInt(1, ordedno);
			updateCount_ORDERLISTs = pstmt.executeUpdate();
			// �A�R������
			pstmt = con.prepareStatement(DELETE_ORDERED);
			pstmt.setInt(1, ordedno);
			pstmt.executeUpdate();

			// 2���]�w�� pstm.executeUpdate()����
			con.commit();
			con.setAutoCommit(true);
			System.out.println("�R���q��s��" + ordedno + "��,�@���q�����" + updateCount_ORDERLISTs + "�i�P�ɳQ�R��");

			// Handle any SQL errors
		} catch (SQLException se) {
			if (con != null) {
				try {
					// 3���]�w�����exception�o�ͮɤ�catch�϶���
					con.rollback();
				} catch (SQLException excep) {
					throw new RuntimeException("rollback error occured. " + excep.getMessage());
				}
			}
			throw new RuntimeException("A database error occured. " + se.getMessage());
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					e.printStackTrace(System.err);
				}
			}
		}

	}

	@Override
	public OrderedVO findByPrimaryKey(Integer ordedno) {

		OrderedVO orderedVO = null;
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {

			con = ds.getConnection();
			pstmt = con.prepareStatement(GET_ONE_STMT);

			pstmt.setInt(1, ordedno);

			rs = pstmt.executeQuery();

			while (rs.next()) {
				// orderedVo �]�٬� Domain objects
				orderedVO = new OrderedVO();
				orderedVO.setOrdedno(rs.getInt("ordedno"));
				orderedVO.setMemno(rs.getInt("memno"));
				orderedVO.setOrddate(rs.getTimestamp("orddate"));
				orderedVO.setDeliverydate(rs.getTimestamp("deliverydate"));
				orderedVO.setSums(rs.getInt("sums"));
			}

			// Handle any SQL errors
		} catch (SQLException se) {
			throw new RuntimeException("A database error occured. " + se.getMessage());
			// Clean up JDBC resources
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					e.printStackTrace(System.err);
				}
			}
		}
		return orderedVO;
	}

	@Override
	public List<OrderedVO> getAll() {
		List<OrderedVO> list = new ArrayList<OrderedVO>();
		OrderedVO orderedVO = null;

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {

			con = ds.getConnection();
			pstmt = con.prepareStatement(GET_ALL_STMT);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				// orderedVO �]�٬� Domain objects
				orderedVO = new OrderedVO();
				orderedVO.setOrdedno(rs.getInt("ordedno"));
				orderedVO.setMemno(rs.getInt("memno"));
				orderedVO.setOrddate(rs.getTimestamp("orddate"));
				orderedVO.setDeliverydate(rs.getTimestamp("deliverydate"));
				orderedVO.setSums(rs.getInt("sums"));

				list.add(orderedVO); // Store the row in the list
			}

			// Handle any SQL errors
		} catch (SQLException se) {
			throw new RuntimeException("A database error occured. " + se.getMessage());
			// Clean up JDBC resources
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					e.printStackTrace(System.err);
				}
			}
		}
		return list;
	}

	private static final String GET_OrderLists_ByOrdedno_STMT = "SELECT ORDLSTNO,ORDEDNO,PRODNO,ORDEDQNTY FROM orderlist where ordedno = ? order by ORDLSTNO";

	@Override
	public Set<OrderListVO> getOrderListsByOrdedno(Integer ordedno) {
		Set<OrderListVO> set = new LinkedHashSet<OrderListVO>();
		OrderListVO orderListVO = null;

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {

			con = ds.getConnection();
			pstmt = con.prepareStatement(GET_OrderLists_ByOrdedno_STMT);
			pstmt.setInt(1, ordedno);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				orderListVO = new OrderListVO();
				orderListVO.setOrdlstno(rs.getInt("ordlstno"));
				orderListVO.setOrdedno(rs.getInt("ordedno"));
				orderListVO.setProdno(rs.getInt("prodno"));
				orderListVO.setOrdedqnty(rs.getInt("ordedqnty"));
				set.add(orderListVO); // Store the row in the vector
			}

			// Handle any SQL errors
		} catch (SQLException se) {
			throw new RuntimeException("A database error occured. " + se.getMessage());
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					e.printStackTrace(System.err);
				}
			}
		}
		return set;
	}

	@Override
	public List<OrderedVO> getAllOrderList() {
		// TODO Auto-generated method stub
		List<OrderedVO> list = new ArrayList<OrderedVO>();
		OrderedVO orderedVO = null;

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {

			con = ds.getConnection();
			pstmt = con.prepareStatement(GET_ORDERLIST);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				// orderedVO �]�٬� Domain objects
				orderedVO = new OrderedVO();
				orderedVO.setOrdedno(rs.getInt("ordedno"));
				orderedVO.setMemno(rs.getInt("memno"));
				orderedVO.setOrddate(rs.getTimestamp("orddate"));
				orderedVO.setDeliverydate(rs.getTimestamp("deliverydate"));
				orderedVO.setSums(rs.getInt("sums"));

				list.add(orderedVO); // Store the row in the list
			}

			// Handle any SQL errors
		} catch (SQLException se) {
			throw new RuntimeException("A database error occured. " + se.getMessage());
			// Clean up JDBC resources
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					e.printStackTrace(System.err);
				}
			}
		}
		return list;
	}

	@Override
	public void updateOrderList(OrderedVO orderedVO) {
		// TODO Auto-generated method stub
		Connection con = null;
		PreparedStatement pstmt = null;

		try {

			con = ds.getConnection();
			pstmt = con.prepareStatement(UPDATE_DELIVERYDATE);

			
			pstmt.setInt(1, orderedVO.getOrdedno());

			pstmt.executeUpdate();

			// Handle any SQL errors
		} catch (SQLException se) {
			throw new RuntimeException("A database error occured. " + se.getMessage());
			// Clean up JDBC resources
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					e.printStackTrace(System.err);
				}
			}
		}

	}

}