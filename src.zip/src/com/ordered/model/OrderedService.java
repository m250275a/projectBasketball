package com.ordered.model;

import java.sql.Timestamp;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.orderlist.model.OrderListVO;
import com.product.model.CarProductVO;

public class OrderedService {

	private OrderedDAO_interface dao;

	public OrderedService() {
		dao = new OrderedDAO();
	}

	public OrderedVO updateOrdered(Integer ordedno, Integer memno, Timestamp orddate,
			Timestamp deliverydate) {

		OrderedVO orderedVO = new OrderedVO();

		orderedVO.setOrdedno(ordedno);
		orderedVO.setMemno(memno);
		orderedVO.setOrddate(orddate);
		orderedVO.setDeliverydate(deliverydate);
		dao.update(orderedVO);

		return orderedVO;
	}

	public OrderedVO getOneOrdered(Integer ordedno) {
		return dao.findByPrimaryKey(ordedno);
	}

	public List<OrderedVO> getAll() {
		return dao.getAll();
	}
	
//	public List<OrderedVO> getAll(Map<String, String[]> map) {
//		return dao.getAll(map);
//	}
	
	public Set<OrderListVO> getOrderListsByOrdedno(Integer ordedno) {
		return dao.getOrderListsByOrdedno(ordedno);
	}
	
	public void deleteOrdered(Integer ordedno) {
		dao.delete(ordedno);
	}
	
	public OrderedVO addCarOrdered(Integer memno, Timestamp orddate, Integer sums, Set<CarProductVO> carList) {

		OrderedVO orderedVO = new OrderedVO();

		orderedVO.setMemno(memno);
		orderedVO.setOrddate(orddate);
		orderedVO.setSums(sums);
		dao.insertCarOrdered(orderedVO,carList);

		return orderedVO;
	}
	
	//�䥼�X�f���q��
	public List<OrderedVO> getAllOrderList(){
		return dao.getAllOrderList();
	}
	//�T�{�X�f
	public OrderedVO updateOrderList(Integer ordedno){
		OrderedVO orderedVO = new OrderedVO();

		orderedVO.setOrdedno(ordedno);
		dao.updateOrderList(orderedVO);

		return orderedVO;
	}
	
}
