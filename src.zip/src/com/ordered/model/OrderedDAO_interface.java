package com.ordered.model;

import java.util.*;

import com.orderlist.model.OrderListVO;
import com.product.model.CarProductVO;

public interface OrderedDAO_interface {
          public void insertCarOrdered(OrderedVO orderedVO, Set<CarProductVO> carList);
          public void update(OrderedVO orderedVO);
          public void delete(Integer ordedno);
          public OrderedVO findByPrimaryKey(Integer ordedno);
          public List<OrderedVO> getAll();
          //�U�νƦX�d��(�ǤJ�Ѽƫ��AMap)(�^�� List)
//        public List<OrderedVO> getAll(Map<String, String[]> map); 
          public Set<OrderListVO> getOrderListsByOrdedno(Integer ordedno); 
          
          //�䥼�X�f���q��
          public List<OrderedVO> getAllOrderList();
          //�T�{�X�f
          public void updateOrderList(OrderedVO orderedVO);
}
