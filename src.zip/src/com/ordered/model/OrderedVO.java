package com.ordered.model;
import java.sql.Date;
import java.sql.Timestamp;

public class OrderedVO implements java.io.Serializable{
	private Integer ordedno;
	private Integer memno;
	private Timestamp orddate;
	private Timestamp deliverydate;
	private Integer sums;
	
	public Integer getOrdedno() {
		return ordedno;
	}
	public void setOrdedno(Integer ordedno) {
		this.ordedno = ordedno;
	}
	public Integer getMemno() {
		return memno;
	}
	public void setMemno(Integer memno) {
		this.memno = memno;
	}
	public Timestamp getOrddate() {
		return orddate;
	}
	public void setOrddate(Timestamp orddate) {
		this.orddate = orddate;
	}
	public Timestamp getDeliverydate() {
		return deliverydate;
	}
	public void setDeliverydate(Timestamp deliverydate) {
		this.deliverydate = deliverydate;
	}
	public Integer getSums() {
		return sums;
	}
	public void setSums(Integer sums) {
		this.sums = sums;
	}
	
}
