package com.report.model;

import java.util.List;


public interface ReportDAO_interface {
	public void insert(ReportVO reportVO);
    public void update(ReportVO reportVO);
    public void delete(Integer reportno);
    public ReportVO findByPrimaryKey(Integer reportno);

    public List<ReportVO> getAll();
    public List<ReportVO> getByMemedno(Integer memedno);
    //���|�y���n��
    public void insertReport(ReportVO reportVO);
    //�f�ֵ��G
    public void updateResult(ReportVO reportVO);
    //�d�ߥ��f�ֲn��
    public List<ReportVO> getNoCheck();
}
