package com.report.model;

import java.io.Serializable;

public class ReportVO implements Serializable{
	private Integer  reportno;
	private Integer  memno;
	private String   content;
	private Integer  memedno;
	private String   result;
	
	public Integer getReportno() {
		return reportno;
	}
	public void setReportno(Integer reportno) {
		this.reportno = reportno;
	}
	public Integer getMemno() {
		return memno;
	}
	public void setMemno(Integer memno) {
		this.memno = memno;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public Integer getMemedno() {
		return memedno;
	}
	public void setMemedno(Integer memedno) {
		this.memedno = memedno;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	
	
	
}

