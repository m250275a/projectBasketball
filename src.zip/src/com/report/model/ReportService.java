package com.report.model;

import java.util.List;

public class ReportService {
	
	private ReportDAO_interface dao ;
	public ReportService(){
		dao = new ReportDAO();
	}
	
	public ReportVO addReport(Integer memno, String content,
			Integer memedno, String result) {

		ReportVO reportVO = new ReportVO();

		
		reportVO.setMemno(memno);
		reportVO.setContent(content);
		reportVO.setMemedno(memedno);
		reportVO.setResult(result);
		
		dao.insert(reportVO);

		return reportVO;
	}

	public ReportVO updateReport(Integer reportno, Integer memno, String content,
			Integer memedno, String result) {

		ReportVO reportVO = new ReportVO();

		reportVO.setReportno(reportno);
		reportVO.setMemno(memno);
		reportVO.setContent(content);
		reportVO.setMemedno(memedno);
		reportVO.setResult(result);
		
		dao.update(reportVO);

		return reportVO;
	}

	public void deleteReport(Integer reportno) {
		dao.delete(reportno);
	}

	public ReportVO getOneReport(Integer reportno) {
		return dao.findByPrimaryKey(reportno);
	}

	public List<ReportVO> getAll() {
		return dao.getAll();
	}
	public List<ReportVO> getByMemedno(Integer memedno) {
		return dao.getByMemedno(memedno);
	}
	//���|�y���n��
	public ReportVO insertReport(Integer memno, String content,
			Integer memedno) {

		ReportVO reportVO = new ReportVO();
		reportVO.setMemno(memno);
		reportVO.setContent(content);
		reportVO.setMemedno(memedno);
		
		dao.insertReport(reportVO);

		return reportVO;
	}
	//�f�ֲy���n��
	public List<ReportVO> getNoCheck() {
		return dao.getNoCheck();
	}
	//�f�ֵ��G
	public ReportVO updateResult(Integer reportno,String result){
		ReportVO reportVO = new ReportVO();

		reportVO.setReportno(reportno);
		reportVO.setResult(result);
		
		dao.updateResult(reportVO);

		return reportVO;
	}
}
