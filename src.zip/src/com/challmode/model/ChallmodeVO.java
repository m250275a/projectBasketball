package com.challmode.model;

public class ChallmodeVO implements java.io.Serializable {
	private Integer challmode;
	private String challcontent;
	public Integer getChallmode() {
		return challmode;
	}
	public void setChallmode(Integer challmode) {
		this.challmode = challmode;
	}
	public String getChallcontent() {
		return challcontent;
	}
	public void setChallcontent(String challcontent) {
		this.challcontent = challcontent;
	}
	
}
