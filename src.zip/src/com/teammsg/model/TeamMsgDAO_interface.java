package com.teammsg.model;

import java.util.*;

public interface TeamMsgDAO_interface {
	public void insert(TeamMsgVO teamMsgVo);
	public void update(TeamMsgVO teamMsgVo);
	//�R�����|�d��
	public void delete(Integer msgno);
	public TeamMsgVO findByPrimaryKey(Integer msgno);
	public List<TeamMsgVO> getAll();
	
	//�s�W�y���d��
	public void insertmsg(TeamMsgVO teamMsgVo);
	//��ݼf�֤����o��
	public List<TeamMsgVO> getMemmsgByMem(Integer memno);
	
	//public List<TeamVo> getAll(Map<String, String[]> map);
}
