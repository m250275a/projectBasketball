package com.teammsg.model;

import java.sql.*;
import java.util.*;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class TeamMsgDAO implements TeamMsgDAO_interface {

	// �@�����ε{����,�w��@�Ӹ�Ʈw ,�@�Τ@��DataSource�Y�i
		private static DataSource ds = null;
		static {
			try {
				Context ctx = new InitialContext();
				ds = (DataSource) ctx.lookup("java:comp/env/jdbc/TestDB");
			} catch (NamingException e) {
				e.printStackTrace();
			}
		}

	private static final String INSERT_STMT = "INSERT INTO Teammsg (msgno ,memno ,teamno ,msg ,msgdate) VALUES(teammsg_seq.NEXTVAL,?,?,?,?)";
	private static final String GET_ALL_STMT = "SELECT msgno ,memno ,teamno ,msg ,to_char(msgdate,'yyyy-mm-dd hh:mi:ss')msgdate FROM Teammsg order by msgno";
	private static final String GET_ONE_STMT = "SELECT msgno ,memno ,teamno ,msg ,to_char(msgdate,'yyyy-mm-dd hh:mi:ss')msgdate FROM Teammsg where msgno = ?";
	//�R�����|�d��
	private static final String DELETE = "DELETE FROM Teammsg where msgno = ?";
	private static final String UPDATE = "UPDATE Teammsg set memno=?, teamno=?, msg=?, msgdate=? where msgno=?";
	
	//�s�W�y���d��
	private static final String INSERT_msg = "INSERT INTO Teammsg (msgno ,memno ,teamno ,msg ,msgdate) "
			+ "VALUES(teammsg_seq.NEXTVAL,?,?,?,to_date(to_char(sysdate,'yyyy-mm-dd hh:mi:ss'),'yyyy-mm-dd hh:mi:ss'))";
	//��ݼf�֤����o��
	private static final String CHECK_MEM_MSG = 
	"SELECT msgno ,memno ,teamno ,msg ,to_char(msgdate,'yyyy-mm-dd hh:mi:ss')msgdate FROM Teammsg where memno =?";
	@Override
	public void insert(TeamMsgVO teamMsgVO) {

		Connection con = null;
		PreparedStatement pstmt = null;

		try {
			con = ds.getConnection();
			pstmt = con.prepareStatement(INSERT_STMT);

			pstmt.setInt(1, teamMsgVO.getMemno());
			pstmt.setInt(2, teamMsgVO.getTeamno());
			pstmt.setString(3, teamMsgVO.getMsg());
			pstmt.setTimestamp(4, teamMsgVO.getMsgdate());

			pstmt.executeUpdate();

		
		} catch (SQLException se) {
			throw new RuntimeException("A database error occured. " + se.getMessage());
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					e.printStackTrace(System.err);
				}
			}
		}
	}

	@Override
	public void update(TeamMsgVO teamMsgVO) {

		Connection con = null;
		PreparedStatement pstmt = null;

		try {
			con = ds.getConnection();
			pstmt = con.prepareStatement(UPDATE);

			pstmt.setInt(1, teamMsgVO.getMemno());
			pstmt.setInt(2, teamMsgVO.getTeamno());
			pstmt.setString(3, teamMsgVO.getMsg());
			pstmt.setTimestamp(4, teamMsgVO.getMsgdate());
			pstmt.setInt(5, teamMsgVO.getMsgno());

			pstmt.executeUpdate();

		
		} catch (SQLException se) {
			throw new RuntimeException("A database error occured. " + se.getMessage());

		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}

			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					e.printStackTrace(System.err);
				}
			}
		}

	}

	@Override
	public void delete(Integer msgno) {

		Connection con = null;
		PreparedStatement pstmt = null;

		try {
			con = ds.getConnection();
			pstmt = con.prepareStatement(DELETE);

			pstmt.setInt(1, msgno);
			pstmt.executeUpdate();

		
		} catch (SQLException se) {
			throw new RuntimeException("A database error occured. " + se.getMessage());
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
		}
	}

	@Override
	public TeamMsgVO findByPrimaryKey(Integer msgno) {

		TeamMsgVO teamMsgVO = null;
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			con = ds.getConnection();
			pstmt = con.prepareStatement(GET_ONE_STMT);

			pstmt.setInt(1, msgno);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				teamMsgVO = new TeamMsgVO();
				teamMsgVO.setMsgno(rs.getInt("msgno"));
				teamMsgVO.setMemno(rs.getInt("memno"));
				teamMsgVO.setTeamno(rs.getInt("teamno"));
				teamMsgVO.setMsg(rs.getString("msg"));
				teamMsgVO.setMsgdate(rs.getTimestamp("msgdate"));
			}
		
		} catch (SQLException se) {
			throw new RuntimeException("A database error occured. " + se.getMessage());
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					e.printStackTrace(System.err);
				}
			}
		}
		return teamMsgVO;
	}

	@Override
	public List<TeamMsgVO> getAll() {
		List<TeamMsgVO> list = new ArrayList<TeamMsgVO>();
		TeamMsgVO teamMsgVO = null;

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			con = ds.getConnection();
			pstmt = con.prepareStatement(GET_ALL_STMT);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				teamMsgVO = new TeamMsgVO();
				teamMsgVO.setMsgno(rs.getInt("msgno"));
				teamMsgVO.setMemno(rs.getInt("memno"));
				teamMsgVO.setTeamno(rs.getInt("teamno"));
				teamMsgVO.setMsg(rs.getString("msg"));
				teamMsgVO.setMsgdate(rs.getTimestamp("msgdate"));
				list.add(teamMsgVO);// Store the row in the list
			}

			
		} catch (SQLException se) {
			throw new RuntimeException("A database error occured. " + se.getMessage());
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					e.printStackTrace(System.err);
				}
			}
		}
		return list;
	}
	//�s�W�y���d��
	@Override
	public void insertmsg(TeamMsgVO teamMsgVO) {
		// TODO Auto-generated method stub
		Connection con = null;
		PreparedStatement pstmt = null;
		try {
			con = ds.getConnection();
			pstmt = con.prepareStatement(INSERT_msg);

			pstmt.setInt(1, teamMsgVO.getMemno());
			pstmt.setInt(2, teamMsgVO.getTeamno());
			pstmt.setString(3, teamMsgVO.getMsg());

			pstmt.executeUpdate();

		
		} catch (SQLException se) {
			throw new RuntimeException("A database error occured. " + se.getMessage());
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					e.printStackTrace(System.err);
				}
			}
		}
	}
	//��ݼf�֤����o��
	@Override
	public List<TeamMsgVO> getMemmsgByMem(Integer memno) {
		// TODO Auto-generated method stub
		List<TeamMsgVO> list = new ArrayList<TeamMsgVO>();
		TeamMsgVO teamMsgVO = null;

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			con = ds.getConnection();
			pstmt = con.prepareStatement(CHECK_MEM_MSG);
			pstmt.setInt(1, memno);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				teamMsgVO = new TeamMsgVO();
				teamMsgVO.setMsgno(rs.getInt("msgno"));
				teamMsgVO.setMemno(rs.getInt("memno"));
				teamMsgVO.setTeamno(rs.getInt("teamno"));
				teamMsgVO.setMsg(rs.getString("msg"));
				teamMsgVO.setMsgdate(rs.getTimestamp("msgdate"));
				list.add(teamMsgVO);// Store the row in the list
			}

			
		} catch (SQLException se) {
			throw new RuntimeException("A database error occured. " + se.getMessage());
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					e.printStackTrace(System.err);
				}
			}
		}
		return list;
	}
}