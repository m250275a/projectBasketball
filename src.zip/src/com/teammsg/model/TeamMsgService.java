package com.teammsg.model;

import java.sql.Timestamp;
import java.util.List;

public class TeamMsgService {

	private TeamMsgDAO_interface dao;

	public TeamMsgService() {
		dao = new TeamMsgDAO();
	}

	public TeamMsgVO addTeamMsg(Integer memno, Integer teamno, String msg, Timestamp msgdate) {

		TeamMsgVO teamMsgVO = new TeamMsgVO();

		teamMsgVO.setMemno(memno);
		teamMsgVO.setTeamno(teamno);
		teamMsgVO.setMsg(msg);
		teamMsgVO.setMsgdate(msgdate);
		dao.insert(teamMsgVO);

		return teamMsgVO;
	}

	public TeamMsgVO updateTeamMsg(Integer msgno, Integer memno, Integer teamno, String msg, Timestamp msgdate) {

		TeamMsgVO teamMsgVO = new TeamMsgVO();

		teamMsgVO.setMsgno(msgno);
		teamMsgVO.setMemno(memno);
		teamMsgVO.setTeamno(teamno);
		teamMsgVO.setMsg(msg);
		teamMsgVO.setMsgdate(msgdate);
		dao.update(teamMsgVO);

		return teamMsgVO;
	}

	public void deleteTeamMsg(Integer msgno) {
		dao.delete(msgno);
	}

	public TeamMsgVO getOneTeamMsg(Integer msgno) {
		return dao.findByPrimaryKey(msgno);
	}

	public List<TeamMsgVO> getAll() {
		return dao.getAll();
	}
	//�s�W�y���d��
	public TeamMsgVO addMsg(Integer memno, Integer teamno, String msg) {

		TeamMsgVO teamMsgVO = new TeamMsgVO();

		teamMsgVO.setMemno(memno);
		teamMsgVO.setTeamno(teamno);
		teamMsgVO.setMsg(msg);
		
		dao.insertmsg(teamMsgVO);

		return teamMsgVO;
	}
	//��ݼf�֤����o��
	public List<TeamMsgVO> getMemmsgByMem(Integer memno){
		return dao.getMemmsgByMem(memno);
	}
	//�R�����|�d��
	public void deleteMsg(Integer msgno){
		 dao.delete(msgno);
	}
}
