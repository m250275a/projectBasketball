package com.teammsg.controller;

import java.io.*;
import java.sql.Timestamp;
import java.util.*;

import javax.servlet.*;
import javax.servlet.http.*;

import com.team.model.TeamService;
import com.teammsg.model.TeamMsgService;
import com.teammsg.model.TeamMsgVO;

public class TeamMsgServlet extends HttpServlet {

	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		doPost(req, res);
	}

	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {

		req.setCharacterEncoding("UTF-8");
		String action = req.getParameter("action");

		if ("getOne_For_Display".equals(action)) { // �Ӧ�select_page.jsp���ШD

			List<String> errorMsgs = new LinkedList<String>();
			// Store this set in the request scope, in case we need to
			// send the ErrorPage view.
			req.setAttribute("errorMsgs", errorMsgs);

			try {
				/***************************
				 * 1.�����ШD�Ѽ� - ��J�榡�����~�B�z
				 **********************/
				String str = req.getParameter("msgno");
				if (str == null || (str.trim()).length() == 0) {
					errorMsgs.add("�п�J�d���s��");
				}
				// Send the use back to the form, if there were errors
				if (!errorMsgs.isEmpty()) {
					RequestDispatcher failureView = req.getRequestDispatcher("/teamMsg/select_page.jsp");
					failureView.forward(req, res);
					return;// �{�����_
				}

				Integer msgno = null;
				try {
					msgno = new Integer(str);
				} catch (Exception e) {
					errorMsgs.add("�d���s���榡�����T");
				}
				// Send the use back to the form, if there were errors
				if (!errorMsgs.isEmpty()) {
					RequestDispatcher failureView = req.getRequestDispatcher("/teamMsg/select_page.jsp");
					failureView.forward(req, res);
					return;// �{�����_
				}

				/***************************
				 * 2.�}�l�d�߸��
				 *****************************************/
				TeamMsgService teamMsgSvc = new TeamMsgService();
				TeamMsgVO teamMsgVO = teamMsgSvc.getOneTeamMsg(msgno);
				if (teamMsgVO == null) {
					errorMsgs.add("�d�L���");
				}
				// Send the use back to the form, if there were errors
				if (!errorMsgs.isEmpty()) {
					RequestDispatcher failureView = req.getRequestDispatcher("/teamMsg/select_page.jsp");
					failureView.forward(req, res);
					return;// �{�����_
				}

				/***************************
				 * 3.�d�ߧ���,�ǳ����(Send the Success view)
				 *************/
				req.setAttribute("teamMsgVO", teamMsgVO); // ��Ʈw���X��teamMsgVO����,�s�Jreq
				String url = "/teamMsg/listOneTeamMsg.jsp";
				RequestDispatcher successView = req.getRequestDispatcher(url); // ���\���listOneTeamMsg.jsp
				successView.forward(req, res);

				/*************************** ��L�i�઺���~�B�z *************************************/
			} catch (Exception e) {
				errorMsgs.add("�L�k���o���:" + e.getMessage());
				RequestDispatcher failureView = req.getRequestDispatcher("/teamMsg/select_page.jsp");
				failureView.forward(req, res);
			}
		}

		if ("getOne_For_Update".equals(action)) { // �Ӧ�listAllTeamMSg.jsp

			List<String> errorMsgs = new LinkedList<String>();
			// Store this set in the request scope, in case we need to
			// send the ErrorPage view.
			req.setAttribute("errorMsgs", errorMsgs);

			String requestURL = req.getParameter("requestURL"); // �e�X�ק諸�ӷ��������|:
																// �i�ର�i/emp/listAllEmp.jsp�j
																// ��
																// �i/dept/listEmps_ByDeptno.jsp�j
																// �� �i
																// /dept/listAllDept.jsp�j

			try {
				/***************************
				 * 1.�����ШD�Ѽ�
				 ****************************************/
				Integer msgno = new Integer(req.getParameter("msgno"));

				/***************************
				 * 2.�}�l�d�߸��
				 ****************************************/
				TeamMsgService teamMsgSvc = new TeamMsgService();
				TeamMsgVO teamMsgVO = teamMsgSvc.getOneTeamMsg(msgno);

				/***************************
				 * 3.�d�ߧ���,�ǳ����(Send the Success view)
				 ************/
				req.setAttribute("teamMsgVO", teamMsgVO); // ��Ʈw���X��teamMsgVO����,�s�Jreq
				String url = "/teamMsg/update_teamMsg_input.jsp";
				RequestDispatcher successView = req.getRequestDispatcher(url); // ���\���update_teamMSg_input.jsp
				successView.forward(req, res);

				/*************************** ��L�i�઺���~�B�z ************************************/
			} catch (Exception e) {
				errorMsgs.add("�ק��ƨ��X�ɥ���:" + e.getMessage());
				RequestDispatcher failureView = req.getRequestDispatcher(requestURL);
				failureView.forward(req, res);
			}
		}

		if ("update".equals(action)) { // �Ӧ�update_teamMsg_input.jsp���ШD

			List<String> errorMsgs = new LinkedList<String>();
			// Store this set in the request scope, in case we need to
			// send the ErrorPage view.
			req.setAttribute("errorMsgs", errorMsgs);

			String requestURL = req.getParameter("requestURL"); // �e�X�ק諸�ӷ��������|:
																// �i�ର�i/teamMsg/listAllTeamMSg.jsp�j

			try {
				/***************************
				 * 1.�����ШD�Ѽ� - ��J�榡�����~�B�z
				 **********************/
				Integer msgno = new Integer(req.getParameter("msgno").trim());
				Integer memno = null;
				try {
					memno = new Integer(req.getParameter("memno").trim());
				} catch (NumberFormatException e) {
					memno = 0;
					errorMsgs.add("�п�J�|���s��");
				}

				Integer teamno = null;
				try {
					teamno = new Integer(req.getParameter("teamno").trim());
				} catch (NumberFormatException e) {
					teamno = 0;
					errorMsgs.add("�п�J�y���s��");
				}

				String msg = req.getParameter("msg").trim();
				Timestamp msgdate = java.sql.Timestamp.valueOf(req.getParameter("msgdate"));

				TeamMsgVO teamMsgVO = new TeamMsgVO();
				teamMsgVO.setMsgno(msgno);
				teamMsgVO.setMemno(memno);
				teamMsgVO.setTeamno(teamno);
				teamMsgVO.setMsg(msg);
				teamMsgVO.setMsgdate(msgdate);

				// Send the use back to the form, if there were errors
				if (!errorMsgs.isEmpty()) {
					req.setAttribute("teamMsgVO", teamMsgVO); // �t����J�榡���~��teamMsgVO����,�]�s�Jreq
					RequestDispatcher failureView = req.getRequestDispatcher("/teamMsg/update_teamMsg_input.jsp");
					failureView.forward(req, res);
					return; // �{�����_
				}

				/***************************
				 * 2.�}�l�ק���
				 *****************************************/
				TeamMsgService teamMsgSvc = new TeamMsgService();
				teamMsgVO = teamMsgSvc.updateTeamMsg(msgno, memno, teamno, msg, msgdate);

				/***************************
				 * 3.�ק粒��,�ǳ����(Send the Success view)
				 *************/

				String url = requestURL;
				RequestDispatcher successView = req.getRequestDispatcher(url); // �ק令�\��,���^�e�X�ק諸�ӷ�����
				successView.forward(req, res);

				/*************************** ��L�i�઺���~�B�z *************************************/
			} catch (Exception e) {
				errorMsgs.add("�ק��ƥ���:" + e.getMessage());
				RequestDispatcher failureView = req.getRequestDispatcher("/teamMsg/update_teamMsg_input.jsp");
				failureView.forward(req, res);
			}
		}

		if ("insert".equals(action)) { // �Ӧ�addEmp.jsp���ШD

			List<String> errorMsgs = new LinkedList<String>();
			// Store this set in the request scope, in case we need to
			// send the ErrorPage view.
			req.setAttribute("errorMsgs", errorMsgs);

			try {
				/***********************
				 * 1.�����ШD�Ѽ� - ��J�榡�����~�B�z
				 *************************/
				Integer memno = null;
				try {
					memno = new Integer(req.getParameter("memno").trim());
				} catch (NumberFormatException e) {
					memno = 0;
					errorMsgs.add("�п�J�|���s��");
				}

				Integer teamno = null;
				try {
					teamno = new Integer(req.getParameter("teamno").trim());
				} catch (NumberFormatException e) {
					teamno = 0;
					errorMsgs.add("�п�J�y���s��");
				}

				String msg = req.getParameter("msg").trim();
				Timestamp msgdate = java.sql.Timestamp.valueOf(req.getParameter("msgdate"));

				TeamMsgVO teamMsgVO = new TeamMsgVO();
				teamMsgVO.setMemno(memno);
				teamMsgVO.setTeamno(teamno);
				teamMsgVO.setMsg(msg);
				teamMsgVO.setMsgdate(msgdate);

				// Send the use back to the form, if there were errors
				if (!errorMsgs.isEmpty()) {
					req.setAttribute("teamMsgVO", teamMsgVO); // �t����J�榡���~��teamMsgVO����,�]�s�Jreq
					RequestDispatcher failureView = req.getRequestDispatcher("/teamMsg/listAllTeamMsg.jsp");

					failureView.forward(req, res);
					return;
				}

				/***************************
				 * 2.�}�l�s�W���
				 ***************************************/
				TeamMsgService teamMsgSvc = new TeamMsgService();
				teamMsgVO = teamMsgSvc.addTeamMsg(memno, teamno, msg, msgdate);

				/***************************
				 * 3.�s�W����,�ǳ����(Send the Success view)
				 ***********/

				TeamService teamSvc = new TeamService();
				List<TeamMsgVO> list = teamSvc.getMsgByTeam(teamno);

				req.setAttribute("list", list);
				String url = "/teamMsg/listAllTeamMsg.jsp";
				RequestDispatcher successView = req.getRequestDispatcher(url); // �s�W���\�����listAllTeamMsg.jsp
				successView.forward(req, res);

				/*************************** ��L�i�઺���~�B�z **********************************/
			} catch (Exception e) {
				errorMsgs.add(e.getMessage());
				RequestDispatcher failureView = req.getRequestDispatcher("/teamMsg/listAllTeamMsg.jsp");

				failureView.forward(req, res);
			}
		}

		if ("delete".equals(action)) { // �Ӧ�listAllTeamMSg.jsp

			List<String> errorMsgs = new LinkedList<String>();
			// Store this set in the request scope, in case we need to
			// send the ErrorPage view.
			req.setAttribute("errorMsgs", errorMsgs);

			String requestURL = req.getParameter("requestURL"); // �e�X�R�����ӷ��������|:
																// �i�ର�i/teamMsg/listAllTeamMSg.jsp�j

			try {
				/***************************
				 * 1.�����ШD�Ѽ�
				 ***************************************/
				Integer msgno = new Integer(req.getParameter("msgno"));

				/***************************
				 * 2.�}�l�R�����
				 ***************************************/
				TeamMsgService teamMsgSvc = new TeamMsgService();
				TeamMsgVO teamMsgVO = teamMsgSvc.getOneTeamMsg(msgno);
				teamMsgSvc.deleteTeamMsg(msgno);

				/***************************
				 * 3.�R������,�ǳ����(Send the Success view)
				 ***********/

				String url = requestURL;
				RequestDispatcher successView = req.getRequestDispatcher(url); // �R�����\��,���^�e�X�R�����ӷ�����
				successView.forward(req, res);

				/*************************** ��L�i�઺���~�B�z **********************************/
			} catch (Exception e) {
				errorMsgs.add("�R����ƥ���:" + e.getMessage());
				RequestDispatcher failureView = req.getRequestDispatcher(requestURL);
				failureView.forward(req, res);
			}
		}

		// �s�W�d��
		if ("insertmsg".equals(action)) { // �Ӧ�teamMsg.jsp���ШD

			List<String> errorMsgs = new LinkedList<String>();
			// Store this set in the request scope, in case we need to
			// send the ErrorPage view.
			req.setAttribute("errorMsgs", errorMsgs);
			try {
				/***********************
				 * 1.�����ШD�Ѽ� - ��J�榡�����~�B�z
				 *************************/
				Integer memno = null;
				try {
					memno = new Integer(req.getParameter("memno").trim());
				} catch (NumberFormatException e) {
					memno = 0;
					errorMsgs.add("�п�J�|���s��");
				}

				Integer teamno = null;
				try {
					teamno = new Integer(req.getParameter("teamno").trim());
				} catch (NumberFormatException e) {
					teamno = 0;
					errorMsgs.add("�п�J�y���s��");
				}

				String msg = req.getParameter("msg").trim();

				TeamMsgVO teamMsgVO = new TeamMsgVO();
				teamMsgVO.setMemno(memno);
				teamMsgVO.setTeamno(teamno);
				teamMsgVO.setMsg(msg);

				// Send the use back to the form, if there were errors
				if (!errorMsgs.isEmpty()) {
					req.setAttribute("teamMsgVO", teamMsgVO); // �t����J�榡���~��teamMsgVO����,�]�s�Jreq
					RequestDispatcher failureView = req.getRequestDispatcher("/front-end/msgload.jsp");

					failureView.forward(req, res);
					return;
				}

				/***************************
				 * 2.�}�l�s�W���
				 ***************************************/
				TeamMsgService teamMsgSvc = new TeamMsgService();
				teamMsgVO = teamMsgSvc.addMsg(memno, teamno, msg);

				/***************************
				 * 3.�s�W����,�ǳ����(Send the Success view)
				 ***********/

				TeamService teamSvc = new TeamService();
				List<TeamMsgVO> list = teamSvc.getMsgByTeam(teamno);

				req.setAttribute("list", list);
				String url = "/front-end/msgload.jsp";
				RequestDispatcher successView = req.getRequestDispatcher(url); // �s�W���\�����teamMsg.jsp
				successView.forward(req, res);

				/*************************** ��L�i�઺���~�B�z **********************************/
			} catch (Exception e) {
				errorMsgs.add(e.getMessage());
				RequestDispatcher failureView = req.getRequestDispatcher("/front-end/msgload.jsp");

				failureView.forward(req, res);
			}
		}

		// ��ݼf�֤����o��
		if ("checkMemMsg".equals(action)) {

			List<String> errorMsgs = new LinkedList<String>();
			// Store this set in the request scope, in case we need to
			// send the ErrorPage view.
			req.setAttribute("errorMsgs", errorMsgs);

			try {
				String str = req.getParameter("memno");
				if (str == null || (str.trim()).length() == 0) {

					errorMsgs.add("�п�J�s��");
				}
				if (!errorMsgs.isEmpty()) {
					RequestDispatcher failureView = req.getRequestDispatcher("/back-end/backreportMem.jsp");
					failureView.forward(req, res);
					return;// �{�����_
				}

				Integer memno = null;
				try {
					memno = new Integer(str);
				} catch (Exception e) {
					errorMsgs.add("�榡�����T");
				}
				// Send the use back to the form, if there were errors
				if (!errorMsgs.isEmpty()) {
					RequestDispatcher failureView = req.getRequestDispatcher("/back-end/backreportMem.jsp");
					failureView.forward(req, res);
					return;// �{�����_
				}
				
				TeamMsgService teammsgSvc = new TeamMsgService();
				List<TeamMsgVO> list = teammsgSvc.getMemmsgByMem(memno);

				req.setAttribute("list", list);
				String url = "/back-end/backreportMem.jsp";
				RequestDispatcher successView = req.getRequestDispatcher(url); // �s�W���\�����backreportMem.jsp
				successView.forward(req, res);

			} catch (Exception e) {
				
				errorMsgs.add(e.getMessage());
				RequestDispatcher failureView = req.getRequestDispatcher("/back-end/backreportMem.jsp");
				failureView.forward(req, res);
				return;
			}
		}
		//��ݧR�����|�����d��
		if ("msgDelete".equals(action)) { // �Ӧ�backreportMem.jsp

			List<String> errorMsgs = new LinkedList<String>();
			// Store this set in the request scope, in case we need to
			// send the ErrorPage view.
			req.setAttribute("errorMsgs", errorMsgs);

			String requestURL = req.getParameter("requestURL"); 

			try {
				/***************************
				 * 1.�����ШD�Ѽ�
				 ***************************************/
				Integer msgmemno = new Integer(req.getParameter("msgmemno"));
				String[] msgnos = req.getParameterValues("msgno");
	
				/***************************
				 * 2.�}�l�R�����
				 ***************************************/
				if(msgnos != null){
					TeamMsgService teamMsgSvc = new TeamMsgService();
					for(String nos:msgnos){
						Integer no = Integer.parseInt(nos);
						teamMsgSvc.deleteMsg(no);
					}
				}
				else{errorMsgs.add("����ܯd��");}
				
				if (!errorMsgs.isEmpty()) {
					RequestDispatcher failureView = req.getRequestDispatcher("/back-end/backreportMem.jsp");
					failureView.forward(req, res);
					return;// �{�����_
				}
				TeamMsgService teammsgSvc = new TeamMsgService();
				List<TeamMsgVO> list = teammsgSvc.getMemmsgByMem(msgmemno);

				req.setAttribute("list", list);

				/***************************
				 * 3.�R������,�ǳ����(Send the Success view)
				 ***********/

				String url = requestURL;
				RequestDispatcher successView = req.getRequestDispatcher(url); // �R�����\��,���^�e�X�R�����ӷ�����
				successView.forward(req, res);
				
				/*************************** ��L�i�઺���~�B�z **********************************/
			} catch (Exception e) {
				errorMsgs.add("�R����ƥ���:" + e.getMessage());
				RequestDispatcher failureView = req.getRequestDispatcher(requestURL);
				failureView.forward(req, res);
			}
		}
		
		//�ίd���s����Q���|���d��
		if ("checkMemMsgno".equals(action)) { // �Ӧ�backreportMem.jsp���ШD
			List<String> errorMsgs = new LinkedList<String>();
			// Store this set in the request scope, in case we need to
			// send the ErrorPage view.
			req.setAttribute("errorMsgs", errorMsgs);
			try {
				/***************************
				 * 1.�����ШD�Ѽ� - ��J�榡�����~�B�z
				 **********************/
				String str = req.getParameter("msgno");
				if (str == null || (str.trim()).length() == 0) {
					errorMsgs.add("�п�J�d���s��");
				}
				// Send the use back to the form, if there were errors
				if (!errorMsgs.isEmpty()) {
					RequestDispatcher failureView = req.getRequestDispatcher("/back-end/backreportMem.jsp");
					failureView.forward(req, res);
					return;// �{�����_
				}

				Integer msgno = null;
				try {
					msgno = new Integer(str);
				} catch (Exception e) {
					errorMsgs.add("�d���s���榡�����T");
				}
				// Send the use back to the form, if there were errors
				if (!errorMsgs.isEmpty()) {
					RequestDispatcher failureView = req.getRequestDispatcher("/back-end/backreportMem.jsp");
					failureView.forward(req, res);
					return;// �{�����_
				}

				/***************************
				 * 2.�}�l�d�߸��
				 *****************************************/
				TeamMsgService teamMsgSvc = new TeamMsgService();
				TeamMsgVO teamMsgVO = teamMsgSvc.getOneTeamMsg(msgno);
				if (teamMsgVO == null) {
					errorMsgs.add("�d�L���");
				}
				// Send the use back to the form, if there were errors
				if (!errorMsgs.isEmpty()) {
					RequestDispatcher failureView = req.getRequestDispatcher("/back-end/backreportMem.jsp");
					failureView.forward(req, res);
					return;// �{�����_
				}

				/***************************
				 * 3.�d�ߧ���,�ǳ����(Send the Success view)
				 *************/
				req.setAttribute("teamMsgVO", teamMsgVO); // ��Ʈw���X��teamMsgVO����,�s�Jreq
				String url = "/back-end/backreportMem1.jsp";
				RequestDispatcher successView = req.getRequestDispatcher(url); // �ק令�\��,���^�e�X�ק諸�ӷ�����
				successView.forward(req, res);

				/*************************** ��L�i�઺���~�B�z *************************************/
			}
			catch (Exception e) {
				errorMsgs.add("�L�k���o���:" + e.getMessage());
				RequestDispatcher failureView = req.getRequestDispatcher("/back-end/backreportMem.jsp");
				failureView.forward(req, res);
			}
		}
		//��ݧR����@�d��
		if ("onemsgDelete".equals(action)) { // �Ӧ�listAllTeamMSg.jsp

			List<String> errorMsgs = new LinkedList<String>();
			// Store this set in the request scope, in case we need to
			// send the ErrorPage view.
			req.setAttribute("errorMsgs", errorMsgs);

//			String requestURL = req.getParameter("requestURL"); // �e�X�R�����ӷ��������|:
//																// �i�ର�i/teamMsg/listAllTeamMSg.jsp�j

			try {
				/***************************
				 * 1.�����ШD�Ѽ�
				 ***************************************/
				Integer msgno = new Integer(req.getParameter("msgno"));

				/***************************
				 * 2.�}�l�R�����
				 ***************************************/
				TeamMsgService teamMsgSvc = new TeamMsgService();
				TeamMsgVO teamMsgVO = teamMsgSvc.getOneTeamMsg(msgno);
				teamMsgSvc.deleteTeamMsg(msgno);

				/***************************
				 * 3.�R������,�ǳ����(Send the Success view)
				 ***********/

//				String url = requestURL;
				RequestDispatcher successView = req.getRequestDispatcher("/back-end/backreportMem.jsp"); // �R�����\��,���^�e�X�R�����ӷ�����
				successView.forward(req, res);

				/*************************** ��L�i�઺���~�B�z **********************************/
			} catch (Exception e) {
				errorMsgs.add("�R����ƥ���:" + e.getMessage());
				RequestDispatcher failureView = req.getRequestDispatcher("/back-end/backreportMem.jsp");
				failureView.forward(req, res);
			}
		}
	}
}
