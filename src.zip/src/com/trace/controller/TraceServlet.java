package com.trace.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import com.trace.model.TraceService;
import com.trace.model.TraceVO;


@WebServlet("/TraceServlet")
public class TraceServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		doPost(req, res);
	}

	
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		req.setCharacterEncoding("UTF-8");
		res.setCharacterEncoding("UTF-8");
		String action = req.getParameter("action");
	
		if ("getOne_For_Display".equals(action)) { // �Ӧ�select_page.jsp���ШD
			
			List<String> errorMsgs = new LinkedList<String>();
			// Store this set in the request scope, in case we need to
			// send the ErrorPage view.
			req.setAttribute("errorMsgs", errorMsgs);

			try {
				/***************************1.�����ШD�Ѽ� - ��J�榡�����~�B�z**********************/
				String str = req.getParameter("traceno");
				
				if (str == null || (str.trim()).length() == 0) {
					errorMsgs.add("�п�J���u�s��");
				}
				// Send the use back to the form, if there were errors
				if (!errorMsgs.isEmpty()) {
					RequestDispatcher failureView = req
							.getRequestDispatcher("/trace/select_page.jsp");
					failureView.forward(req, res);
					return;//�{�����_
				}
				
				Integer traceno = null;
				try {
					traceno = new Integer(str);
				} catch (Exception e) {
					errorMsgs.add("���u�s���榡�����T");
				}
				// Send the use back to the form, if there were errors
				if (!errorMsgs.isEmpty()) {
					RequestDispatcher failureView = req
							.getRequestDispatcher("/trace/select_page.jsp");
					failureView.forward(req, res);
					return;//�{�����_
				}
				
				/***************************2.�}�l�d�߸��*****************************************/
				TraceService traceSvc = new TraceService();
				TraceVO traceVO = traceSvc.getOneTrace(traceno);
				if (traceVO == null) {
					errorMsgs.add("�d�L���");
				}
				// Send the use back to the form, if there were errors
				if (!errorMsgs.isEmpty()) {
					RequestDispatcher failureView = req
							.getRequestDispatcher("/trace/select_page.jsp");
					failureView.forward(req, res);
					return;//�{�����_
				}
				
				/***************************3.�d�ߧ���,�ǳ����(Send the Success view)*************/
				req.setAttribute("traceVO", traceVO); // ��Ʈw���X��empVO����,�s�Jreq
				String url = "/trace/listOneTrace.jsp";
				RequestDispatcher successView = req.getRequestDispatcher(url); // ���\��� listOneEmp.jsp
				successView.forward(req, res);

				/***************************��L�i�઺���~�B�z*************************************/
			} catch (Exception e) {
				errorMsgs.add("�L�k���o���:" + e.getMessage());
				RequestDispatcher failureView = req
						.getRequestDispatcher("/trace/select_page.jsp");
				failureView.forward(req, res);
			}
		}
		
		
		if ("getOne_For_Update".equals(action)) { // �Ӧ�listAllEmp.jsp���ШD

			List<String> errorMsgs = new LinkedList<String>();
			// Store this set in the request scope, in case we need to
			// send the ErrorPage view.
			req.setAttribute("errorMsgs", errorMsgs);
			
			try {
				/***************************1.�����ШD�Ѽ�****************************************/
				Integer traceno = new Integer(req.getParameter("traceno"));
				
				/***************************2.�}�l�d�߸��****************************************/
				TraceService traceSvc = new TraceService();
				TraceVO traceVO = traceSvc.getOneTrace(traceno);
								
				/***************************3.�d�ߧ���,�ǳ����(Send the Success view)************/
				req.setAttribute("traceVO", traceVO);         // ��Ʈw���X��empVO����,�s�Jreq
				String url = "/trace/update_Trace_input.jsp";
				RequestDispatcher successView = req.getRequestDispatcher(url);// ���\��� update_emp_input.jsp
				successView.forward(req, res);

				/***************************��L�i�઺���~�B�z**********************************/
			} catch (Exception e) {
				errorMsgs.add("�L�k���o�n�ק諸���:" + e.getMessage());
				RequestDispatcher failureView = req
						.getRequestDispatcher("/trace/listAllTrace.jsp");
				failureView.forward(req, res);
			}
		}
		
		
		if ("update".equals(action)) { // �Ӧ�update_emp_input.jsp���ШD
			
			List<String> errorMsgs = new LinkedList<String>();
			// Store this set in the request scope, in case we need to
			// send the ErrorPage view.
			req.setAttribute("errorMsgs", errorMsgs);
		
			try {
				/***************************1.�����ШD�Ѽ� - ��J�榡�����~�B�z**********************/
				Integer traceno = new Integer(req.getParameter("traceno").trim());
				Integer memno = new Integer(req.getParameter("memno").trim());
				Integer memedno = new Integer(req.getParameter("memedno").trim());				
				

				

				TraceVO traceVO = new TraceVO();
				traceVO.setTraceno(traceno);
				traceVO.setMemno(memno);
				traceVO.setMemedno(memedno);
				

				// Send the use back to the form, if there were errors
				if (!errorMsgs.isEmpty()) {
					req.setAttribute("traceVO", traceVO); // �t����J�榡���~��empVO����,�]�s�Jreq
					RequestDispatcher failureView = req
							.getRequestDispatcher("/trace/update_Trace_input.jsp");
					failureView.forward(req, res);
					return; //�{�����_
				}
				
				/***************************2.�}�l�ק���*****************************************/
				TraceService traceSvc = new TraceService();
				traceVO = traceSvc.updateTrace(traceno,memno,memedno);
				
				/***************************3.�ק粒��,�ǳ����(Send the Success view)*************/
				req.setAttribute("traceVO", traceVO); // ��Ʈwupdate���\��,���T����empVO����,�s�Jreq
				String url = "/trace/listOneTrace.jsp";
				RequestDispatcher successView = req.getRequestDispatcher(url); // �ק令�\��,���listOneEmp.jsp
				successView.forward(req, res);

				/***************************��L�i�઺���~�B�z*************************************/
			} catch (Exception e) {
				errorMsgs.add("�ק��ƥ���:"+e.getMessage());
				RequestDispatcher failureView = req
						.getRequestDispatcher("/trace/update_Trace_input.jsp");
				failureView.forward(req, res);
			}
		}

        if ("insert".equals(action)) { // �Ӧ�addEmp.jsp���ШD  
			
			List<String> errorMsgs = new LinkedList<String>();
			// Store this set in the request scope, in case we need to
			// send the ErrorPage view.
			req.setAttribute("errorMsgs", errorMsgs);

			try {
				/***********************1.�����ШD�Ѽ� - ��J�榡�����~�B�z*************************/
				Integer memno = new Integer(req.getParameter("memno").trim());
				Integer memedno = new Integer(req.getParameter("memedno").trim());				
				
				TraceVO traceVO = new TraceVO();
				traceVO.setMemno(memno);
				traceVO.setMemedno(memedno);
				

				// Send the use back to the form, if there were errors
				if (!errorMsgs.isEmpty()) {
					req.setAttribute("traceVO", traceVO); // �t����J�榡���~��empVO����,�]�s�Jreq
					RequestDispatcher failureView = req
							.getRequestDispatcher("/trace/addTrace.jsp");
					failureView.forward(req, res);
					return;
				}
				
				/***************************2.�}�l�s�W���***************************************/
				TraceService traceSvc = new TraceService();
				traceVO = traceSvc.addTrace(memno,memedno);
				
				/***************************3.�s�W����,�ǳ����(Send the Success view)***********/
				String url = "/trace/listAllTrace.jsp";
				RequestDispatcher successView = req.getRequestDispatcher(url); // �s�W���\�����listAllEmp.jsp
				successView.forward(req, res);				
				
				/***************************��L�i�઺���~�B�z**********************************/
			} catch (Exception e) {
				errorMsgs.add(e.getMessage());
				RequestDispatcher failureView = req
						.getRequestDispatcher("/trace/addTrace.jsp");
				failureView.forward(req, res);
			}
		}
		
		
		if ("delete".equals(action)) { // �Ӧ�listAllEmp.jsp

			List<String> errorMsgs = new LinkedList<String>();
			// Store this set in the request scope, in case we need to
			// send the ErrorPage view.
			req.setAttribute("errorMsgs", errorMsgs);
	
			try {
				/***************************1.�����ШD�Ѽ�***************************************/
				Integer traceno = new Integer(req.getParameter("traceno"));
				
				/***************************2.�}�l�R�����***************************************/
				TraceService traceSvc = new TraceService();
				traceSvc.deleteTrace(traceno);
				
				/***************************3.�R������,�ǳ����(Send the Success view)***********/								
				String url = "/trace/listAllTrace.jsp";
				RequestDispatcher successView = req.getRequestDispatcher(url);// �R�����\��,���^�e�X�R�����ӷ�����
				successView.forward(req, res);
				
				/***************************��L�i�઺���~�B�z**********************************/
			} catch (Exception e) {
				errorMsgs.add("�R����ƥ���:"+e.getMessage());
				RequestDispatcher failureView = req
						.getRequestDispatcher("/trace/listAllTrace.jsp");
				failureView.forward(req, res);
			}
		}
		
if ("getForMemno".equals(action)) { // �Ӧ�select_page.jsp���ШD
			
			List<String> errorMsgs = new LinkedList<String>();
			// Store this set in the request scope, in case we need to
			// send the ErrorPage view.
			req.setAttribute("errorMsgs", errorMsgs);

			try {
				/***************************1.�����ШD�Ѽ� - ��J�榡�����~�B�z**********************/
				String str = req.getParameter("memno");
				
				if (str == null || (str.trim()).length() == 0) {
					errorMsgs.add("�п�J���u�s��");
				}
				// Send the use back to the form, if there were errors
				if (!errorMsgs.isEmpty()) {
					RequestDispatcher failureView = req
							.getRequestDispatcher("/trace/select_page.jsp");
					failureView.forward(req, res);
					return;//�{�����_
				}
				
				Integer memno = null;
				try {
					memno = new Integer(str);
				} catch (Exception e) {
					errorMsgs.add("���u�s���榡�����T");
				}
				// Send the use back to the form, if there were errors
				if (!errorMsgs.isEmpty()) {
					RequestDispatcher failureView = req
							.getRequestDispatcher("/trace/select_page.jsp");
					failureView.forward(req, res);
					return;//�{�����_
				}
				
				/***************************2.�}�l�d�߸��*****************************************/
				TraceService traceSvc = new TraceService();
				List<TraceVO> traceVO = traceSvc.getByMemno(memno);
				if (traceVO == null) {
					errorMsgs.add("�d�L���");
				}
				// Send the use back to the form, if there were errors
				if (!errorMsgs.isEmpty()) {
					RequestDispatcher failureView = req
							.getRequestDispatcher("/trace/select_page.jsp");
					failureView.forward(req, res);
					return;//�{�����_
				}
				
				/***************************3.�d�ߧ���,�ǳ����(Send the Success view)*************/
				req.setAttribute("traceVO", traceVO); // ��Ʈw���X��empVO����,�s�Jreq
				String url = "/trace/listAllByMemno.jsp";
				RequestDispatcher successView = req.getRequestDispatcher(url); // ���\��� listOneEmp.jsp
				successView.forward(req, res);

				/***************************��L�i�઺���~�B�z*************************************/
			} catch (Exception e) {
				errorMsgs.add("�L�k���o���:" + e.getMessage());
				RequestDispatcher failureView = req
						.getRequestDispatcher("/trace/select_page.jsp");
				failureView.forward(req, res);
			}
		}	
		
if ("getForMemedno".equals(action)) { // �Ӧ�select_page.jsp���ШD
	
	List<String> errorMsgs = new LinkedList<String>();
	// Store this set in the request scope, in case we need to
	// send the ErrorPage view.
	req.setAttribute("errorMsgs", errorMsgs);

	try {
		/***************************1.�����ШD�Ѽ� - ��J�榡�����~�B�z**********************/
		String str = req.getParameter("memedno");
		
		if (str == null || (str.trim()).length() == 0) {
			errorMsgs.add("�п�J���u�s��");
		}
		// Send the use back to the form, if there were errors
		if (!errorMsgs.isEmpty()) {
			RequestDispatcher failureView = req
					.getRequestDispatcher("/trace/select_page.jsp");
			failureView.forward(req, res);
			return;//�{�����_
		}
		
		Integer memedno = null;
		try {
			memedno = new Integer(str);
		} catch (Exception e) {
			errorMsgs.add("���u�s���榡�����T");
		}
		// Send the use back to the form, if there were errors
		if (!errorMsgs.isEmpty()) {
			RequestDispatcher failureView = req
					.getRequestDispatcher("/trace/select_page.jsp");
			failureView.forward(req, res);
			return;//�{�����_
		}
		
		/***************************2.�}�l�d�߸��*****************************************/
		TraceService traceSvc = new TraceService();
		List<TraceVO> traceVO = traceSvc.getByMemedno(memedno);
		if (traceVO == null) {
			errorMsgs.add("�d�L���");
		}
		// Send the use back to the form, if there were errors
		if (!errorMsgs.isEmpty()) {
			RequestDispatcher failureView = req
					.getRequestDispatcher("/trace/select_page.jsp");
			failureView.forward(req, res);
			return;//�{�����_
		}
		
		/***************************3.�d�ߧ���,�ǳ����(Send the Success view)*************/
		req.setAttribute("traceVO", traceVO); // ��Ʈw���X��empVO����,�s�Jreq
		String url = "/trace/listAllByMemedno.jsp";
		RequestDispatcher successView = req.getRequestDispatcher(url); // ���\��� listOneEmp.jsp
		successView.forward(req, res);

		/***************************��L�i�઺���~�B�z*************************************/
	} catch (Exception e) {
		errorMsgs.add("�L�k���o���:" + e.getMessage());
		RequestDispatcher failureView = req
				.getRequestDispatcher("/trace/select_page.jsp");
		failureView.forward(req, res);
	}
}	

if ("insertByJson".equals(req.getParameter("action"))) { // �Ӧ�addEmp.jsp���ШD
	try {
		/***********************
		 * 1.�����ШD�Ѽ� - ��J�榡�����~�B�z
		 *************************/
		String str = req.getParameter("memno");
		String str1 = req.getParameter("memedno");
		Integer memno = new Integer(str);
		Integer memedno = new Integer(str1);
		
//		TraceVO traceVO = new TraceVO();
//		traceVO.setMemno(memno);
//		traceVO.setMemedno(memedno);
		/***************************
		 * 2.�}�l�s�W���
		 ***************************************/
		TraceService traceSvc = new TraceService();
		traceSvc.addTrace(memno, memedno);
		/***************************
		 * 3.�s�W����,�ǳ����(Send the Success view)
		 ***********/
		PrintWriter out = res.getWriter();
		out.print("�w���\�s�W:"+str1);
		/*************************** ��L�i�઺���~�B�z **********************************/
	} catch (Exception e) {
		PrintWriter out = res.getWriter();
		out.print("�s�W����:�w�s�W�L");
	}
}

if ("delete2".equals(req.getParameter("action"))) { // �Ӧ�addEmp.jsp���ШD
	try {
		/***************************1.�����ШD�Ѽ�***************************************/
		Integer traceno = new Integer(req.getParameter("traceno"));
		
		/***************************2.�}�l�R�����***************************************/
		TraceService traceSvc = new TraceService();
		traceSvc.deleteTrace(traceno);
		
		/***************************3.�R������,�ǳ����(Send the Success view)***********/								
		String url = "/front-end/memberPage.jsp";
		RequestDispatcher successView = req.getRequestDispatcher(url);// �R�����\��,���^�e�X�R�����ӷ�����
		successView.forward(req, res);
		/*************************** ��L�i�઺���~�B�z **********************************/
	} catch (Exception e) {
//		RequestDispatcher failureView = req.getRequestDispatcher("/personalMsg/addPersonalMsg.jsp");
//		failureView.forward(req, res);
	}
}
		
	}
}


