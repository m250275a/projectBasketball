package com.trace.model;

import java.util.List;

import com.trace.model.TraceVO;

public class TraceService {
		
	private TraceDAO_interface dao ; 
	
	public TraceService (){
		dao = new TraceDAO();
	}
	
	public TraceVO addTrace(Integer memno,Integer memedno){
		
		TraceVO traceVO = new TraceVO();
		traceVO.setMemno(memno);
		traceVO.setMemedno(memedno);
		dao.insert(traceVO);
		
		return traceVO;
	}
	
	public TraceVO updateTrace(Integer traceno,Integer memno,Integer memedno){
		
		TraceVO traceVO = new TraceVO();
		traceVO.setTraceno(traceno);
		traceVO.setMemno(memno);
		traceVO.setMemedno(memedno);
		dao.update(traceVO);
		
		return traceVO;
	}
	
	public void deleteTrace(Integer traceno){
		dao.delete(traceno);
		
	}
	public TraceVO getOneTrace(Integer traceno){
		return dao.findByPrimaryKey(traceno);

	}
	
	public List<TraceVO> getAll() {
		return dao.getAll();
	}
	
	public List<TraceVO> getByMemno(Integer memno) {
		return dao.getByMemno(memno);
	}
	
	public List<TraceVO> getByMemedno(Integer memedno) {
		return dao.getByMemedno(memedno);
	}
	public int getCount(Integer memno){
		return dao.getCount(memno);
	}
}
