package com.trace.model;

import java.io.Serializable;

public class TraceVO implements Serializable{
	private Integer traceno;
	private Integer memno ;
	private Integer memedno ;
	
	public Integer getTraceno() {
		return traceno;
	}
	public void setTraceno(Integer traceno) {
		this.traceno = traceno;
	}
	public Integer getMemno() {
		return memno;
	}
	public void setMemno(Integer memno) {
		this.memno = memno;
	}
	public Integer getMemedno() {
		return memedno;
	}
	public void setMemedno(Integer memedno) {
		this.memedno = memedno;
	}
	
	
}
