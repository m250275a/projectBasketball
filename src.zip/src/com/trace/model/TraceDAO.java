package com.trace.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class TraceDAO implements TraceDAO_interface {
	
	// �@�����ε{����,�w��@�Ӹ�Ʈw ,�@�Τ@��DataSource�Y�i
		private static DataSource ds = null;
		static {
			try {
				Context ctx = new InitialContext();
				ds = (DataSource) ctx.lookup("java:comp/env/jdbc/TestDB");
			} catch (NamingException e) {
				e.printStackTrace();
			}
		}
	
	private static final String INSERT_STMT = 
			"INSERT INTO trace (traceno,memno,memedno) VALUES (Trace_SEQ.nextval,?,?)";
		private static final String GET_ALL_STMT = 
			"SELECT traceno,memno,memedno FROM trace order by traceno";
		private static final String GET_ONE_STMT = 
			"SELECT traceno,memno,memedno FROM trace where traceno = ?";
		private static final String DELETE = 
			"DELETE FROM trace where traceno = ?";
		private static final String UPDATE = 
			"UPDATE trace set memno=?, memedno=? where traceno = ?";
		private static final String GET_BY_MEMNO = 
				"SELECT traceno,memno,memedno FROM trace where memno = ?";
		private static final String GET_BY_MEMEDNO = 
				"SELECT traceno,memno,memedno FROM trace where memedno = ?";
	@Override
	public void insert(TraceVO traceVO) {
		Connection con = null;
		PreparedStatement pstmt = null;

		try {

			con = ds.getConnection();
			pstmt = con.prepareStatement(INSERT_STMT);

			pstmt.setInt(1,traceVO.getMemno());
			pstmt.setInt(2,traceVO.getMemedno());

			pstmt.executeUpdate();

			// Handle any driver errors
		} catch (SQLException se) {
			throw new RuntimeException("A database error occured. "
					+ se.getMessage());
			// Clean up JDBC resources
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					e.printStackTrace(System.err);
				}
			}
		}
		
		
	}

	@Override
	public void update(TraceVO traceVO) {
		Connection con = null;
		PreparedStatement pstmt = null;

		try {

			con = ds.getConnection();
			pstmt = con.prepareStatement(UPDATE);

			pstmt.setInt(1,traceVO.getMemno());
			pstmt.setInt(2,traceVO.getMemedno());
			pstmt.setInt(3,traceVO.getTraceno());

			pstmt.executeUpdate();

			// Handle any driver errors
		} catch (SQLException se) {
			throw new RuntimeException("A database error occured. "
					+ se.getMessage());
			// Clean up JDBC resources
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					e.printStackTrace(System.err);
				}
			}
		}
		
	}

	@Override
	public void delete(Integer traceno) {
		Connection con = null;
		PreparedStatement pstmt = null;

		try {

			con = ds.getConnection();
			pstmt = con.prepareStatement(DELETE);

			pstmt.setInt(1, traceno);

			pstmt.executeUpdate();

			// Handle any driver errors
		} catch (SQLException se) {
			throw new RuntimeException("A database error occured. "
					+ se.getMessage());
			// Clean up JDBC resources
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					e.printStackTrace(System.err);
				}
			}
		}
		
		
	}

	@Override
	public TraceVO findByPrimaryKey(Integer traceno) {
		TraceVO traceVO = null;
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {

			con = ds.getConnection();
			pstmt = con.prepareStatement(GET_ONE_STMT);

			pstmt.setInt(1, traceno);

			rs = pstmt.executeQuery();
			
			while (rs.next()) {
				// empVo �]�٬� Domain objects
				traceVO = new TraceVO();
				traceVO.setTraceno(rs.getInt("traceno"));
				traceVO.setMemno(rs.getInt("memno"));
				traceVO.setMemedno(rs.getInt("memedno"));
			}

			// Handle any driver errors
		} catch (SQLException se) {
			throw new RuntimeException("A database error occured. "
					+ se.getMessage());
			// Clean up JDBC resources
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					e.printStackTrace(System.err);
				}
			}
		}
		return traceVO;
	}

	@Override
	public List<TraceVO> getAll() {
		List<TraceVO> list = new ArrayList<TraceVO>();
		TraceVO traceVO = null;

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {

			con = ds.getConnection();
			pstmt = con.prepareStatement(GET_ALL_STMT);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				// empVO �]�٬� Domain objects
				traceVO = new TraceVO();
				traceVO.setTraceno(rs.getInt("traceno"));
				traceVO.setMemno(rs.getInt("memno"));
				traceVO.setMemedno(rs.getInt("memedno"));
				list.add(traceVO); // Store the row in the list
			}

			// Handle any driver errors
		} catch (SQLException se) {
			throw new RuntimeException("A database error occured. "
					+ se.getMessage());
			// Clean up JDBC resources
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					e.printStackTrace(System.err);
				}
			}
		}
		return list;
	}

	public List<TraceVO> getByMemno(Integer memno){
		TraceVO traceVO = null;
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<TraceVO> list = new ArrayList<TraceVO>();
		try {

			con = ds.getConnection();
			pstmt = con.prepareStatement(GET_BY_MEMNO);

			pstmt.setInt(1, memno);

			rs = pstmt.executeQuery();
			
			while (rs.next()) {
				// empVo �]�٬� Domain objects
				traceVO = new TraceVO();
				traceVO.setTraceno(rs.getInt("traceno"));
				traceVO.setMemno(rs.getInt("memno"));
				traceVO.setMemedno(rs.getInt("memedno"));
				list.add(traceVO); // Store the row in the list
			}

			// Handle any driver errors
		} catch (SQLException se) {
			throw new RuntimeException("A database error occured. "
					+ se.getMessage());
			// Clean up JDBC resources
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					e.printStackTrace(System.err);
				}
			}
		}
		return list;
		
	}

	@Override
	public List<TraceVO> getByMemedno(Integer memedno) {
		TraceVO traceVO = null;
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<TraceVO> list = new ArrayList<TraceVO>();
		try {

			con = ds.getConnection();
			pstmt = con.prepareStatement(GET_BY_MEMEDNO);

			pstmt.setInt(1, memedno);

			rs = pstmt.executeQuery();
			
			while (rs.next()) {
				// empVo �]�٬� Domain objects
				traceVO = new TraceVO();
				traceVO.setTraceno(rs.getInt("traceno"));
				traceVO.setMemno(rs.getInt("memno"));
				traceVO.setMemedno(rs.getInt("memedno"));
				list.add(traceVO); // Store the row in the list
			}

			// Handle any driver errors
		} catch (SQLException se) {
			throw new RuntimeException("A database error occured. "
					+ se.getMessage());
			// Clean up JDBC resources
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					e.printStackTrace(System.err);
				}
			}
		}
		return list;
	}

	@Override
	public int getCount(Integer memno) {
		TraceVO traceVO = null;
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<TraceVO> list = new ArrayList<TraceVO>();
		int count = 0;
		try {

			con = ds.getConnection();
			pstmt = con.prepareStatement(GET_BY_MEMEDNO);

			pstmt.setInt(1, memno);

			rs = pstmt.executeQuery();
			
			while (rs.next()) {
				// empVo �]�٬� Domain objects
				traceVO = new TraceVO();
				traceVO.setTraceno(rs.getInt("traceno"));
				traceVO.setMemno(rs.getInt("memno"));
				traceVO.setMemedno(rs.getInt("memedno"));
				list.add(traceVO); // Store the row in the list
				++count;
			}

			// Handle any driver errors
		} catch (SQLException se) {
			throw new RuntimeException("A database error occured. "
					+ se.getMessage());
			// Clean up JDBC resources
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					e.printStackTrace(System.err);
				}
			}
		}
		return count;
	}
}
