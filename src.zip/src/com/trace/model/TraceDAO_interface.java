package com.trace.model;

import java.util.List;


public interface TraceDAO_interface {
	public void insert(TraceVO traceVO);
    public void update(TraceVO traceVO);
    public void delete(Integer traceno);
    public TraceVO findByPrimaryKey(Integer traceno);
    public List<TraceVO> getAll();
    public List<TraceVO> getByMemno(Integer memno);
    public List<TraceVO> getByMemedno(Integer memedno);
    public int getCount(Integer memno);
    //�U�νƦX�d��(�ǤJ�Ѽƫ��AMap)(�^�� List)
//  public List<EmpVO> getAll(Map<String, String[]> map);
}
