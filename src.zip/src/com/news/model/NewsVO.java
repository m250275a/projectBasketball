package com.news.model;

import java.sql.*;

public class NewsVO implements java.io.Serializable {
	private Integer newsno;
	private Date newsdate;
	private String newscon;
	private String newsfullcon;
	private byte [] newsimg;
	public Integer getNewsno() {
		return newsno;
	}
	public void setNewsno(Integer newsno) {
		this.newsno = newsno;
	}
	public Date getNewsdate() {
		return newsdate;
	}
	public void setNewsdate(Date newsdate) {
		this.newsdate = newsdate;
	}
	public String getNewscon() {
		return newscon;
	}
	public void setNewscon(String newscon) {
		this.newscon = newscon;
	}
	public String getNewsfullcon() {
		return newsfullcon;
	}
	public void setNewsfullcon(String newsfullcon) {
		this.newsfullcon = newsfullcon;
	}
	public byte[] getNewsimg() {
		return newsimg;
	}
	public void setNewsimg(byte[] newsimg) {
		this.newsimg = newsimg;
	}

}
