package com.news.model;

import java.util.List;

public class NewsService {
	
	private NewsDAO_interface dao;

	public NewsService() {
		dao = new NewsJNDIDAO();
	}

	public NewsVO addNews(String newscon, String newsfullcon, byte[] newsimg) {
		
		NewsVO newsVO = new NewsVO();

		newsVO.setNewscon(newscon);
		newsVO.setNewsfullcon(newsfullcon);
		newsVO.setNewsimg(newsimg);
		dao.insert(newsVO);

		return newsVO;
	}

	public NewsVO updateNews(Integer newsno, java.sql.Date newsdate, String newscon, String newsfullcon, byte[] newsimg) {
		NewsVO newsVO = new NewsVO();

		newsVO.setNewsno(newsno);
		newsVO.setNewsdate(newsdate);
		newsVO.setNewscon(newscon);
		newsVO.setNewsfullcon(newsfullcon);
		newsVO.setNewsimg(newsimg);
		dao.update(newsVO);

		return newsVO;
	}

	public void deleteNews(Integer newsno) {
		dao.delete(newsno);
	}

	public NewsVO getOneNews(Integer newsno) {
		return dao.findByPrimaryKey(newsno);
	}

	public List<NewsVO> getAll() {
		return dao.getAll();
	}
}
