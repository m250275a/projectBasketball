package com.admin.model;

public class AdminVO implements java.io.Serializable{
	private Integer adminno;
	private String  adminname;
	private String  adminvarname;
	private String  adminid;
	private String  adminphone;
	private String  adminaddr;
	private String  adminpsw ;
	private String  adminemail;
	private String  adminlevel;
	
	
	/**
	 * @return the adminno
	 */
	public Integer getAdminno() {
		return adminno;
	}
	/**
	 * @param adminno the adminno to set
	 */
	public void setAdminno(Integer adminno) {
		this.adminno = adminno;
	}
	/**
	 * @return the adminname
	 */
	public String getAdminname() {
		return adminname;
	}
	/**
	 * @param adminname the adminname to set
	 */
	public void setAdminname(String adminname) {
		this.adminname = adminname;
	}
	/**
	 * @return the adminvarname
	 */
	public String getAdminvarname() {
		return adminvarname;
	}
	/**
	 * @param adminvarname the adminvarname to set
	 */
	public void setAdminvarname(String adminvarname) {
		this.adminvarname = adminvarname;
	}
	/**
	 * @return the adminid
	 */
	public String getAdminid() {
		return adminid;
	}
	/**
	 * @param adminid the adminid to set
	 */
	public void setAdminid(String adminid) {
		this.adminid = adminid;
	}
	/**
	 * @return the adminphone
	 */
	public String getAdminphone() {
		return adminphone;
	}
	/**
	 * @param adminphone the adminphone to set
	 */
	public void setAdminphone(String adminphone) {
		this.adminphone = adminphone;
	}
	/**
	 * @return the adminaddr
	 */
	public String getAdminaddr() {
		return adminaddr;
	}
	/**
	 * @param adminaddr the adminaddr to set
	 */
	public void setAdminaddr(String adminaddr) {
		this.adminaddr = adminaddr;
	}
	/**
	 * @return the adminpsw
	 */
	public String getAdminpsw() {
		return adminpsw;
	}
	/**
	 * @param adminpsw the adminpsw to set
	 */
	public void setAdminpsw(String adminpsw) {
		this.adminpsw = adminpsw;
	}
	/**
	 * @return the adminemail
	 */
	public String getAdminemail() {
		return adminemail;
	}
	/**
	 * @param adminemail the adminemail to set
	 */
	public void setAdminemail(String adminemail) {
		this.adminemail = adminemail;
	}
	/**
	 * @return the adminlevel
	 */
	public String getAdminlevel() {
		return adminlevel;
	}
	/**
	 * @param adminlevel the adminlevel to set
	 */
	public void setAdminlevel(String adminlevel) {
		this.adminlevel = adminlevel;
	}
	
	
	
}