package com.videopicture.model;

import java.util.*;
import java.io.File;
import java.io.FileInputStream;
import java.sql.*;
import java.util.Date;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class VideoPictureDAO implements VideoPictureDAO_interface {

	// �@�����ε{����,�w��@�Ӹ�Ʈw ,�@�Τ@��DataSource�Y�i
		private static DataSource ds = null;
		static {
			try {
				Context ctx = new InitialContext();
				ds = (DataSource) ctx.lookup("java:comp/env/jdbc/TestDB");
			} catch (NamingException e) {
				e.printStackTrace();
			}
		}

	private static final String INSERT_STMT = "INSERT INTO Videopicture (vpno,vptitle,memno,vpmsg,vpfile,vptype,vpdate,visitnum) "
			+ "VALUES (videopicture_seq.NEXTVAL, ?, ?, ?, ?, ?, ?, ?)";
	private static final String GET_ALL_STMT = "SELECT vpno,vptitle,memno,vpmsg,vpfile,vptype,to_char(vpdate,'yyyy-mm-dd hh:mi:ss')vpdate,visitnum FROM Videopicture order by vpno";
	private static final String GET_ONE_STMT = "SELECT vpno,vptitle,memno,vpmsg,vpfile,vptype,to_char(vpdate,'yyyy-mm-dd hh:mi:ss')vpdate,visitnum FROM Videopicture where vpno= ?";
	private static final String GET_BYMEMNO_STMT = "SELECT vpno,vptitle,memno,vpmsg,vpfile,vptype,to_char(vpdate,'yyyy-mm-dd hh:mi:ss')vpdate,visitnum FROM Videopicture where memno= ?";
	private static final String DELETE = "DELETE FROM Videopicture where vpno = ?";
	private static final String UPDATE = "UPDATE Videopicture set vptitle=?, memno=?, vpmsg=?, vpfile=?, vptype=?, vpdate=?, visitnum=? where vpno =?";
    private static final String UPDATEvisitnum = "UPDATE Videopicture set visitnum=? WHERE vpno=?";
	@Override
	public void insert(VideoPictureVO videoPictureVO) {

		Connection con = null;
		PreparedStatement pstmt = null;

		try {

			con = ds.getConnection();
			pstmt = con.prepareStatement(INSERT_STMT);

			pstmt.setString(1, videoPictureVO.getVptitle());
			pstmt.setInt(2, videoPictureVO.getMemno());
			pstmt.setString(3, videoPictureVO.getVpmsg());
			pstmt.setBytes(4, videoPictureVO.getVpfile());
			pstmt.setString(5, videoPictureVO.getVptype());
			pstmt.setTimestamp(6, videoPictureVO.getVpdate());
			pstmt.setInt(7, videoPictureVO.getVisitnum());

			pstmt.executeUpdate();

			// Handle any SQL errors
		} catch (SQLException se) {
			throw new RuntimeException("A database error occured. " + se.getMessage());
			// Clean up JDBC resources
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					e.printStackTrace(System.err);
				}
			}
		}

	}

	@Override
	public void update(VideoPictureVO videoPictureVO) {

		Connection con = null;
		PreparedStatement pstmt = null;

		try {

			con = ds.getConnection();
			pstmt = con.prepareStatement(UPDATE);

			pstmt.setString(1, videoPictureVO.getVptitle());
			pstmt.setInt(2, videoPictureVO.getMemno());
			pstmt.setString(3, videoPictureVO.getVpmsg());
			pstmt.setBytes(4, videoPictureVO.getVpfile());
			pstmt.setString(5, videoPictureVO.getVptype());
			pstmt.setTimestamp(6, videoPictureVO.getVpdate());
			pstmt.setInt(7, videoPictureVO.getVisitnum());
			pstmt.setInt(8, videoPictureVO.getVpno());

			pstmt.executeUpdate();

			// Handle any SQL errors
		} catch (SQLException se) {
			throw new RuntimeException("A database error occured. " + se.getMessage());
			// Clean up JDBC resources
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					e.printStackTrace(System.err);
				}
			}
		}

	}

	@Override
	public void delete(Integer vpno) {

		Connection con = null;
		PreparedStatement pstmt = null;

		try {

			con = ds.getConnection();
			pstmt = con.prepareStatement(DELETE);

			pstmt.setInt(1, vpno);

			pstmt.executeUpdate();

			// Handle any SQL errors
		} catch (SQLException se) {
			throw new RuntimeException("A database error occured. " + se.getMessage());
			// Clean up JDBC resources
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					e.printStackTrace(System.err);
				}
			}
		}

	}

	@SuppressWarnings("resource")
	@Override
	public VideoPictureVO findByPrimaryKey(Integer vpno) {

		VideoPictureVO videoPictureVO = null;
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {

			con = ds.getConnection();
			pstmt = con.prepareStatement(GET_ONE_STMT);

			pstmt.setInt(1, vpno);

			rs = pstmt.executeQuery();

			while (rs.next()) {
				// empVo �]�٬� Domain objects
				videoPictureVO = new VideoPictureVO();
				videoPictureVO.setVpno(rs.getInt("vpno"));
				videoPictureVO.setVptitle(rs.getString("vptitle"));
				videoPictureVO.setMemno(rs.getInt("memno"));
				videoPictureVO.setVpmsg(rs.getString("vpmsg"));
				videoPictureVO.setVpfile(rs.getBytes("vpfile"));
				videoPictureVO.setVptype(rs.getString("vptype"));
				videoPictureVO.setVpdate(rs.getTimestamp("vpdate")); 
				videoPictureVO.setVisitnum(rs.getInt("visitnum")+1);
			}
			
			//�s���H��
//			pstmt = con.prepareStatement(UPDATEvisitnum);
//			pstmt.setInt(1, videoPictureVO.getVisitnum());
//			pstmt.setInt(2, videoPictureVO.getVpno());
//			pstmt.executeUpdate();

			// Handle any SQL errors
		} catch (SQLException se) {
			throw new RuntimeException("A database error occured. " + se.getMessage());
			// Clean up JDBC resources
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					e.printStackTrace(System.err);
				}
			}
		}
		return videoPictureVO;
	}

	@Override
	public List<VideoPictureVO> getAll() {
		List<VideoPictureVO> list = new ArrayList<VideoPictureVO>();
		VideoPictureVO videoPictureVO = null;

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {

			con = ds.getConnection();
			pstmt = con.prepareStatement(GET_ALL_STMT);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				// empVO �]�٬� Domain objects
				videoPictureVO = new VideoPictureVO();
				videoPictureVO.setVpno(rs.getInt("vpno"));
				videoPictureVO.setVptitle(rs.getString("vptitle"));
				videoPictureVO.setMemno(rs.getInt("memno"));
				videoPictureVO.setVpmsg(rs.getString("vpmsg"));
				videoPictureVO.setVpfile(rs.getBytes("vpfile"));
				videoPictureVO.setVptype(rs.getString("vptype"));
				videoPictureVO.setVpdate(rs.getTimestamp("vpdate"));
				videoPictureVO.setVisitnum(rs.getInt("visitnum"));
				list.add(videoPictureVO); // Store the row in the list
			}

			// Handle any SQL errors
		} catch (SQLException se) {
			throw new RuntimeException("A database error occured. " + se.getMessage());
			// Clean up JDBC resources
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					e.printStackTrace(System.err);
				}
			}
		}
		return list;
	}

	@Override
	public List<VideoPictureVO> getByMemno(Integer memno) {
		List<VideoPictureVO> list = new ArrayList<VideoPictureVO>();
		VideoPictureVO videoPictureVO = null;

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {

			con = ds.getConnection();
			pstmt = con.prepareStatement(GET_BYMEMNO_STMT);
			pstmt.setInt(1, memno);

			rs = pstmt.executeQuery();

			while (rs.next()) {
				// empVO �]�٬� Domain objects
				videoPictureVO = new VideoPictureVO();
				videoPictureVO.setVpno(rs.getInt("vpno"));
				videoPictureVO.setVptitle(rs.getString("vptitle"));
				videoPictureVO.setMemno(rs.getInt("memno"));
				videoPictureVO.setVpmsg(rs.getString("vpmsg"));
				videoPictureVO.setVpfile(rs.getBytes("vpfile"));
				videoPictureVO.setVptype(rs.getString("vptype"));
				videoPictureVO.setVpdate(rs.getTimestamp("vpdate"));
				videoPictureVO.setVisitnum(rs.getInt("visitnum"));
				list.add(videoPictureVO); // Store the row in the list
			}

			// Handle any SQL errors
		} catch (SQLException se) {
			throw new RuntimeException("A database error occured. " + se.getMessage());
			// Clean up JDBC resources
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					e.printStackTrace(System.err);
				}
			}
		}
		return list;
	}


}