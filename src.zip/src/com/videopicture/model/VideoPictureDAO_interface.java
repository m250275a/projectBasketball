package com.videopicture.model;

import java.util.*;

public interface VideoPictureDAO_interface {
	public void insert(VideoPictureVO videoPictureVO);
    public void update(VideoPictureVO videoPictureVO);
    public void delete(Integer vpno);
    public VideoPictureVO findByPrimaryKey(Integer vpno);
    public List<VideoPictureVO> getAll();
    public List<VideoPictureVO> getByMemno(Integer memno);
    //�U�νƦX�d��(�ǤJ�Ѽƫ��AMap)(�^�� List)
//  public List<EmpVO> getAll(Map<String, String[]> map); 

}
