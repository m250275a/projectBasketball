package com.videopicture.model;

import java.sql.*;

public class VideoPictureVO implements java.io.Serializable {
	private Integer vpno;
	private String  vptitle;
	private Integer memno;
	private String  vpmsg;
    private byte[]  vpfile;
    private String  vptype;
    private Timestamp    vpdate;
    private Integer visitnum;
	
    
    
    
    public Integer getVpno() {
		return vpno;
	}
	public void setVpno(Integer vpno) {
		this.vpno = vpno;
	}
	public String getVptitle() {
		return vptitle;
	}
	public void setVptitle(String vptitle) {
		this.vptitle = vptitle;
	}
	public Integer getMemno() {
		return memno;
	}
	public void setMemno(Integer memno) {
		this.memno = memno;
	}
	public String getVpmsg() {
		return vpmsg;
	}
	public void setVpmsg(String vpmsg) {
		this.vpmsg = vpmsg;
	}
	public byte[] getVpfile() {
		return vpfile;
	}
	public void setVpfile(byte[] vpfile) {
		this.vpfile = vpfile;
	}
	public String getVptype() {
		return vptype;
	}
	public void setVptype(String vptype) {
		this.vptype = vptype;
	}
	public Timestamp getVpdate() {
		return vpdate;
	}
	public void setVpdate(Timestamp vpdate) {
		this.vpdate = vpdate;
	}
	public Integer getVisitnum() {
		return visitnum;
	}
	public void setVisitnum(Integer visitnum) {
		this.visitnum = visitnum;
	}
    
    
    
    
}
