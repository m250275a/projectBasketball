package com.videopicture.model;

import java.sql.Timestamp;
import java.util.List;

public class VideoPictureService {

	private VideoPictureDAO_interface dao;

	public VideoPictureService() {
		dao = new VideoPictureDAO();
	}

	public VideoPictureVO addVideoPicture(String vptitle, Integer memno, String vpmsg, byte[] vpfile,
			String vptype, Timestamp vpdate, Integer visitnum) {

		VideoPictureVO videoPictureVO = new VideoPictureVO();

		videoPictureVO.setVptitle(vptitle);
		videoPictureVO.setMemno(memno);
		videoPictureVO.setVpmsg(vpmsg);
		videoPictureVO.setVpfile(vpfile);
		videoPictureVO.setVptype(vptype);
		videoPictureVO.setVpdate(vpdate);
		videoPictureVO.setVisitnum(visitnum);
		dao.insert(videoPictureVO);

		return videoPictureVO;
	}

	public VideoPictureVO updateVideoPicture(Integer vpno, String vptitle, Integer memno, String vpmsg, byte[] vpfile,
			String vptype, Timestamp vpdate, Integer visitnum) {

		VideoPictureVO videoPictureVO = new VideoPictureVO();

		videoPictureVO.setVpno(vpno);
		videoPictureVO.setVptitle(vptitle);
		videoPictureVO.setMemno(memno);
		videoPictureVO.setVpmsg(vpmsg);
		videoPictureVO.setVpfile(vpfile);
		videoPictureVO.setVptype(vptype);
		videoPictureVO.setVpdate(vpdate);
		videoPictureVO.setVisitnum(visitnum);
		dao.update(videoPictureVO);

		return videoPictureVO;
	}

	public void deleteVideoPicture(Integer vpno) {
		dao.delete(vpno);
	}

	public VideoPictureVO getOneVideoPicture(Integer vpno) {
		return dao.findByPrimaryKey(vpno);
	}

	public List<VideoPictureVO> getAll() {
		return dao.getAll();
	}
	
	public List<VideoPictureVO> getByMemno(Integer memno) {
		return dao.getByMemno(memno);
	}
}
