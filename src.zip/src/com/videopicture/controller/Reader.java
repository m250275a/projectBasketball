package com.videopicture.controller;

import java.io.*;
import java.sql.*;

import javax.naming.Context;
import javax.naming.NamingException;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.sql.DataSource;


public class Reader extends HttpServlet {

	Connection con;

	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		doGet(req, res);
	}

	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		String type = null;
		req.setCharacterEncoding("Big5");
		ServletOutputStream out = res.getOutputStream();

		try {
			Statement stmt = con.createStatement();
			 String vpno = req.getParameter("vpno");
			 String vpno1 = new String(vpno.getBytes("ISO-8859-1"), "Big5");
			 ResultSet rs = stmt.executeQuery("SELECT vpfile, vptype FROM Videopicture WHERE vpno='" +vpno1+ "' ");

			if (rs.next()) {
                
				//�ʺA����contentype
				type ="."+ rs.getString("vptype");
				String contentType = getServletContext().getMimeType(type);
				res.setContentType(contentType);  
			
				BufferedInputStream in = new BufferedInputStream(rs.getBinaryStream("vpfile"));
				byte[] buf = new byte[4 * 1024]; // 4K buffer
				int len;
				while ((len = in.read(buf)) != -1) {
					out.write(buf, 0, len);
				}
				in.close();
			}

			rs.close();
			out.close();
			stmt.close();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e);
		}

	}

	public void init() throws ServletException {
		try {
			Context ctx = new javax.naming.InitialContext();
			DataSource ds = (DataSource) ctx.lookup("java:comp/env/jdbc/TestDB");
			con = ds.getConnection();
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void destroy() {
		try {
			if (con != null)
				con.close();
		} catch (SQLException e) {
			System.out.println(e);
		}
	}

}
