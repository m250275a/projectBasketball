package com.videopicture.controller;

import java.io.*;

import java.sql.Timestamp;
import java.util.*;

import javax.servlet.*;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.*;
import com.videopicture.model.VideoPictureService;
import com.videopicture.model.VideoPictureVO;

@MultipartConfig(fileSizeThreshold = 1 * 1024, maxFileSize = 10 * 1024 * 1024, maxRequestSize = 20 * 1024 * 1024)
// ���ƾڶq�j��fileSizeThreshold�ȮɡA���e�N�Q�g�J�Ϻ�
// �W�ǹL�{���L�׬O��Ӥ��W�LmaxFileSize�ȡA�Ϊ̤W�Ǫ��`�q�j��maxRequestSize �ȳ��|�ߥXIllegalStateException
// ���`

public class VideoPictureServlet extends HttpServlet {

	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		doPost(req, res);
	}

	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {

		req.setCharacterEncoding("UTF-8");
		String action = req.getParameter("action");

		if ("getOne_For_Display".equals(action)) { // �Ӧ�select_page.jsp���ШD

			List<String> errorMsgs = new LinkedList<String>();
			// Store this set in the request scope, in case we need to
			// send the ErrorPage view.
			req.setAttribute("errorMsgs", errorMsgs);

			try {
				/***************************
				 * 1.�����ШD�Ѽ� - ��J�榡�����~�B�z
				 **********************/
				String str = req.getParameter("vpno");
				if (str == null || (str.trim()).length() == 0) {
					errorMsgs.add("�п�J�ɮ׽s��");
				}
				// Send the use back to the form, if there were errors
				if (!errorMsgs.isEmpty()) {
					RequestDispatcher failureView = req.getRequestDispatcher("/videoPicture/select_page.jsp");
					failureView.forward(req, res);
					return;// �{�����_
				}

				Integer vpno = null;
				try {
					vpno = new Integer(str);
				} catch (Exception e) {
					errorMsgs.add("�ɮ׽s���榡�����T");
				}
				// Send the use back to the form, if there were errors
				if (!errorMsgs.isEmpty()) {
					RequestDispatcher failureView = req.getRequestDispatcher("/videoPicture/select_page.jsp");
					failureView.forward(req, res);
					return;// �{�����_
				}

				/***************************
				 * 2.�}�l�d�߸��
				 *****************************************/
				VideoPictureService videoPictureSvc = new VideoPictureService();
				VideoPictureVO videoPictureVO = videoPictureSvc.getOneVideoPicture(vpno);
				if (videoPictureVO == null) {
					errorMsgs.add("�d�L���");
				}
				// Send the use back to the form, if there were errors
				if (!errorMsgs.isEmpty()) {
					RequestDispatcher failureView = req.getRequestDispatcher("/videoPicture/select_page.jsp");
					failureView.forward(req, res);
					return;// �{�����_
				}

				/***************************
				 * 3.�d�ߧ���,�ǳ����(Send the Success view)
				 *************/
				req.setAttribute("videoPictureVO", videoPictureVO); // ��Ʈw���X��videoPictureVO����,�s�Jreq
				String url = "/videoPicture/listOneVideoPicture.jsp";
				RequestDispatcher successView = req.getRequestDispatcher(url); // ���\���listOneVideoPicture.jsp
				successView.forward(req, res);

				/*************************** ��L�i�઺���~�B�z *************************************/
			} catch (Exception e) {
				errorMsgs.add("�L�k���o���:" + e.getMessage());
				RequestDispatcher failureView = req.getRequestDispatcher("/videoPicture/select_page.jsp");
				failureView.forward(req, res);
			}
		}

		if ("getOne_For_Update".equals(action)) { // �Ӧ�listAllVideoPicture.jsp

			List<String> errorMsgs = new LinkedList<String>();
			// Store this set in the request scope, in case we need to
			// send the ErrorPage view.
			req.setAttribute("errorMsgs", errorMsgs);

			String requestURL = req.getParameter("requestURL");
			// �e�X�ק諸�ӷ��������|: �i�ର�i/videoPicture/listAllVideoPicture.jsp�j

			try {
				/***************************
				 * 1.�����ШD�Ѽ�
				 ****************************************/
				Integer vpno = new Integer(req.getParameter("vpno"));

				/***************************
				 * 2.�}�l�d�߸��
				 ****************************************/
				VideoPictureService videoPictureSvc = new VideoPictureService();
				VideoPictureVO videoPictureVO = videoPictureSvc.getOneVideoPicture(vpno);

				/***************************
				 * 3.�d�ߧ���,�ǳ����(Send the Success view)
				 ************/
				req.setAttribute("videoPictureVO", videoPictureVO); // ��Ʈw���X��videoPictureVO����,�s�Jreq
				String url = "/videoPicture/update_videoPicture_input.jsp";
				RequestDispatcher successView = req.getRequestDispatcher(url); // ���\���update_videoPicture_input.jsp
				successView.forward(req, res);

				/*************************** ��L�i�઺���~�B�z ************************************/
			} catch (Exception e) {
				errorMsgs.add("�ק��ƨ��X�ɥ���:" + e.getMessage());
				RequestDispatcher failureView = req.getRequestDispatcher(requestURL);
				failureView.forward(req, res);
			}
		}

		if ("update".equals(action)) { // �Ӧ�update_videoPicture_input.jsp���ШD

			List<String> errorMsgs = new LinkedList<String>();
			// Store this set in the request scope, in case we need to
			// send the ErrorPage view.
			req.setAttribute("errorMsgs", errorMsgs);

			String requestURL = req.getParameter("requestURL");
			// �e�X�ק諸�ӷ��������|: �i�ର�i/videoPicture/listAllVideoPicture.jsp�j

			try {
				/***************************
				 * 1.�����ШD�Ѽ� - ��J�榡�����~�B�z
				 **********************/
				Integer vpno = new Integer(req.getParameter("vpno").trim());
				String vptitle = req.getParameter("vptitle").trim();
				Integer memno = null;
				try {
					memno = new Integer(req.getParameter("memno").trim());
				} catch (NumberFormatException e) {
					memno = 0;
					errorMsgs.add("�п�J�|���s��");
				}
				String vpmsg = req.getParameter("vpmsg").trim();
				
				// �ק�Ϥ�/�v��
				Part part = req.getPart("vpfile");
				
				// ��3��O���o���ɦW�s�J��ƫ��A, getFileNameFromPart()�w�q�b�̤U��
				String vptype = null; 
				if (getFileNameFromPart(part)!= null && part.getContentType()!= null) {
					vptype = getFileNameFromPart(part);
				}
				//���oclient���ɮ�
				InputStream in = part.getInputStream();
				byte[] vpfile = new byte[in.available()];
				in.read(vpfile);

				Timestamp vpdate = java.sql.Timestamp.valueOf(req.getParameter("vpdate"));
				Integer visitnum = new Integer(req.getParameter("visitnum").trim());

				VideoPictureVO videoPictureVO = new VideoPictureVO();
				videoPictureVO.setVpno(vpno);
				videoPictureVO.setVptitle(vptitle);
				videoPictureVO.setMemno(memno);
				videoPictureVO.setVpmsg(vpmsg);
				videoPictureVO.setVpfile(vpfile);
				videoPictureVO.setVptype(vptype);
				videoPictureVO.setVpdate(vpdate);
				videoPictureVO.setVisitnum(visitnum);
				in.close();

				// Send the use back to the form, if there were errors
				if (!errorMsgs.isEmpty()) {
					req.setAttribute("videoPictureVO", videoPictureVO); // �t����J�榡���~��videoPictureVO����,�]�s�Jreq
					RequestDispatcher failureView = req
							.getRequestDispatcher("/videoPicture/update_videoPicture_input.jsp");
					failureView.forward(req, res);
					return; // �{�����_
				}
				

				/***************************
				 * 2.�}�l�ק���
				 *****************************************/
				VideoPictureService videoPictureSvc = new VideoPictureService();
				videoPictureVO = videoPictureSvc.updateVideoPicture(vpno, vptitle, memno, vpmsg, vpfile, vptype, vpdate,
						visitnum);

				/***************************
				 * 3.�ק粒��,�ǳ����(Send the Success view)
				 *************/
				// DeptService deptSvc = new DeptService();
				// if(requestURL.equals("/dept/listEmps_ByDeptno.jsp") ||
				// requestURL.equals("/dept/listAllDept.jsp"))
				// req.setAttribute("listEmps_ByDeptno",deptSvc.getEmpsByDeptno(deptno));
				// // ��Ʈw���X��list����,�s�Jrequest

				String url = requestURL;
				RequestDispatcher successView = req.getRequestDispatcher(url); // �ק令�\��,���^�e�X�ק諸�ӷ�����
				successView.forward(req, res);

				/*************************** ��L�i�઺���~�B�z *************************************/
			} catch (Exception e) {
				errorMsgs.add("�ק��ƥ���:" + e.getMessage());
				RequestDispatcher failureView = req.getRequestDispatcher("/videoPicture/update_videoPicture_input.jsp");
				failureView.forward(req, res);
			}
		}

		if ("insert".equals(action)) { // �Ӧ�addVideoPicture.jsp���ШD

			List<String> errorMsgs = new LinkedList<String>();
			// Store this set in the request scope, in case we need to
			// send the ErrorPage view.
			req.setAttribute("errorMsgs", errorMsgs);

			try {
				/***********************
				 * 1.�����ШD�Ѽ� - ��J�榡�����~�B�z
				 *************************/
				String vptitle = req.getParameter("vptitle").trim();
				Integer memno = null;
				try {
					memno = new Integer(req.getParameter("memno").trim());
				} catch (NumberFormatException e) {
					memno = 0;
					errorMsgs.add("�п�J�|���s��");
				}

				String vpmsg = req.getParameter("vpmsg").trim();

				// �s�W�v��/�Ϥ�
				Part part = req.getPart("vpfile");
				
				// ��3��O���o���ɦW�s�J��ƫ��A, getFileNameFromPart()�w�q�b�̤U��
				String vptype = null; 
				if (getFileNameFromPart(part)!= null && part.getContentType()!= null) {
					vptype = getFileNameFromPart(part);
				}
				//���oclient���ɮ�
				InputStream in = part.getInputStream();
				byte[] vpfile = new byte[in.available()];
				in.read(vpfile);

				Timestamp vpdate = java.sql.Timestamp.valueOf(req.getParameter("vpdate"));
				Integer visitnum = new Integer(req.getParameter("visitnum").trim());

				VideoPictureVO videoPictureVO = new VideoPictureVO();
				videoPictureVO.setVptitle(vptitle);
				videoPictureVO.setMemno(memno);
				videoPictureVO.setVpmsg(vpmsg);
				videoPictureVO.setVpfile(vpfile);
				videoPictureVO.setVptype(vptype);
				videoPictureVO.setVpdate(vpdate);
				videoPictureVO.setVisitnum(visitnum);
				in.close();

				// Send the use back to the form, if there were errors
				
				/***************************
				 * 2.�}�l�s�W���
				 ***************************************/
				VideoPictureService videoPictureSvc = new VideoPictureService();
				videoPictureVO = videoPictureSvc.addVideoPicture(vptitle, memno, vpmsg, vpfile, vptype, vpdate,
						visitnum);

				/***************************
				 * 3.�s�W����,�ǳ����(Send the Success view)
				 ***********/
				String url = "/videoPicture/listAllVideoPicture.jsp";
				RequestDispatcher successView = req.getRequestDispatcher(url); // �s�W���\�����listAllVideoPicture.jsp
				successView.forward(req, res);

				/*************************** ��L�i�઺���~�B�z **********************************/
			} catch (Exception e) {
				errorMsgs.add(e.getMessage());
				RequestDispatcher failureView = req.getRequestDispatcher("/videoPicture/addVideoPicture.jsp");
				failureView.forward(req, res);
			}
		}

		if ("delete".equals(action)) { // �Ӧ�listAllVideoPicture.jsp

			List<String> errorMsgs = new LinkedList<String>();
			// Store this set in the request scope, in case we need to
			// send the ErrorPage view.
			req.setAttribute("errorMsgs", errorMsgs);

			String requestURL = req.getParameter("requestURL");
			// �e�X�R�����ӷ��������|: �i�ର�i/videoPicture/listAllVideoPicture.jsp�j

			try {
				/***************************
				 * 1.�����ШD�Ѽ�
				 ***************************************/
				Integer vpno = new Integer(req.getParameter("vpno"));

				/***************************
				 * 2.�}�l�R�����
				 ***************************************/
				VideoPictureService videoPictureSvc = new VideoPictureService();
				//VideoPictureVO videoPictureVO = videoPictureSvc.getOneVideoPicture(vpno);
				videoPictureSvc.deleteVideoPicture(vpno);

				/***************************
				 * 3.�R������,�ǳ����(Send the Success view)
				 ***********/
				// DeptService deptSvc = new DeptService();
				// if(requestURL.equals("/dept/listEmps_ByDeptno.jsp") ||
				// requestURL.equals("/dept/listAllDept.jsp"))
				// req.setAttribute("listEmps_ByDeptno",deptSvc.getEmpsByDeptno(videoPictureVO.getDeptno()));
				// // ��Ʈw���X��list����,�s�Jrequest

				String url = "/front-end/memberPage.jsp";
				RequestDispatcher successView = req.getRequestDispatcher(url); // �R�����\��,���^�e�X�R�����ӷ�����
				successView.forward(req, res);

				/*************************** ��L�i�઺���~�B�z **********************************/
			} catch (Exception e) {
				errorMsgs.add("�R����ƥ���:" + e.getMessage());
				RequestDispatcher failureView = req.getRequestDispatcher(requestURL);
				failureView.forward(req, res);
			}
		}
	

	if ("insert2".equals(action)) { 
		List<String> errorMsgs = new LinkedList<String>();
		req.setAttribute("errorMsgs", errorMsgs);
		
		try {
			/***********************
			 * 1.�����ШD�Ѽ� - ��J�榡�����~�B�z
			 *************************/
			String vptitle = "����";
			Integer memno = null;
			memno = new Integer(req.getParameter("memno").trim());
			
			String vpmsg = req.getParameter("vpmsg");
			// �s�W�v��/�Ϥ�
			Part part = req.getPart("vpfile");			
			// ��3��O���o���ɦW�s�J��ƫ��A, getFileNameFromPart()�w�q�b�̤U��
			String vptype = null; 
			if (getFileNameFromPart(part)!= null && part.getContentType()!= null) {
				vptype = getFileNameFromPart(part);
			}
			//���oclient���ɮ�
			InputStream in = part.getInputStream();
			byte[] vpfile = new byte[in.available()];
			in.read(vpfile);

			Timestamp vpdate = new Timestamp(System.currentTimeMillis());
			Integer visitnum = 99;
			
			VideoPictureVO videoPictureVO = new VideoPictureVO();
			videoPictureVO.setVptitle(vptitle);
			videoPictureVO.setMemno(memno);
			videoPictureVO.setVpmsg(vpmsg);
			videoPictureVO.setVpfile(vpfile);
			videoPictureVO.setVptype(vptype);
			videoPictureVO.setVpdate(vpdate);
			videoPictureVO.setVisitnum(visitnum);
			in.close();
			
			if(videoPictureVO != null){
				errorMsgs.add("�Ӥ��w�W��!");
			}
			/***************************
			 * 2.�}�l�s�W���
			 ***************************************/
			VideoPictureService videoPictureSvc = new VideoPictureService();
			videoPictureVO = videoPictureSvc.addVideoPicture(vptitle, memno, vpmsg, vpfile, vptype, vpdate,
					visitnum);

			/***************************
			 * 3.�s�W����,�ǳ����(Send the Success view)
			 ***********/
			String url = "/front-end/memberPage.jsp";
			RequestDispatcher successView = req.getRequestDispatcher(url); // �s�W���\�����listAllVideoPicture.jsp
			successView.forward(req, res);

			/*************************** ��L�i�઺���~�B�z **********************************/
		} catch (Exception e) {
			
		}
	}
}	
	public String getFileNameFromPart(Part part) {
		String header = part.getHeader("content-disposition");
		String filename = new File(header.substring(header.lastIndexOf("=") + 2, header.length() - 1)).getName();
		int dotPos = filename.indexOf('.');
		String vptype = filename.substring(dotPos+1);
		if (filename.length() == 0) {
			String msg = "NO Date";
			return msg;
		}
		return vptype;
	}
}
