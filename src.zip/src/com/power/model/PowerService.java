package com.power.model;

import java.util.List;

import com.news.model.NewsVO;

public class PowerService {
	
	private PowerDAO_interface dao;

	public PowerService() {
		dao = new PowerJNDIDAO();
	}

	public PowerVO addPower(Integer adminno, Integer feano) {
		
		PowerVO powerVO = new PowerVO();

		powerVO.setAdminno(adminno);
		powerVO.setFeano(feano);
		
		dao.insert(powerVO);

		return powerVO;
	}

	public void deletePowerByVO(Integer adminno,Integer feano) {
		PowerVO powerVO = new PowerVO();

		powerVO.setAdminno(adminno);
		powerVO.setFeano(feano);
		dao.delete(powerVO);
	}
	
	public  List<PowerVO> getListByAdminno(Integer adminno) {
		return dao.findByPrimaryKey(adminno);
	}

	public List<PowerVO> getAll() {
		return dao.getAll();
	}
}
