package com.power.model;

import java.util.List;

public interface PowerDAO_interface {
	 public void insert(PowerVO powerVO);
     public void delete(PowerVO powerVO);
     public  List<PowerVO> findByPrimaryKey(Integer adminno);
     public List<PowerVO> getAll();
}
