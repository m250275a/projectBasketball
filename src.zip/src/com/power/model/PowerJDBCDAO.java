//package com.power.model;
//
//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.SQLException;
//import java.util.ArrayList;
//import java.util.List;
//
//import com.power.model.PowerJDBCDAO;
//import com.power.model.PowerVO;
//
//public class PowerJDBCDAO implements PowerDAO_interface{
//	String driver = "oracle.jdbc.driver.OracleDriver";
//	String url = "jdbc:oracle:thin:@localhost:1521:xe";
//	String userid = "aa103";
//	String passwd = "zzzz1111";
//	
//private static final String INSERT_STMT = "INSERT INTO power  VALUES (?,?)";
//	
//	//�R���Y���v��
//	private static final String DELETE = "DELETE FROM power where adminno =? and feano=? ";
//
//	// �d�ߥ����v��
//	private static final String GET_ALL_STMT ="select * from power where adminno=?";
//	
//	@Override
//	public int insert(PowerVO powerVO) {
//		int updateCount = 0;
//		Connection con = null;
//		PreparedStatement pstmt = null;
//		try {
//
//			Class.forName(driver);
//			con = DriverManager.getConnection(url, userid, passwd);
//			pstmt = con.prepareStatement(INSERT_STMT);
//			
//			pstmt.setInt(1, powerVO.getAdminno());
//			pstmt.setInt(2, powerVO.getFeano());
//			
//
//			updateCount = pstmt.executeUpdate();
//
//			// Handle any driver errors
//		} catch (ClassNotFoundException e) {
//			throw new RuntimeException("Couldn't load database driver. "
//					+ e.getMessage());
//			// Handle any SQL errors
//		} catch (SQLException se) {
//			throw new RuntimeException("A database error occured. "
//					+ se.getMessage());
//			// Clean up JDBC resources
//		} finally {
//			if (pstmt != null) {
//				try {
//					pstmt.close();
//				} catch (SQLException se) {
//					se.printStackTrace(System.err);
//				}
//			}
//			if (con != null) {
//				try {
//					con.close();
//				} catch (Exception e) {
//					e.printStackTrace(System.err);
//				}
//			}
//		}
//		
//		return updateCount;
//	}
//
//	@Override
//	   public int delete(Integer memno,Integer teamno) {
//		int updateCount = 0;
//		Connection con = null;
//		PreparedStatement pstmt = null;
//		try {
//			Class.forName(driver);
//			con = DriverManager.getConnection(url, userid, passwd);
//			pstmt = con.prepareStatement(DELETE);
//			
//			pstmt.setInt(1,memno);
//			pstmt.setInt(2,teamno);
//			
//
//			updateCount = pstmt.executeUpdate();
//
//			// Handle any driver errors
//		} catch (ClassNotFoundException e) {
//			throw new RuntimeException("Couldn't load database driver. "
//					+ e.getMessage());
//			// Handle any SQL errors
//		} catch (SQLException se) {
//			throw new RuntimeException("A database error occured. "
//					+ se.getMessage());
//			// Clean up JDBC resources
//		} finally {
//			if (pstmt != null) {
//				try {
//					pstmt.close();
//				} catch (SQLException se) {
//					se.printStackTrace(System.err);
//				}
//			}
//			if (con != null) {
//				try {
//					con.close();
//				} catch (Exception e) {
//					e.printStackTrace(System.err);
//				}
//			}
//		}
//		
//		return updateCount;
//	}
//
//	
//
//	
//	
//	@Override
//	public List<PowerVO> getAll(Integer memno) {
//		List<PowerVO> list = new ArrayList<PowerVO>();
//		PowerVO powerVO = null;
//
//		Connection con = null;
//		PreparedStatement pstmt = null;
//		ResultSet rs = null;
//		
//		try {
//			Class.forName(driver);
//			con = DriverManager.getConnection(url, userid, passwd);
//			pstmt = con.prepareStatement(GET_ALL_STMT);
//			pstmt.setInt(1,memno);
//			rs = pstmt.executeQuery();
//
//			while (rs.next()) {
//				
//				// memberVO �]�٬� Domain objects
//				powerVO = new PowerVO();
//				powerVO.setAdminno(rs.getInt("memno"));
//				powerVO.setFeano(rs.getInt("teamno"));
//				list.add(powerVO);
//			}
//
//			// Handle any driver errors
//		} catch (ClassNotFoundException e) {
//			throw new RuntimeException("Couldn't load database driver. "
//					+ e.getMessage());
//			// Handle any SQL errors
//		} catch (SQLException se) {
//			throw new RuntimeException("A database error occured. "
//					+ se.getMessage());
//			// Clean up JDBC resources
//		} finally {
//			if (rs != null) {
//				try {
//					rs.close();
//				} catch (SQLException se) {
//					se.printStackTrace(System.err);
//				}
//			}
//			if (pstmt != null) {
//				try {
//					pstmt.close();
//				} catch (SQLException se) {
//					se.printStackTrace(System.err);
//				}
//			}
//			if (con != null) {
//				try {
//					con.close();
//				} catch (Exception e) {
//					e.printStackTrace(System.err);
//				}
//			}
//		}
//		return list;
//	}	
//	
///////////////////////////////////////////////////////////////////////////////	
//	public static void main(String[] args) {
//		PowerJDBCDAO dao = new PowerJDBCDAO();
//		
////		 �s�W
////		//////////////////////////////////////////////////////////////
////		PowerVO powerVO1 = new PowerVO();
////		powerVO1.setAdminno(7003);
////		powerVO1.setFeano(7004);
////		int updateCount_insert=dao.insert(powerVO1);
////		System.out.println(updateCount_insert+"��new ok");
//		/////////////////////////////////////////////////////////////
//		
////		 �R��
//////		/////////////////////////////////////////////////////////////
////		int updateCount_delete = dao.delete(7003,7004);
////		 System.out.println(updateCount_delete+"��del OK");
//		////////////////////////////////////////////////////////////////////
//		
//		//�d����7001�n��
//		///////////////////////////////////////////////////////
////		List<PowerVO> list = dao.getAll(7001);
////		for (PowerVO aFeano : list) 
////		{
////		   System.out.print(aFeano.getFeano() + ",");
////		  
////		   System.out.println();
////		}
//	////////////////////////////////////////////////////////////////
//		
//		
//	}//main
//}//class