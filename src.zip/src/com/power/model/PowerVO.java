package com.power.model;

public class PowerVO implements java.io.Serializable{
	private Integer adminno;
	private Integer feano;
	
	
	
	public Integer getAdminno() {
		return adminno;
	}
	public void setAdminno(Integer adminno) {
		this.adminno = adminno;
	}
	public Integer getFeano() {
		return feano;
	}
	public void setFeano(Integer feano) {
		this.feano = feano;
	}
	@Override
	public int hashCode() {
		return (this.adminno.toString() + this.feano.toString()).hashCode();
	}
	@Override
	public boolean equals(Object obj) {
		PowerVO powerVO = (PowerVO)obj;
		
		return this.adminno.equals(powerVO.getAdminno())&&this.feano.equals(powerVO.getFeano());
	}
	
}
