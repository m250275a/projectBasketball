package com.power.controller;

import java.io.*;
import java.util.*;

import javax.servlet.*;
import javax.servlet.http.*;

import com.power.model.*;

public class PowerServlet extends HttpServlet {

	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		doPost(req, res);
	}

	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {

		req.setCharacterEncoding("UTF-8");
		res.setContentType("multipart/form-data; charset=UTF-8");
		String action = req.getParameter("action");

		String listAllAdmin = "/back-end/listAllAdmin.jsp";
		//////////////////////////////////////////////////////////////////////////////
		if ("update".equals(action)) { // �Ӧ�select_page.jsp���ШD

			List<String> errorMsgs = new LinkedList<String>();
			List<String> errorMsgs2 = new LinkedList<String>();
			// Store this set in the request scope, in case we need to
			// send the ErrorPage view.
			req.setAttribute("errorMsgs", errorMsgs);
			req.setAttribute("errorMsgs2", errorMsgs2);

			try {
				/***********************
				 * 1.�����ШD�Ѽ� - ��J�榡�����~�B�z
				 *************************/
				Integer adminno = new Integer(req.getParameter("adminno").trim());
				Integer feano = new Integer(req.getParameter("feano").trim());

				PowerService powerService = new PowerService();
				List<PowerVO> list = powerService.getListByAdminno(adminno);
				boolean status = false;
				for (PowerVO powerVO : list) {
					if (powerVO.getAdminno().equals(adminno) && powerVO.getFeano().equals(feano)) {
						status= true;
					}
				}
				if(status){
					powerService.deletePowerByVO(adminno, feano);
				}else{
					powerService.addPower(adminno, feano);
				}
				
				PowerVO powerVO = new PowerVO();
				powerVO.setAdminno(adminno);
				powerVO.setFeano(feano);

				// Send the use back to the form, if there were errors
				if (!errorMsgs.isEmpty()) {
					req.setAttribute("powerVO", powerVO); // �t����J�榡���~��powerVO����,�]�s�Jreq
					RequestDispatcher failureView = req.getRequestDispatcher(listAllAdmin);
					failureView.forward(req, res);
					return;
				}

				/***************************
				 * 2.�}�l�s�W���
				 ***************************************/
			

				/***************************
				 * 3.�s�W����,�ǳ����(Send the Success view)
				 ***********/

				RequestDispatcher successView = req.getRequestDispatcher(listAllAdmin); // �s�W���\�����listAllPower.jsp
				successView.forward(req, res);

				/*************************** ��L�i�઺���~�B�z **********************************/
			} catch (Exception e) {
				errorMsgs.add(e.getMessage());
				RequestDispatcher failureView = req.getRequestDispatcher(listAllAdmin);
				failureView.forward(req, res);
			}
		}
		/////////////////////////////////////////////////////////////////////////////
		if ("getOne_For_Display".equals(action)) { // �Ӧ�select_page.jsp���ШD

			List<String> errorMsgs = new LinkedList<String>();
			// Store this set in the request scope, in case we need to
			// send the ErrorPage view.
			req.setAttribute("errorMsgs", errorMsgs);

			try {
				/***************************
				 * 1.�����ШD�Ѽ� - ��J�榡�����~�B�z
				 **********************/
				String str = req.getParameter("adminno");
				if (str == null || (str.trim()).length() == 0) {
					errorMsgs.add("�п�J�s��");
				}
				// Send the use back to the form, if there were errors
				if (!errorMsgs.isEmpty()) {
					RequestDispatcher failureView = req.getRequestDispatcher(listAllAdmin);
					failureView.forward(req, res);
					return;// �{�����_
				}

				Integer adminno = null;
				try {
					adminno = new Integer(str);
				} catch (Exception e) {
					errorMsgs.add("�s���榡�����T");
				}
				// Send the use back to the form, if there were errors
				if (!errorMsgs.isEmpty()) {
					RequestDispatcher failureView = req.getRequestDispatcher(listAllAdmin);
					failureView.forward(req, res);
					return;// �{�����_
				}

				/***************************
				 * 2.�}�l�d�߸��
				 *****************************************/
				PowerService powerSvc = new PowerService();
				List<PowerVO> list = powerSvc.getListByAdminno(adminno);
				if (list == null) {
					errorMsgs.add("�d�L���");
				}
				// Send the use back to the form, if there were errors
				if (!errorMsgs.isEmpty()) {
					RequestDispatcher failureView = req.getRequestDispatcher(listAllAdmin);
					failureView.forward(req, res);
					return;// �{�����_
				}

				/***************************
				 * 3.�d�ߧ���,�ǳ����(Send the Success view)
				 *************/
				req.setAttribute("list", list); // ��Ʈw���X��powerVO����,�s�Jreq
				String url = "/power/listOnePower.jsp";
				RequestDispatcher successView = req.getRequestDispatcher(url); // ���\���listOnePower.jsp
				successView.forward(req, res);

				/*************************** ��L�i�઺���~�B�z *************************************/
			} catch (Exception e) {
				errorMsgs.add("�L�k���o���:" + e.getMessage());
				RequestDispatcher failureView = req.getRequestDispatcher("/select_page.jsp");
				failureView.forward(req, res);
			}
		}

		if ("getOne_For_Update".equals(action)) { // �Ӧ�listAllPower.jsp ��
													// /dept/listPowers_ByDeptno.jsp
													// ���ШD

			List<String> errorMsgs = new LinkedList<String>();
			// Store this set in the request scope, in case we need to
			// send the ErrorPage view.
			req.setAttribute("errorMsgs", errorMsgs);

			String requestURL = req.getParameter("requestURL"); // �e�X�ק諸�ӷ��������|:
																// �i�ର�i/power/listAllPower.jsp�j
																// ��
																// �i/dept/listPowers_ByDeptno.jsp�j
																// �� �i
																// /dept/listAllDept.jsp�j

			try {
				/***************************
				 * 1.�����ШD�Ѽ�
				 ****************************************/
				Integer adminno = new Integer(req.getParameter("adminno"));

				/***************************
				 * 2.�}�l�d�߸��
				 ****************************************/
				PowerService powerSvc = new PowerService();
				List<PowerVO> list = powerSvc.getListByAdminno(adminno);

				/***************************
				 * 3.�d�ߧ���,�ǳ����(Send the Success view)
				 ************/
				req.setAttribute("list", list); // ��Ʈw���X��powerVO����,�s�Jreq
				String url = "/power/update_power_input.jsp";
				RequestDispatcher successView = req.getRequestDispatcher(url); // ���\���update_power_input.jsp
				successView.forward(req, res);

				/*************************** ��L�i�઺���~�B�z ************************************/
			} catch (Exception e) {
				errorMsgs.add("�ק��ƨ��X�ɥ���:" + e.getMessage());
				RequestDispatcher failureView = req.getRequestDispatcher(requestURL);
				failureView.forward(req, res);
			}
		}

		if ("insert".equals(action)) { // �Ӧ�addPower.jsp���ШD

			List<String> errorMsgs = new LinkedList<String>();
			List<String> errorMsgs2 = new LinkedList<String>();
			// Store this set in the request scope, in case we need to
			// send the ErrorPage view.
			req.setAttribute("errorMsgs", errorMsgs);
			req.setAttribute("errorMsgs2", errorMsgs2);

			try {
				/***********************
				 * 1.�����ШD�Ѽ� - ��J�榡�����~�B�z
				 *************************/
				Integer adminno = new Integer(req.getParameter("adminno").trim());
				Integer feano = new Integer(req.getParameter("feano").trim());

				PowerVO powerVO = new PowerVO();
				powerVO.setAdminno(adminno);
				powerVO.setFeano(feano);

				// Send the use back to the form, if there were errors
				if (!errorMsgs.isEmpty()) {
					req.setAttribute("powerVO", powerVO); // �t����J�榡���~��powerVO����,�]�s�Jreq
					RequestDispatcher failureView = req.getRequestDispatcher("/power/addPower.jsp");
					failureView.forward(req, res);
					return;
				}

				/***************************
				 * 2.�}�l�s�W���
				 ***************************************/
				PowerService powerSvc = new PowerService();
				powerVO = powerSvc.addPower(adminno, feano);

				/***************************
				 * 3.�s�W����,�ǳ����(Send the Success view)
				 ***********/
				String url = "/power/listAllPower.jsp";
				RequestDispatcher successView = req.getRequestDispatcher(url); // �s�W���\�����listAllPower.jsp
				successView.forward(req, res);

				/*************************** ��L�i�઺���~�B�z **********************************/
			} catch (Exception e) {
				errorMsgs.add(e.getMessage());
				RequestDispatcher failureView = req.getRequestDispatcher("/power/addPower.jsp");
				failureView.forward(req, res);
			}
		}

		if ("delete".equals(action)) { // �Ӧ�listAllPower.jsp ��
										// /dept/listPowers_ByDeptno.jsp���ШD

			List<String> errorMsgs = new LinkedList<String>();
			// Store this set in the request scope, in case we need to
			// send the ErrorPage view.
			req.setAttribute("errorMsgs", errorMsgs);

			String requestURL = req.getParameter("requestURL"); // �e�X�R�����ӷ��������|:
																// �i�ର�i/power/listAllPower.jsp�j
																// ��
																// �i/dept/listPowers_ByDeptno.jsp�j
																// �� �i
																// /dept/listAllDept.jsp�j

			try {
				/***************************
				 * 1.�����ШD�Ѽ�
				 ***************************************/
				Integer adminno = new Integer(req.getParameter("adminno").trim());
				Integer feano = new Integer(req.getParameter("feano").trim());
				/***************************
				 * 2.�}�l�R�����
				 ***************************************/

				PowerService powerSvc = new PowerService();
				List<PowerVO> list = powerSvc.getListByAdminno(adminno);
				powerSvc.deletePowerByVO(adminno, feano);

				/***************************
				 * 3.�R������,�ǳ����(Send the Success view)
				 ***********/
				// PowerService deptSvc = new DeptService();
				if (requestURL.equals("/power/listAllPower.jsp") || requestURL.equals("/dept/listAllDept.jsp"))
					req.setAttribute("listAllPower", powerSvc.getAll()); // ��Ʈw���X��list����,�s�Jrequest

				String url = requestURL;
				RequestDispatcher successView = req.getRequestDispatcher(url); // �ק令�\��,���^�e�X�ק諸�ӷ�����
				successView.forward(req, res);

				/*************************** ��L�i�઺���~�B�z **********************************/
			} catch (Exception e) {
				errorMsgs.add("�R����ƥ���:" + e.getMessage());
				RequestDispatcher failureView = req.getRequestDispatcher(requestURL);
				failureView.forward(req, res);
			}
		}
	}
}
