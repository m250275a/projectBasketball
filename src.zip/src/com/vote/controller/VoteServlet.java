package com.vote.controller;

import java.io.*;
import java.util.*;

import javax.servlet.*;
import javax.servlet.http.*;

import com.vote.model.*;

public class VoteServlet extends HttpServlet {

	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		doPost(req, res);
	}

	public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {

		req.setCharacterEncoding("UTF-8");
		String action = req.getParameter("action");
		
		
		if ("getOne_For_Display".equals(action)) { // �Ӧ�select_page.jsp���ШD

			List<String> errorMsgs = new LinkedList<String>();
			// Store this set in the request scope, in case we need to
			// send the ErrorPage view.
			req.setAttribute("errorMsgs", errorMsgs);

			try {
				/***************************1.�����ШD�Ѽ� - ��J�榡�����~�B�z**********************/
				String str = req.getParameter("voteno");
				if (str == null || (str.trim()).length() == 0) {
					errorMsgs.add("�п�J�벼�s��");
				}
				// Send the use back to the form, if there were errors
				if (!errorMsgs.isEmpty()) {
					RequestDispatcher failureView = req
							.getRequestDispatcher("/vote/select_page.jsp");
					failureView.forward(req, res);
					return;//�{�����_
				}
				
				Integer voteno = null;
				try {
					voteno = new Integer(str);
				} catch (Exception e) {
					errorMsgs.add("�벼�s���榡�����T");
				}
				// Send the use back to the form, if there were errors
				if (!errorMsgs.isEmpty()) {
					RequestDispatcher failureView = req
							.getRequestDispatcher("/vote/select_page.jsp");
					failureView.forward(req, res);
					return;//�{�����_
				}
				
				/***************************2.�}�l�d�߸��*****************************************/
				VoteService voteSvc = new VoteService();
				VoteVO voteVO = voteSvc.getOneVote(voteno);
				if (voteVO == null) {
					errorMsgs.add("�d�L���");
				}
				// Send the use back to the form, if there were errors
				if (!errorMsgs.isEmpty()) {
					RequestDispatcher failureView = req
							.getRequestDispatcher("/vote/select_page.jsp");
					failureView.forward(req, res);
					return;//�{�����_
				}
				
				/***************************3.�d�ߧ���,�ǳ����(Send the Success view)*************/
				req.setAttribute("voteVO", voteVO); // ��Ʈw���X��voteVO����,�s�Jreq
				String url = "/vote/listOneVote.jsp";
				RequestDispatcher successView = req.getRequestDispatcher(url); // ���\���listOneVote.jsp
				successView.forward(req, res);

				/***************************��L�i�઺���~�B�z*************************************/
			} catch (Exception e) {
				errorMsgs.add("�L�k���o���:" + e.getMessage());
				RequestDispatcher failureView = req
						.getRequestDispatcher("/vote/select_page.jsp");
				failureView.forward(req, res);
			}
		}
		
		
		if ("getOne_For_Update".equals(action)) { // �Ӧ�listAllVote.jsp ��  /dept/listVotes_ByDeptno.jsp ���ШD

			List<String> errorMsgs = new LinkedList<String>();
			// Store this set in the request scope, in case we need to
			// send the ErrorPage view.
			req.setAttribute("errorMsgs", errorMsgs);
			
			String requestURL = req.getParameter("requestURL"); // �e�X�ק諸�ӷ��������|: �i�ର�i/vote/listAllVote.jsp�j ��  �i/dept/listVotes_ByDeptno.jsp�j �� �i /dept/listAllDept.jsp�j		
			
			try {
				/***************************1.�����ШD�Ѽ�****************************************/
				Integer voteno = new Integer(req.getParameter("voteno"));
				
				/***************************2.�}�l�d�߸��****************************************/
				VoteService voteSvc = new VoteService();
				VoteVO voteVO = voteSvc.getOneVote(voteno);
								
				/***************************3.�d�ߧ���,�ǳ����(Send the Success view)************/
				req.setAttribute("voteVO", voteVO); // ��Ʈw���X��voteVO����,�s�Jreq
				String url = "/vote/update_vote_input.jsp";
				RequestDispatcher successView = req.getRequestDispatcher(url); // ���\���update_vote_input.jsp
				successView.forward(req, res);

				/***************************��L�i�઺���~�B�z************************************/
			} catch (Exception e) {
				errorMsgs.add("�ק��ƨ��X�ɥ���:"+e.getMessage());
				RequestDispatcher failureView = req
						.getRequestDispatcher(requestURL);
				failureView.forward(req, res);
			}
		}
		
		
		if ("update".equals(action)) { // �Ӧ�update_vote_input.jsp���ШD
			
			List<String> errorMsgs = new LinkedList<String>();
			// Store this set in the request scope, in case we need to
			// send the ErrorPage view.
			req.setAttribute("errorMsgs", errorMsgs);
			
			String requestURL = req.getParameter("requestURL"); // �e�X�ק諸�ӷ��������|: �i�ର�i/vote/listAllVote.jsp�j ��  �i/dept/listVotes_ByDeptno.jsp�j �� �i /dept/listAllDept.jsp�j
		
			try {
				/***************************1.�����ШD�Ѽ� - ��J�榡�����~�B�z**********************/
				Integer voteno = new Integer(req.getParameter("voteno").trim());
				Integer votedno = new Integer(req.getParameter("votedno").trim());
				java.sql.Date votetime = null;
				try {
					votetime = java.sql.Date.valueOf(req.getParameter("votetime").trim());
				} catch (IllegalArgumentException e) {
					votetime=new java.sql.Date(System.currentTimeMillis());
					errorMsgs.add("�п�J���!");
				}
				
				VoteVO voteVO = new VoteVO();
				voteVO.setVoteno(voteno);
				voteVO.setVotedno(votedno);
				voteVO.setVotetime(votetime);
				

				// Send the use back to the form, if there were errors
				if (!errorMsgs.isEmpty()) {
					req.setAttribute("voteVO", voteVO); // �t����J�榡���~��voteVO����,�]�s�Jreq
					RequestDispatcher failureView = req
							.getRequestDispatcher("/vote/update_vote_input.jsp");
					failureView.forward(req, res);
					return; //�{�����_
				}
				
				/***************************2.�}�l�ק���*****************************************/
				VoteService voteSvc = new VoteService();
				voteVO = voteSvc.updateVote(voteno, votedno, votetime);
				
				/***************************3.�ק粒��,�ǳ����(Send the Success view)*************/				
//				VoteService deptSvc = new DeptService();
				if(requestURL.equals("/vote/listAllVote.jsp") || requestURL.equals("/dept/listAllDept.jsp"))
					req.setAttribute("listAllVote",voteSvc.getAll()); // ��Ʈw���X��list����,�s�Jrequest

                String url = requestURL;
				RequestDispatcher successView = req.getRequestDispatcher(url);   // �ק令�\��,���^�e�X�ק諸�ӷ�����
				successView.forward(req, res);

				/***************************��L�i�઺���~�B�z*************************************/
			} catch (Exception e) {
				errorMsgs.add("�ק��ƥ���:"+e.getMessage());
				RequestDispatcher failureView = req
						.getRequestDispatcher("/vote/update_vote_input.jsp");
				failureView.forward(req, res);
			}
		}

        if ("insert".equals(action)) { // �Ӧ�addVote.jsp���ШD  
			
			List<String> errorMsgs = new LinkedList<String>();
			// Store this set in the request scope, in case we need to
			// send the ErrorPage view.
			req.setAttribute("errorMsgs", errorMsgs);

			try {
				/***********************1.�����ШD�Ѽ� - ��J�榡�����~�B�z*************************/
				Integer voteno = new Integer(req.getParameter("voteno").trim());
				Integer votedno = new Integer(req.getParameter("votedno").trim());
				java.sql.Date votetime = null;
				try {
					votetime = java.sql.Date.valueOf(req.getParameter("votetime").trim());
				} catch (IllegalArgumentException e) {
					votetime=new java.sql.Date(System.currentTimeMillis());
					errorMsgs.add("�п�J���!");
				}
				
				VoteVO voteVO = new VoteVO();
				voteVO.setVoteno(voteno);
				voteVO.setVotedno(votedno);
				voteVO.setVotetime(votetime);

				// Send the use back to the form, if there were errors
				if (!errorMsgs.isEmpty()) {
					req.setAttribute("voteVO", voteVO); // �t����J�榡���~��voteVO����,�]�s�Jreq
					RequestDispatcher failureView = req
							.getRequestDispatcher("/vote/addVote.jsp");
					failureView.forward(req, res);
					return;
				}
				
				/***************************2.�}�l�s�W���***************************************/
				VoteService voteSvc = new VoteService();
				voteVO = voteSvc.addVote(voteno, votedno, votetime);
				
				/***************************3.�s�W����,�ǳ����(Send the Success view)***********/
				String url = "/vote/listAllVote.jsp";
				RequestDispatcher successView = req.getRequestDispatcher(url); // �s�W���\�����listAllVote.jsp
				successView.forward(req, res);				
				
				/***************************��L�i�઺���~�B�z**********************************/
			} catch (Exception e) {
				errorMsgs.add(e.getMessage());
				RequestDispatcher failureView = req
						.getRequestDispatcher("/vote/addVote.jsp");
				failureView.forward(req, res);
			}
		}
		
       
		if ("delete".equals(action)) { // �Ӧ�listAllVote.jsp ��  /dept/listVotes_ByDeptno.jsp���ШD

			List<String> errorMsgs = new LinkedList<String>();
			// Store this set in the request scope, in case we need to
			// send the ErrorPage view.
			req.setAttribute("errorMsgs", errorMsgs);
			
			String requestURL = req.getParameter("requestURL"); // �e�X�R�����ӷ��������|: �i�ର�i/vote/listAllVote.jsp�j ��  �i/dept/listVotes_ByDeptno.jsp�j �� �i /dept/listAllDept.jsp�j

			try {
				/***************************1.�����ШD�Ѽ�***************************************/
				Integer voteno = new Integer(req.getParameter("voteno"));
				
				/***************************2.�}�l�R�����***************************************/
				VoteService voteSvc = new VoteService();
				VoteVO voteVO = voteSvc.getOneVote(voteno);
				voteSvc.deleteVote(voteno);
				
				/***************************3.�R������,�ǳ����(Send the Success view)***********/
//				VoteService deptSvc = new DeptService();
				if(requestURL.equals("/vote/listAllVote.jsp") || requestURL.equals("/dept/listAllDept.jsp"))
					req.setAttribute("listAllVote",voteSvc.getAll()); // ��Ʈw���X��list����,�s�Jrequest

                String url = requestURL;
				RequestDispatcher successView = req.getRequestDispatcher(url);   // �ק令�\��,���^�e�X�ק諸�ӷ�����
				successView.forward(req, res);
				
				/***************************��L�i�઺���~�B�z**********************************/
			} catch (Exception e) {
				errorMsgs.add("�R����ƥ���:"+e.getMessage());
				RequestDispatcher failureView = req
						.getRequestDispatcher(requestURL);
				failureView.forward(req, res);
			}
		}
	}
}
