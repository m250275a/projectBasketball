package com.vote.model;

import java.util.List;

public class VoteService {
	
	private VoteDAO_interface dao;

	public VoteService() {
		dao = new VoteJNDIDAO();
	}

	public VoteVO addVote(Integer voteno, Integer votedno, java.sql.Date votetime) {
		
		VoteVO voteVO = new VoteVO();

		voteVO.setVoteno(voteno);
		voteVO.setVotedno(votedno);
		voteVO.setVotetime(votetime);
		dao.insert(voteVO);

		return voteVO;
	}

	public VoteVO updateVote(Integer voteno, Integer votedno,java.sql.Date votetime) {
		VoteVO voteVO = new VoteVO();

		voteVO.setVoteno(voteno);
		voteVO.setVotedno(votedno);
		voteVO.setVotetime(votetime);
		dao.update(voteVO);

		return voteVO;
	}

	public void deleteVote(Integer voteno) {
		dao.delete(voteno);
	}

	public VoteVO getOneVote(Integer voteno) {
		return dao.findByPrimaryKey(voteno);
	}

	public List<VoteVO> getAll() {
		return dao.getAll();
	}

}
