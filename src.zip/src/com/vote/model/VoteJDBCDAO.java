package com.vote.model;

import java.util.*;
import java.sql.*;

public class VoteJDBCDAO implements VoteDAO_interface {
	String driver = "oracle.jdbc.driver.OracleDriver";
	String url = "jdbc:oracle:thin:@localhost:1521:XE";
	String userid = "AA103g05";
	String passwd = "1234";

	private static final String INSERT_STMT = 
			"INSERT INTO Vote (voteno, votedno, votetime) VALUES (?, ?, default)";
	private static final String GET_ALL_STMT = 
			"SELECT voteno, votedno, votetime FROM Vote order by voteno";
	private static final String GET_ONE_STMT = 
			"SELECT voteno, votedno, votetime FROM Vote where voteno = ?";
	private static final String DELETE = 
			"DELETE FROM Vote where voteno = ?";
	private static final String UPDATE = 
			"UPDATE Vote set votedno=?, votetime=? where voteno = ?";

	@Override
	public void insert(VoteVO voteVO) {

		Connection con = null;
		PreparedStatement pstmt = null;

		try {

			Class.forName(driver);
			con = DriverManager.getConnection(url, userid, passwd);
			pstmt = con.prepareStatement(INSERT_STMT);

			pstmt.setInt(1, voteVO.getVoteno());
			pstmt.setInt(2, voteVO.getVotedno());
			// pstmt.setDate(3, voteVO.getVotetime());

			pstmt.executeUpdate();

			// Handle any driver errors
		} catch (ClassNotFoundException e) {
			throw new RuntimeException("Couldn't load database driver. " + e.getMessage());
			// Handle any SQL errors
		} catch (SQLException se) {
			throw new RuntimeException("A database error occured. " + se.getMessage());
			// Clean up JDBC resources
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					e.printStackTrace(System.err);
				}
			}
		}
	}

	@Override
	public void update(VoteVO voteVO) {

		Connection con = null;
		PreparedStatement pstmt = null;

		try {

			Class.forName(driver);
			con = DriverManager.getConnection(url, userid, passwd);
			pstmt = con.prepareStatement(UPDATE);
			
			pstmt.setInt(1, voteVO.getVotedno());
			pstmt.setDate(2, voteVO.getVotetime());
			pstmt.setInt(3, voteVO.getVoteno());

			pstmt.executeUpdate();

			// Handle any driver errors
		} catch (ClassNotFoundException e) {
			throw new RuntimeException("Couldn't load database driver. " + e.getMessage());
			// Handle any SQL errors
		} catch (SQLException se) {
			throw new RuntimeException("A database error occured. " + se.getMessage());
			// Clean up JDBC resources
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					e.printStackTrace(System.err);
				}
			}
		}
	}

	@Override
	public void delete(Integer voteno) {

		Connection con = null;
		PreparedStatement pstmt = null;

		try {

			Class.forName(driver);
			con = DriverManager.getConnection(url, userid, passwd);
			pstmt = con.prepareStatement(DELETE);

			pstmt.setInt(1, voteno);

			pstmt.executeUpdate();

			// Handle any driver errors
		} catch (ClassNotFoundException e) {
			throw new RuntimeException("Couldn't load database driver. " + e.getMessage());
			// Handle any SQL errors
		} catch (SQLException se) {
			throw new RuntimeException("A database error occured. " + se.getMessage());
			// Clean up JDBC resources
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					e.printStackTrace(System.err);
				}
			}
		}
	}

	@Override
	public VoteVO findByPrimaryKey(Integer voteno) {

		VoteVO voteVO = null;
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {

			Class.forName(driver);
			con = DriverManager.getConnection(url, userid, passwd);
			pstmt = con.prepareStatement(GET_ONE_STMT);

			pstmt.setInt(1, voteno);

			rs = pstmt.executeQuery();

			while (rs.next()) {
				voteVO = new VoteVO();
				voteVO.setVoteno(rs.getInt("voteno"));
				voteVO.setVotedno(rs.getInt("votedno"));
				voteVO.setVotetime(rs.getDate("votetime"));
			}

			// Handle any driver errors
		} catch (ClassNotFoundException e) {
			throw new RuntimeException("Couldn't load database driver. " + e.getMessage());
			// Handle any SQL errors
		} catch (SQLException se) {
			throw new RuntimeException("A database error occured. " + se.getMessage());
			// Clean up JDBC resources
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					e.printStackTrace(System.err);
				}
			}
		}
		return voteVO;
	}

	@Override
	public List<VoteVO> getAll() {
		List<VoteVO> list = new ArrayList<VoteVO>();
		VoteVO voteVO = null;

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {

			Class.forName(driver);
			con = DriverManager.getConnection(url, userid, passwd);
			pstmt = con.prepareStatement(GET_ALL_STMT);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				voteVO = new VoteVO();
				voteVO.setVoteno(rs.getInt("voteno"));
				voteVO.setVotedno(rs.getInt("votedno"));
				voteVO.setVotetime(rs.getDate("votetime"));
				list.add(voteVO); // Store the row in the list
			}

			// Handle any driver errors
		} catch (ClassNotFoundException e) {
			throw new RuntimeException("Couldn't load database driver. " + e.getMessage());
			// Handle any SQL errors
		} catch (SQLException se) {
			throw new RuntimeException("A database error occured. " + se.getMessage());
			// Clean up JDBC resources
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException se) {
					se.printStackTrace(System.err);
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					e.printStackTrace(System.err);
				}
			}
		}
		return list;
	}

	public static void main(String[] args) {

		VoteJDBCDAO dao = new VoteJDBCDAO();

		// �s�W
//		VoteVO voteVO1 = new VoteVO();
//		voteVO1.setVoteno(7002);
//		voteVO1.setVotedno(7014);
//		// voteVO1.setVottime(java.sql.Date.valueOf("default"));
//		dao.insert(voteVO1);
		//
		 // �ק�
//		 VoteVO voteVO2 = new VoteVO();
//		 voteVO2.setVoteno(7002);
//		 voteVO2.setVotedno(7011);
//		 //voteVO2.setVoted_time(java.sql.Date.valueOf("2016-07-20"));
//		 dao.update(voteVO2);

		// //�R��
//		 dao.delete(7002);

		 // �d��
		 VoteVO voteVO3 = dao.findByPrimaryKey(7001);
		 System.out.print(voteVO3.getVoteno() + ",");
		 System.out.print(voteVO3.getVotedno() + ",");
		 System.out.println(voteVO3.getVotetime() + ",");
		 System.out.println("---------------------");
		//
		// // �d��
		// List<VoteVO> list = dao.getAll();
		// for (VoteVO avoteVO : list) {
		// System.out.print(avoteVO.getVote_no() + ",");
		// System.out.print(avoteVO.getVoted_no() + ",");
		// System.out.print(avoteVO.getVoted_time() + ",");
		// System.out.println();
		// }
	}

}
