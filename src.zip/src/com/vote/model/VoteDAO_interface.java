package com.vote.model;

import java.util.*;

public interface VoteDAO_interface {
	public void insert(VoteVO voteVO);
    public void update(VoteVO voteVO);
    public void delete(Integer voteno);
    public VoteVO findByPrimaryKey(Integer voteno);
    public List<VoteVO> getAll();

}
