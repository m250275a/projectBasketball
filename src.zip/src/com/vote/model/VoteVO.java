package com.vote.model;

import java.sql.*;

public class VoteVO implements java.io.Serializable {
	private Integer voteno;
	private Integer votedno;
	private Date votetime;
	public Integer getVoteno() {
		return voteno;
	}
	public void setVoteno(Integer voteno) {
		this.voteno = voteno;
	}
	public Integer getVotedno() {
		return votedno;
	}
	public void setVotedno(Integer votedno) {
		this.votedno = votedno;
	}
	public Date getVotetime() {
		return votetime;
	}
	public void setVotetime(Date votetime) {
		this.votetime = votetime;
	}
	
}
